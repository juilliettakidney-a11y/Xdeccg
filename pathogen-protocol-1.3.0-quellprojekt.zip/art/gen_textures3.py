#!/usr/bin/env python3
from PIL import Image, ImageDraw
import math, os, random
OUT = "/home/user/pathogen-protocol/src/main/resources/assets/pathogen_protocol"
random.seed(42)

yellow = (232, 200, 50, 255); yellow_dark = (150, 128, 24, 255); yellow_hi = (250, 228, 110, 255)
grey = (120, 120, 120, 255); black = (16, 16, 16, 255)
broken = (168, 156, 84, 255); broken_dark = (96, 88, 40, 255); broken_hi = (200, 190, 120, 255)

def armor(path, base, base_dark, base_hi, ripped):
    im = Image.new("RGBA", (64, 32), base)
    d = ImageDraw.Draw(im)
    # ---- body region (y 17..31), front panel x20..27
    d.rectangle([16, 16, 39, 31], fill=base)
    # outline edges of body
    d.line([(16,16),(16,31)], fill=base_dark); d.line([(39,16),(39,31)], fill=base_dark)
    d.line([(16,16),(39,16)], fill=base_dark); d.line([(16,31),(39,31)], fill=base_dark)
    # zipper center front (front is x20..27)
    d.line([(23,17),(23,31)], fill=base_dark); d.line([(24,17),(24,31)], fill=base_dark)
    # collar
    d.rectangle([20,16,27,18], fill=base_dark)
    # hazard stripe chevron on chest
    for i, (x, y) in enumerate([(20,24),(21,23),(22,22),(25,22),(26,23),(27,24)]):
        d.point((x, y), fill=black if i % 2 == 0 else yellow_hi)
    d.line([(19,25),(28,25)], fill=base_dark)
    # back cross-straps
    d.line([(33,17),(37,31)], fill=base_dark); d.line([(37,17),(33,31)], fill=base_dark)
    # arms (both sides) x0..15 and x40..63, y17..31
    for (x0, x1) in [(0, 15), (40, 63)]:
        d.rectangle([x0, 16, x1, 31], fill=base)
        d.rectangle([x0, 29, x1, 31], fill=base_dark)   # gloves/cuffs
        d.line([(x0,16),(x1,16)], fill=base_dark)
        d.line([(x0,23),(x1,23)], fill=base_dark)      # elbow seam
    # noise speckles
    for _ in range(60):
        x, y = random.randrange(64), random.randrange(16, 32)
        cur = im.getpixel((x, y))
        if cur == base:
            im.putpixel((x, y), base_dark if random.random() < 0.6 else base_hi)
    if ripped:
        for _ in range(28):
            x, y = random.randrange(64), random.randrange(16, 32)
            im.putpixel((x, y), black)
        # tears in body front
        for (x, y) in [(21, 20), (26, 27), (22, 29)]: im.putpixel((x, y), black)
        d.line([(20, 19), (23, 26)], fill=black)
    im.save(path)

def leggings(path, base, base_dark, base_hi):
    im = Image.new("RGBA", (64, 32), base)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 16, 63, 31], fill=base)
    for (x0, x1) in [(0, 15), (16, 39), (40, 63)]:
        d.rectangle([x0, 28, x1, 31], fill=base_dark)
    d.line([(23,17),(23,31)], fill=base_dark); d.line([(24,17),(24,31)], fill=base_dark)
    d.line([(0,22),(15,22)], fill=base_dark); d.line([(16,22),(39,22)], fill=base_dark); d.line([(40,22),(63,22)], fill=base_dark)
    for _ in range(40):
        x, y = random.randrange(64), random.randrange(16, 32)
        if im.getpixel((x, y)) == base:
            im.putpixel((x, y), base_dark if random.random() < 0.6 else base_hi)
    im.save(path)

armor(f"{OUT}/textures/entity/equipment/humanoid/hazmat.png", yellow, yellow_dark, yellow_hi, False)
armor(f"{OUT}/textures/entity/equipment/humanoid/hazmat_broken.png", broken, broken_dark, broken_hi, True)
armor(f"{OUT}/textures/entity/equipment/humanoid_baby/hazmat.png", yellow, yellow_dark, yellow_hi, False)
armor(f"{OUT}/textures/entity/equipment/humanoid_baby/hazmat_broken.png", broken, broken_dark, broken_hi, True)
leggings(f"{OUT}/textures/entity/equipment/humanoid_leggings/hazmat.png", yellow, yellow_dark, yellow_hi)
leggings(f"{OUT}/textures/entity/equipment/humanoid_leggings/hazmat_broken.png", broken, broken_dark, broken_hi)
leggings(f"{OUT}/textures/entity/equipment/humanoid_baby_leggings/hazmat.png", yellow, yellow_dark, yellow_hi)
leggings(f"{OUT}/textures/entity/equipment/humanoid_baby_leggings/hazmat_broken.png", broken, broken_dark, broken_hi)

# ---------- mod icon 128x128: biohazard on dark disc ----------
S = 128
im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
d.ellipse([2, 2, S-3, S-3], fill=(24, 18, 26, 255))
d.ellipse([2, 2, S-3, S-3], outline=(250, 204, 60, 255), width=5)
cx, cy = S/2, S/2 + 4
col = (250, 204, 60, 255)
bg = (24, 18, 26, 255)
def ring_seg(a_start, a_end, r_in, r_out, colr):
    steps = 400
    for i in range(steps + 1):
        a = math.radians(a_start + (a_end - a_start) * i / steps)
        for r in range(int(r_in*4), int(r_out*4)+1):
            rr = r / 4.0
            x, y = cx + rr*math.cos(a), cy + rr*math.sin(a)
            d.point((x, y), fill=colr)
# three crescents
for off in (0, 120, 240):
    ring_seg(off - 60, off + 60, 17, 34, col)
# center disc
d.ellipse([cx-8, cy-8, cx+8, cy+8], fill=col)
# cut the three inner lobes
for off in (30, 150, 270):
    a = math.radians(off + 90)
    px, py = cx + 20*math.cos(a), cy + 20*math.sin(a)
    d.ellipse([px-12, py-12, px+12, py+12], fill=bg)
d.ellipse([cx-4.5, cy-4.5, cx+4.5, cy+4.5], fill=bg)
im.save(f"{OUT}/icon.png")
print("armor+icon done")

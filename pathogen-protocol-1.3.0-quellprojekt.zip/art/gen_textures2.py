#!/usr/bin/env python3
from PIL import Image, ImageDraw
import math, os
OUT = "/home/user/pathogen-protocol/src/main/resources/assets/pathogen_protocol"
T = {
    "outline": (22,22,26,255), "glass": (198,226,233,255), "glass_hi": (255,255,255,255),
    "steel": (178,188,198,255), "steel_dark": (96,106,116,255), "steel_hi": (228,234,240,255),
    "yellow": (232,200,50,255), "yellow_dark": (140,118,20,255), "yellow_hi": (250,228,110,255),
    "wood": (120,84,48,255), "wood_dark": (72,48,26,255), "dark_panel": (44,48,60,255),
    "dark_panel_hi": (66,72,90,255), "cyan": (70,240,220,255), "cyan_dark": (20,120,110,255),
    "green": (67,192,74,255), "green_dark": (31,124,40,255), "black": (10,10,10,255),
    "amber": (224,140,48,255), "white": (245,245,245,255), "red": (216,64,64,255),
}
def img(size=16):
    im = Image.new("RGBA", (size, size), (0,0,0,0)); return im, ImageDraw.Draw(im)
def save(im, path): im.save(path)

# ---------- lab_table_top ----------
im, d = img(16)
d.rectangle([0,0,15,15], fill=T["steel"])
for x in range(16): d.point((x,0), fill=T["steel_hi"])
# subtle tile grid
for i in (5, 10):
    for y in range(16): d.point((i, y), fill=T["steel_dark"])
# beaker icon (blue)
d.rectangle([7,3,9,5], outline=T["dark_panel"])
d.point((8,4), fill=(63,140,224,255))
# flask icon (green)
d.point((12,9), fill=T["dark_panel"]); d.point((11,10), fill=T["dark_panel"]); d.point((12,10), fill=T["green"]); d.point((13,10), fill=T["dark_panel"])
# hazard dot
d.point((2,12), fill=T["yellow"]); d.point((2,13), fill=T["black"])
save(im, f"{OUT}/textures/block/lab_table_top.png")
# ---------- lab_table_side ----------
im, d = img(16)
d.rectangle([0,0,15,15], fill=T["wood"])
# caution stripe top
for x in range(16):
    d.point((x,1), fill=T["yellow"] if (x//2)%2==0 else T["black"])
    d.point((x,2), fill=T["yellow"] if (x//2)%2==0 else T["black"])
d.rectangle([0,0,15,15], outline=T["wood_dark"])
# drawers
for (y0,y1) in [(5,8),(10,13)]:
    d.rectangle([2,y0,13,y1], fill=T["wood_dark"])
    d.rectangle([3,y0+1,12,y1-1], fill=(100,70,40,255))
    d.rectangle([6,y0+1,9 if y0==5 else 9, y0+2], fill=T["steel_dark"])
save(im, f"{OUT}/textures/block/lab_table_side.png")
# ---------- research_bench (cube_all, screen face) ----------
im, d = img(16)
d.rectangle([0,0,15,15], fill=T["dark_panel"])
d.rectangle([0,0,15,15], outline=T["black"])
# screen
d.rectangle([2,2,13,9], fill=(16,20,30,255))
# scan text lines (cyan)
for (y,w) in [(3,8),(5,10),(7,6)]:
    for x in range(3, 3+w): d.point((x,y), fill=T["cyan"])
d.point((12,3), fill=T["red"]); d.point((12,5), fill=T["yellow"])
# keyboard
for y in (11,13):
    for x in range(2,14): d.point((x,y), fill=T["dark_panel_hi"])
save(im, f"{OUT}/textures/block/research_bench.png")
# ---------- microscope (cube_all) ----------
im, d = img(16)
d.rectangle([0,0,15,15], fill=T["dark_panel"])
d.rectangle([0,0,15,15], outline=T["black"])
# lens circle
cx, cy = 8, 6
for y in range(2, 11):
    for x in range(2, 14):
        r2 = (x-cx)**2 + (y-cy)**2
        if r2 <= 12: d.point((x,y), fill=T["steel_dark"])
        if r2 <= 6: d.point((x,y), fill=T["cyan_dark"])
        if r2 <= 2: d.point((x,y), fill=T["cyan"])
# base
for x in range(3, 13): d.point((x,13), fill=T["steel"]); d.point((x,14), fill=T["steel_dark"])
save(im, f"{OUT}/textures/block/microscope.png")
# ---------- centrifuge (cube_all) ----------
im, d = img(16)
d.rectangle([0,0,15,15], fill=T["steel"])
d.rectangle([0,0,15,15], outline=T["steel_dark"])
# rotor circle
cx, cy = 8, 8
for y in range(2, 14):
    for x in range(2, 14):
        r2 = (x-cx)**2 + (y-cy)**2
        if r2 <= 25: d.point((x,y), fill=T["steel_dark"])
        if r2 <= 16: d.point((x,y), fill=T["dark_panel"])
# 4 test-tube holes
for (x,y) in [(6,6),(10,6),(6,10),(10,10)]:
    d.ellipse([x-1,y-1,x+1,y+1], fill=T["black"])
d.point((8,8), fill=T["steel_hi"])
save(im, f"{OUT}/textures/block/centrifuge.png")
# ---------- incubator (cube_all) ----------
im, d = img(16)
d.rectangle([0,0,15,15], fill=T["dark_panel"])
# glass dome
for y in range(2, 12):
    for x in range(3, 13):
        if (x-8)**2 + (y-11)**2 <= 52: d.point((x,y), fill=(30,60,45,255))
# glowing culture dots inside
for (x,y) in [(6,8),(9,7),(10,9),(7,10),(8,5)]: d.point((x,y), fill=T["green"])
d.point((8,6), fill=(150,255,160,255))
# base
for x in range(1, 15): d.point((x,12), fill=T["steel_dark"]); d.point((x,13), fill=T["black"])
d.point((3,11), fill=T["green"]); d.point((4,11), fill=T["green"])
save(im, f"{OUT}/textures/block/incubator.png")
# ---------- effect icon 18x18 biohazard ----------
N = 18
im, d = img(N)
d.rectangle([0,0,N-1,N-1], fill=(30,8,8,255))
cx, cy = N/2, N/2
R = 7.2
# three crescents approximated by ring arcs
for a in range(0, 360, 1):
    pass
import math
col = (240, 90, 60, 255)
for y in range(N):
    for x in range(N):
        dx, dy = x+0.5-cx, y+0.5-cy
        r = math.hypot(dx, dy)
        ang = math.degrees(math.atan2(dy, dx)) % 120
        # ring band
        if 4.2 <= r <= 6.6 and (ang > 12 and ang < 108):
            d.point((x,y), fill=col)
        # center circle
        if r <= 1.8: d.point((x,y), fill=col)
# three inner cutouts (dark) to shape trefoil
for off in (0, 120, 240):
    a = math.radians(off - 90)
    px, py = cx + 3.6*math.cos(a), cy + 3.6*math.sin(a)
    for y in range(N):
        for x in range(N):
            if math.hypot(x+0.5-px, y+0.5-py) <= 2.1:
                d.point((x,y), fill=(30,8,8,255))
save(im, f"{OUT}/textures/mob_effect/viral_infection.png")
print("blocks+effect done")

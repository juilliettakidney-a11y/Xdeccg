#!/usr/bin/env python3
"""Regenerates all JSON assets for Pathogen Protocol (26.3 datapack/resource formats)."""
import json, os

R = "/home/user/pathogen-protocol/src/main/resources"
A = f"{R}/assets/pathogen_protocol"
D = f"{R}/data/pathogen_protocol"
for p in [A+"/models/item", A+"/models/block", A+"/blockstates", A+"/equipment", A+"/lang",
          D+"/recipe", D+"/loot_table/blocks"]:
    os.makedirs(p, exist_ok=True)

def w(path, obj):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)

mod = "pathogen_protocol"

# ---------- models: generated (2D) items ----------
generated_items = ["empty_vial", "empty_syringe", "culture_medium", "pathogen_protein",
                   "antibiotics", "serum", "genome_fragment",
                   "hazmat_repair_kit", "hazmat_suit", "broken_hazmat_suit",
                   "virus_vial", "virus_syringe", "pathogen_probe", "sterile_swab"]
for item in generated_items:
    w(f"{A}/models/item/{item}.json", {"parent": "minecraft:item/generated",
                                       "textures": {"layer0": f"{mod}:item/{item}"}})

# ---------- models: blocks ----------
blocks_cubeall = ["research_bench", "microscope", "centrifuge", "incubator", "culture_plate",
                  "lab_cabinet", "lab_wall", "lab_floor", "hazard_stripe"]
# lab_counter: steel sink top, cabinet sides
w(f"{A}/models/block/lab_counter.json", {
    "parent": "minecraft:block/cube",
    "textures": {
        "particle": f"{mod}:block/lab_counter_side",
        "up": f"{mod}:block/lab_counter_top",
        "down": "minecraft:block/oak_planks",
        "north": f"{mod}:block/lab_counter_side",
        "south": f"{mod}:block/lab_counter_side",
        "east": f"{mod}:block/lab_counter_side",
        "west": f"{mod}:block/lab_counter_side",
    }})
w(f"{A}/blockstates/lab_counter.json", {"variants": {"": {"model": f"{mod}:block/lab_counter"}}})
w(f"{A}/models/item/lab_counter.json", {"parent": f"{mod}:block/lab_counter"})
for b in blocks_cubeall:
    w(f"{A}/models/block/{b}.json", {"parent": "minecraft:block/cube_all",
                                     "textures": {"all": f"{mod}:block/{b}"}})
    w(f"{A}/blockstates/{b}.json", {"variants": {"": {"model": f"{mod}:block/{b}"}}})
    w(f"{A}/models/item/{b}.json", {"parent": f"{mod}:block/{b}"})

w(f"{A}/models/block/lab_table.json", {
    "parent": "minecraft:block/cube",
    "textures": {
        "particle": f"{mod}:block/lab_table_side",
        "up": f"{mod}:block/lab_table_top",
        "down": "minecraft:block/oak_planks",
        "north": f"{mod}:block/lab_table_side",
        "south": f"{mod}:block/lab_table_side",
        "east": f"{mod}:block/lab_table_side",
        "west": f"{mod}:block/lab_table_side",
    }})
w(f"{A}/blockstates/lab_table.json", {"variants": {"": {"model": f"{mod}:block/lab_table"}}})
w(f"{A}/models/item/lab_table.json", {"parent": f"{mod}:block/lab_table"})

# ---------- equipment (armor) layers ----------
for name in ["hazmat", "hazmat_broken"]:
    w(f"{A}/equipment/{name}.json", {
        "layers": {
            "humanoid": [{"texture": f"{mod}:{name}"}],
            "humanoid_baby": [{"texture": f"{mod}:{name}"}],
            "humanoid_leggings": [{"texture": f"{mod}:{name}"}],
        }})

# ---------- recipes ----------
def shaped(name, pattern, key, result, count=1, category="misc"):
    w(f"{D}/recipe/{name}.json", {
        "type": "minecraft:crafting_shaped", "category": category,
        "pattern": pattern, "key": key,
        "result": {"id": f"{mod}:{result}", "count": count}})

def shapeless(name, ingredients, result, count=1, category="misc"):
    w(f"{D}/recipe/{name}.json", {
        "type": "minecraft:crafting_shapeless", "category": category,
        "ingredients": list(ingredients),
        "result": {"id": f"{mod}:{result}", "count": count}})

shaped("lab_counter", ["III", "IWI", "PPP"],
       {"I": "minecraft:iron_ingot", "W": "minecraft:white_wool", "P": "#minecraft:planks"}, "lab_counter", 1, "building")
shaped("lab_cabinet", ["III", "W W", "III"],
       {"I": "minecraft:iron_ingot", "W": "minecraft:white_wool"}, "lab_cabinet", 1, "building")
shaped("lab_wall", ["TTT", "TTT"],
       {"T": "minecraft:white_terracotta"}, "lab_wall", 4, "building")
shaped("lab_floor", ["QQ", "QQ"],
       {"Q": "minecraft:quartz_block"}, "lab_floor", 4, "building")
shapeless("hazard_stripe", ["minecraft:yellow_concrete", "minecraft:black_concrete"], "hazard_stripe", 2, "building")
shaped("lab_table", ["GGG", "PTP", "PPP"],
       {"G": "minecraft:glass", "P": "#minecraft:planks", "T": "minecraft:torch"}, "lab_table", 1, "building")
shaped("microscope", [" I ", "GOG", "RRR"],
       {"I": "minecraft:iron_ingot", "G": "minecraft:glass", "O": "minecraft:gold_ingot", "R": "minecraft:redstone"}, "microscope")
shaped("centrifuge", ["III", "IRI", "RRR"],
       {"I": "minecraft:iron_ingot", "R": "minecraft:redstone"}, "centrifuge")
shaped("research_bench", ["IRI", "GCG", "PPP"],
       {"I": "minecraft:iron_ingot", "R": "minecraft:redstone", "G": "minecraft:glass",
        "C": "minecraft:copper_ingot", "P": "#minecraft:planks"}, "research_bench")
shaped("incubator", ["IGI", "GSG", "III"],
       {"I": "minecraft:iron_ingot", "G": "minecraft:glass", "S": "minecraft:slime_block"}, "incubator")
shapeless("culture_plate", ["minecraft:glass", "minecraft:glass", "minecraft:slime_ball"], "culture_plate")
shapeless("culture_medium", ["minecraft:wheat_seeds", "minecraft:sugar"], "culture_medium", 2)
shapeless("empty_vial", ["minecraft:glass"] * 3 + ["minecraft:iron_nugget"], "empty_vial", 2)
shapeless("empty_syringe", ["minecraft:glass", "minecraft:iron_nugget", "minecraft:stick"], "empty_syringe")
shaped("antibiotics", [" S ", "PNP", " S "],
       {"S": "minecraft:sugar", "P": "minecraft:paper", "N": "minecraft:nether_wart"}, "antibiotics")
shapeless("serum", [f"{mod}:antibiotics", f"{mod}:genome_fragment", f"{mod}:genome_fragment",
                    f"{mod}:genome_fragment", "minecraft:nether_wart"], "serum")
shapeless("sterile_swab", ["minecraft:feather", "minecraft:stick"], "sterile_swab", 2)
shapeless("hazmat_repair_kit",
          ["minecraft:copper_ingot", "minecraft:copper_ingot", "minecraft:leather", "minecraft:iron_nugget"],
          "hazmat_repair_kit")
shapeless("hazmat_suit", [f"{mod}:broken_hazmat_suit", f"{mod}:hazmat_repair_kit"], "hazmat_suit")
# virus_vial / virus_syringe / pathogen_probe: never crafted — samples are found, swabbed or drawn.

# ---------- loot tables ----------
for b in ["lab_table", "microscope", "centrifuge", "incubator", "research_bench", "culture_plate",
          "lab_counter", "lab_cabinet", "lab_wall", "lab_floor", "hazard_stripe"]:
    w(f"{D}/loot_table/blocks/{b}.json", {
        "type": "minecraft:block",
        "pools": [{
            "condition": {"type": "minecraft:survives_explosion"},
            "entries": [{"type": "minecraft:item", "name": f"{mod}:{b}"}],
            "rolls": 1
        }],
        "random_sequence": f"{mod}:blocks/{b}"})

# ---------- mineable/pickaxe tag ----------
import os as _os
tag_dir = f"{D}/../minecraft/tags/block/mineable"
_os.makedirs(tag_dir, exist_ok=True)
tag_blocks = ["lab_table", "microscope", "centrifuge", "incubator", "research_bench", "culture_plate",
              "lab_counter", "lab_cabinet", "lab_wall", "lab_floor", "hazard_stripe"]
w(f"{tag_dir}/pickaxe.json", {"replace": False, "values": [f"{mod}:{b}" for b in tag_blocks]})

# ---------- languages ----------
en = {
    "itemGroup.pathogen_protocol.pathogen_protocol": "Pathogen Protocol",
    "item.pathogen_protocol.empty_vial": "Empty Vial",
    "item.pathogen_protocol.empty_syringe": "Syringe",
    "item.pathogen_protocol.culture_medium": "Culture Medium",
    "item.pathogen_protocol.pathogen_protein": "Pathogen Protein",
    "item.pathogen_protocol.antibiotics": "Antibiotics",
    "item.pathogen_protocol.serum": "Engineered Serum",
    "item.pathogen_protocol.genome_fragment": "Genome Fragment",
    "item.pathogen_protocol.hazmat_repair_kit": "Hazmat Repair Kit",
    "item.pathogen_protocol.hazmat_suit": "Sealed Hazmat Suit",
    "item.pathogen_protocol.broken_hazmat_suit": "Torn Hazmat Suit",
    "item.pathogen_protocol.virus_vial": "Virus Sample",
    "item.pathogen_protocol.virus_syringe": "Loaded Syringe",
    "item.pathogen_protocol.pathogen_probe": "Pathogen Probe",
    "item.pathogen_protocol.sterile_swab": "Sterile Swab",
    "block.pathogen_protocol.lab_table": "Field Laboratory Table",
    "block.pathogen_protocol.microscope": "Electron Microscope",
    "block.pathogen_protocol.centrifuge": "Centrifuge",
    "block.pathogen_protocol.incubator": "Virus Incubator",
    "block.pathogen_protocol.research_bench": "Research Bench",
    "block.pathogen_protocol.culture_plate": "Culture Plate",
    "block.pathogen_protocol.lab_counter": "Laboratory Counter",
    "block.pathogen_protocol.lab_cabinet": "Specimen Cabinet",
    "block.pathogen_protocol.lab_wall": "Laboratory Wall Panel",
    "block.pathogen_protocol.lab_floor": "Laboratory Floor Tile",
    "block.pathogen_protocol.hazard_stripe": "Biohazard Hazard Stripe",
    "effect.pathogen_protocol.viral_infection": "Viral Infection",
}
de = dict(en)
de.update({
    "itemGroup.pathogen_protocol.pathogen_protocol": "Pathogen Protocol",
    "item.pathogen_protocol.empty_vial": "Leeres Fläschchen",
    "item.pathogen_protocol.empty_syringe": "Spritze",
    "item.pathogen_protocol.culture_medium": "Nährboden",
    "item.pathogen_protocol.pathogen_protein": "Pathogen-Protein",
    "item.pathogen_protocol.antibiotics": "Antibiotika",
    "item.pathogen_protocol.serum": "Technisches Serum",
    "item.pathogen_protocol.genome_fragment": "Genom-Fragment",
    "item.pathogen_protocol.hazmat_repair_kit": "Hazmat-Reparaturset",
    "item.pathogen_protocol.hazmat_suit": "Versiegelter Hazmat-Anzug",
    "item.pathogen_protocol.broken_hazmat_suit": "Zerrissener Hazmat-Anzug",
    "item.pathogen_protocol.virus_vial": "Virusprobe",
    "item.pathogen_protocol.virus_syringe": "Geladene Spritze",
    "item.pathogen_protocol.pathogen_probe": "Pathogen-Probe",
    "item.pathogen_protocol.sterile_swab": "Steril-Tupfer",
    "block.pathogen_protocol.lab_table": "Feldlabor-Tisch",
    "block.pathogen_protocol.microscope": "Elektronenmikroskop",
    "block.pathogen_protocol.centrifuge": "Zentrifuge",
    "block.pathogen_protocol.incubator": "Virusinkubator",
    "block.pathogen_protocol.research_bench": "Forschungstisch",
    "block.pathogen_protocol.culture_plate": "Nährschale",
    "block.pathogen_protocol.lab_counter": "Labortresen",
    "block.pathogen_protocol.lab_cabinet": "Probenkabinett",
    "block.pathogen_protocol.lab_wall": "Labor-Wandverkleidung",
    "block.pathogen_protocol.lab_floor": "Labor-Bodenfliesen",
    "block.pathogen_protocol.hazard_stripe": "Biogefahren-Markierung",
    "effect.pathogen_protocol.viral_infection": "Virusinfektion",
})
w(f"{A}/lang/en_us.json", en)
w(f"{A}/lang/de_de.json", de)
print("json done")

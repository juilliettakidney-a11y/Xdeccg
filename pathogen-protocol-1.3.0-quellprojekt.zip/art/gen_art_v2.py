#!/usr/bin/env python3
"""
Pathogen Protocol — v1.2 art overhaul.
Smooth 16x16 vanilla-style sprites: per-pixel gradient ramps with Bayer-dither
transitions, auto-outlines and specular accents instead of flat fills.
"""
from PIL import Image, ImageDraw
import math, os, random

OUT = "/home/user/pathogen-protocol/src/main/resources/assets/pathogen_protocol"
random.seed(20261120)

def rgb(c): return (int(c[0]), int(c[1]), int(c[2]))
def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3)) + (255,)

BAYER = ((0, 8, 2, 10), (12, 4, 14, 6), (3, 11, 1, 9), (15, 7, 13, 5))

def ramp_color(stops, t, x=0, y=0, dither=True):
    """stops: [(pos0..1, rgb)]. Dithers between adjacent stops with a 4x4 Bayer map."""
    t = max(0.0, min(1.0, t))
    for i in range(len(stops) - 1):
        p0, c0 = stops[i]; p1, c1 = stops[i + 1]
        if t <= p1 or i == len(stops) - 2:
            frac = 0.0 if p1 == p0 else (t - p0) / (p1 - p0)
            frac = max(0.0, min(1.0, frac))
            if dither and 0.02 < frac < 0.98:
                return mix(c0, c1, 1.0 if BAYER[y & 3][x & 3] / 16.0 < frac else 0.0)
            return mix(c0, c1, frac)
    return stops[-1][1] + (255,)

def img(size=16):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)

def grad(im, box, stops, vertical=True, dither=True):
    x0, y0, x1, y1 = box
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            t = (y - y0) / max(1, (y1 - y0)) if vertical else (x - x0) / max(1, (x1 - x0))
            im.putpixel((x, y), ramp_color(stops, t, x, y, dither))

def disc(im, cx, cy, rx, ry, color_fn):
    for y in range(max(0, int(cy - ry)), min(im.height, int(cy + ry) + 1)):
        for x in range(max(0, int(cx - rx)), min(im.width, int(cx + rx) + 1)):
            nx = (x - cx) / rx; ny = (y - cy) / ry
            if nx * nx + ny * ny <= 1.0:
                im.putpixel((x, y), color_fn(x, y, nx, ny))

def noise(im, box, amount=14, seed=1, keep_alpha=True):
    rng = random.Random(seed)
    x0, y0, x1, y1 = box
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            p = im.getpixel((x, y))
            if p[3] == 0:
                continue
            d = rng.randint(-amount, amount)
            im.putpixel((x, y), tuple(max(0, min(255, c + d)) for c in p[:3]) + (p[3],))

def auto_outline(im, color=(17, 17, 22, 255)):
    src = im.copy()
    w, h = im.size
    for y in range(h):
        for x in range(w):
            if src.getpixel((x, y))[3] != 0:
                continue
            for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and 0 <= ny < h and src.getpixel((nx, ny))[3] != 0:
                    im.putpixel((x, y), color)
                    break

def save(im, rel):
    path = f"{OUT}/{rel}"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    im.save(path)

# Ramps (dark -> light)
GLASS   = [(0.0,(64,84,96)),(0.5,(150,186,196)),(1.0,(232,246,250))]
GLASS_HI= (255,255,255)
STEEL   = [(0.0,(74,84,96)),(0.5,(176,186,198)),(1.0,(240,244,250))]
STEEL_D = [(0.0,(40,46,56)),(0.5,(110,120,133)),(1.0,(180,190,202))]
AMBER   = [(0.0,(120,64,12)),(0.5,(224,140,48)),(1.0,(252,214,130))]
ACID    = [(0.0,(42,84,18)),(0.5,(150,224,64)),(1.0,(228,255,150))]
CYAN    = [(0.0,(14,96,88)),(0.5,(64,214,196)),(1.0,(190,255,244))]
WHITE   = [(0.0,(168,168,176)),(0.5,(232,232,238)),(1.0,(255,255,255))]
CREAM   = [(0.0,(206,206,210)),(0.55,(240,240,242)),(1.0,(255,255,255))]
GOLD    = [(0.0,(140,110,26)),(0.5,(236,202,92)),(1.0,(255,244,176))]
PANEL   = [(0.0,(24,27,36)),(0.5,(46,50,64)),(1.0,(78,86,108))]
PINK    = [(0.0,(150,58,88)),(0.5,(232,124,158)),(1.0,(255,198,214))]
YELLOW  = [(0.0,(172,138,20)),(0.5,(232,190,42)),(1.0,(255,234,128))]
OLIVE   = [(0.0,(94,86,44)),(0.5,(152,140,72)),(1.0,(214,204,128))]
WOOD    = [(0.0,(74,46,22)),(0.5,(122,80,38)),(1.0,(176,124,66))]
TILE    = [(0.0,(128,128,136)),(0.5,(196,196,204)),(1.0,(236,236,242))]

def vial(kind):
    im, d = img()
    grad(im, (6,1,9,3), STEEL_D)                      # cap
    grad(im, (5,4,10,4), GLASS)                       # neck ridge
    grad(im, (4,5,11,14), GLASS)                      # body
    if kind == "virus":
        grad(im, (5,8,10,14), ACID)                   # culture fill
        noise(im, (5,8,10,14), 10, 7)
    elif kind == "serum":
        grad(im, (5,8,10,14), GOLD)                   # serum fill
    # soften edges into diagonal corners
    for (x,y) in [(4,5),(11,5),(4,14),(11,14)]:
        im.putpixel((x,y), (0,0,0,0))
    # inner shading
    for y in range(6, 14):
        im.putpixel((5,y), mix((150,186,196),(64,84,96),0.35))
        im.putpixel((10,y), mix((150,186,196),(255,255,255),0.25))
    # highlights
    for y in (6,7,8,9):
        im.putpixel((6,y), GLASS_HI)
    if kind == "virus":
        noise(im, (5,8,10,13), 18, 11)
        for (x,y) in [(6,11),(9,10),(8,12)]: im.putpixel((x,y), (240,255,190,255))
        for (x,y) in [(7,13),(10,9)]: im.putpixel((x,y), (42,84,18,255))
    if kind == "serum":
        red = (200,52,52,255)
        for y in (9,10,11): im.putpixel((7,y), red); im.putpixel((8,y), red)
        im.putpixel((6,10), red); im.putpixel((9,10), red)
    auto_outline(im)
    return im

def syringe(loaded):
    im, d = img()
    grad(im, (4,0,11,1), STEEL)                       # thumb plate — full width
    for x in (4,11): im.putpixel((x,0), ramp_color(STEEL_D, 0.2, x, 0))
    for y in range(2,4):
        for x in (7,8): im.putpixel((x,y), ramp_color(STEEL_D, (y-2)/2.0, x, y))
    grad(im, (5,4,10,11), GLASS)                      # barrel
    for (x,y) in [(5,4),(10,4)]: im.putpixel((x,y),(0,0,0,0))
    for y in range(5,11):                              # barrel inner shadow, both sides
        im.putpixel((5,y), (110,128,140,255)); im.putpixel((10,y), (200,216,224,255))
    grad(im, (4,11,11,11), STEEL)                     # flange
    for y in range(12,15):
        im.putpixel((7,y), ramp_color(STEEL_D,(y-12)/3.0,7,y)); im.putpixel((8,y), ramp_color(STEEL_D,(y-12)/3.0,8,y))
    im.putpixel((8,15), (255,255,255,255))            # needle bevel
    im.putpixel((7,14), (240,244,250,255))
    if loaded:
        grad(im, (6,7,9,11), ACID)                    # virus culture
        noise(im, (6,7,9,11), 12, 5)
        im.putpixel((7,8), (240,255,190,255))
    for y in (5,6):
        im.putpixel((6,y), GLASS_HI)
    auto_outline(im)
    return im

def swab(soiled):
    im, d = img()
    for i in range(11):                                # diagonal shaft
        t = i / 10.0
        im.putpixel((3+i, 12-i), ramp_color(STEEL, t, 3+i, 12-i))
    im.putpixel((2,13), (110,120,133,255))
    # cotton bud tip
    tip = ACID if soiled else WHITE
    tipdark = (42,84,18,255) if soiled else (150,150,158,255)
    for (x,y) in [(11,3),(12,2),(13,2),(12,3),(13,3),(12,1),(13,1)]:
        im.putpixel((x,y), ramp_color(tip, (x+y)/26.0, x, y))
    im.putpixel((13,1), tipdark)
    if soiled:
        im.putpixel((12,2), (228,255,150,255))
        im.putpixel((11,3), (64,120,24,255))
    else:
        im.putpixel((12,2), (255,255,255,255))
    auto_outline(im)
    return im

# ---------------- ITEM SPRITES ----------------
save(vial("empty"), "textures/item/empty_vial.png")
save(vial("virus"), "textures/item/virus_vial.png")
save(vial("serum"), "textures/item/serum.png")
save(syringe(False), "textures/item/empty_syringe.png")
save(syringe(True),  "textures/item/virus_syringe.png")
save(swab(False), "textures/item/sterile_swab.png")
save(swab(True),  "textures/item/pathogen_probe.png")

# genome fragment
im, d = img()
for y in (5,8,11):                                     # pins
    for x in (1,2,13,14):
        im.putpixel((x,y), ramp_color(GOLD, (x%3)/3.0, x, y))
grad(im, (3,3,12,13), PANEL)
for (x,y) in [(6,6),(9,6),(7,8),(8,8),(6,10),(9,10)]:
    im.putpixel((x,y), ramp_color(CYAN, 0.7, x, y))
im.putpixel((7,7), ramp_color(CYAN, 0.35, 7, 7)); im.putpixel((8,9), ramp_color(CYAN, 0.35, 8, 9))
im.putpixel((11,4), ramp_color(GOLD, 1.0, 11, 4)); im.putpixel((4,12), ramp_color(GOLD, 0.8, 4, 12))
noise(im, (3,3,12,13), 8, 21)
auto_outline(im)
save(im, "textures/item/genome_fragment.png")

# culture medium — petri dish, top-down
im, d = img()
def dish(x, y, nx, ny):
    t = math.hypot(nx, ny)
    if t > 0.78:  return ramp_color(GLASS, 1.0 - t*0.6, x, y)              # glass rim
    return ramp_color(AMBER, 0.95 - t*0.5, x, y)                           # gel
disc(im, 7.5, 8.5, 6.6, 5.6, dish)
disc(im, 7.5, 8.0, 5.2, 4.3, lambda x,y,nx,ny: ramp_color(AMBER, 0.9+0.2*(1-ny), x, y))
for (x,y) in [(5,7),(9,9),(7,10),(10,6),(6,9)]: im.putpixel((x,y), (252,214,130,255))
im.putpixel((8,8), (120,64,12,255)); im.putpixel((4,9), (120,64,12,255))
for (x,y) in [(5,6),(6,5)]: im.putpixel((x,y), (255,246,200,255))       # specular arc
noise(im, (2,4,13,12), 10, 31)
auto_outline(im)
save(im, "textures/item/culture_medium.png")

# pathogen protein — glossy blob
im, d = img()
blob = [(6,5),(7,5),(8,5),(9,5),(5,6),(10,6),(4,7),(11,7),(3,8),(12,8),
        (3,9),(12,9),(3,10),(12,10),(4,11),(11,11),(5,12),(10,12),(6,13),(7,13),(8,13),(9,13)]
for (x,y) in blob: im.putpixel((x,y), ramp_color(PINK, (y-5)/9.0, x, y))
for y in range(6,13):
    for x in range(4,12):
        if im.getpixel((x,y))[3] == 0: im.putpixel((x,y), ramp_color(PINK, (y-5)/9.0, x, y))
noise(im, (3,5,12,13), 14, 17)
for (x,y) in [(6,7),(9,8),(5,9),(10,10),(7,11),(8,6)]: im.putpixel((x,y), (150,58,88,255))
for (x,y) in [(6,8),(7,7),(9,7)]: im.putpixel((x,y), (255,214,226,255))
auto_outline(im)
save(im, "textures/item/pathogen_protein.png")

# antibiotics — white pill bottle
im, d = img()
grad(im, (5,2,10,4), STEEL_D)                          # ridged cap
for x in (6,8,9): im.putpixel((x,2), (180,190,202,255))
grad(im, (4,5,11,14), WHITE)                           # body
for (x,y) in [(4,5),(11,5)]: im.putpixel((x,y),(0,0,0,0))
for y in range(6,14):
    im.putpixel((5,y), (200,200,208,255)); im.putpixel((10,y), (255,255,255,255))
# label
for y in (8,11):
    for x in range(6,10): im.putpixel((x,y), (216,40,40,255))
for x in (6,9):
    for y in (9,10): im.putpixel((x,y), (216,40,40,255))
auto_outline(im)
save(im, "textures/item/antibiotics.png")

# hazmat repair kit — steel case with wrench
im, d = img()
grad(im, (6,3,9,4), STEEL_D)                           # handle
grad(im, (3,5,12,13), STEEL_D)                         # body
for (x,y) in [(3,5),(12,5)]: im.putpixel((x,y),(0,0,0,0))
for y in range(6,13):
    im.putpixel((4,y), ramp_color(STEEL,(y-6)/7.0,4,y)); im.putpixel((11,y), ramp_color(STEEL,(y-6)/7.0,11,y))
noise(im, (3,5,12,13), 8, 13)
# wrench glyph
for (x,y) in [(6,8),(7,9),(8,10),(9,11),(6,11),(7,10),(9,8)]: im.putpixel((x,y), (236,202,92,255))
for (x,y) in [(5,9),(10,10)]: im.putpixel((x,y), (140,110,26,255))
autop = None
auto_outline(im)
save(im, "textures/item/hazmat_repair_kit.png")

# chestplates
def chestplate(patch, ramp, seed):
    im, d = img()
    # pauldrons
    for y in range(4,8):
        for x in range(2,5): im.putpixel((x,y), ramp_color(ramp,(y-4)/4.0,x,y))
        for x in range(11,14): im.putpixel((x,y), ramp_color(ramp,(y-4)/4.0,x,y))
    # torso
    for y in range(4,15):
        im.putpixel((4,y), ramp_color(STEEL_D if False else ramp, (y-4)/11.0, 4, y))
        im.putpixel((11,y), ramp_color(ramp, (y-4)/11.0, 11, y))
    for y in range(5,15):
        for x in range(5,11): im.putpixel((x,y), ramp_color(ramp, (y-4)/11.0, x, y))
    # neck shadow
    for x in range(6,10): im.putpixel((x,4), mix((0,0,0,255)[:3]+(255,), ramp[0][1]+(255,), 0.35))
    # zipper
    for y in range(5,15): im.putpixel((7,y), mix(ramp[0][1]+(255,),(20,20,26,255),0.55)); im.putpixel((8,y), mix(ramp[0][1]+(255,),(20,20,26,255),0.7))
    # hazard chevrons
    for i,(x,y) in enumerate([(5,10),(6,9),(9,11),(10,12)]):
        im.putpixel((x,y), (24,24,30,255) if i%2==0 else (255,234,128,255))
    # highlight
    im.putpixel((5,5), mix(ramp[-1][1]+(255,),(255,255,255,255),0.5)); im.putpixel((5,6), mix(ramp[-1][1]+(255,),(255,255,255,255),0.2))
    noise(im, (2,3,13,14), 7, seed)
    if patch:
        for (x,y) in [(6,7),(9,6),(5,12),(10,9),(8,13),(7,9)]: im.putpixel((x,y), (28,26,20,255))
        im.putpixel((4,11), ramp_color(OLIVE, 0.2, 4, 11))
    auto_outline(im)
    return im

save(chestplate(False, YELLOW, 41), "textures/item/hazmat_suit.png")
save(chestplate(True,  OLIVE, 42), "textures/item/broken_hazmat_suit.png")
print("items done")

# ---------------- BLOCK SPRITES ----------------
# microscope
im, d = img()
grad(im, (4,13,11,14), STEEL_D)                        # base
for y in range(13,15):
    im.putpixel((4,y),(0,0,0,0)); im.putpixel((11,y),(0,0,0,0))
for y in range(3,13):                                  # pillar
    c = ramp_color(STEEL_D, (y-3)/10.0, 6, y)
    im.putpixel((6,y), c); im.putpixel((7,y), mix(STEEL_D[0][1]+(255,),(46,50,64,255),0.3))
grad(im, (5,3,10,7), PANEL)                            # body tube
grad(im, (6,1,9,2), STEEL)                             # eyepiece
# objective lens — cyan radial
def lens(x, y, nx, ny):
    t = math.hypot(nx, ny)
    return ramp_color(CYAN, 1.0 - t*0.7, x, y)
disc(im, 7.5, 9.0, 2.6, 2.2, lens)
im.putpixel((7,8), (230,255,250,255))
noise(im, (4,13,11,14), 8, 51)
auto_outline(im)
save(im, "textures/block/microscope.png")

# research bench — sequencing monitor
im, d = img()
grad(im, (2,2,13,10), PANEL)                           # bezel
grad(im, (3,3,12,9), [(0.0,(10,16,22)),(1.0,(18,32,38))])
# screen content: DNA/graph trace
trace = [(4,6),(5,5),(6,6),(7,4),(8,7),(9,5),(10,6),(11,4)]
for (x,y) in trace: im.putpixel((x,y), ramp_color(CYAN, 0.8, x, y))
for (x,y) in [(4,7),(6,8),(8,8),(10,7)]: im.putpixel((x,y), ramp_color(CYAN, 0.3, x, y))
im.putpixel((11,5), (216,64,64,255))                   # rec dot
for x in range(3,13): im.putpixel((x,3), (60,70,92,255))
# stand
grad(im, (6,10,9,12), STEEL_D)
grad(im, (4,12,11,13), STEEL)
auto_outline(im)
save(im, "textures/block/research_bench.png")

# centrifuge — rotor well
im, d = img()
grad(im, (1,1,14,14), STEEL)                           # body
noise(im, (1,1,14,14), 9, 61)
for (x,y) in [(1,1),(14,1),(1,14),(14,14)]: im.putpixel((x,y),(0,0,0,0))
def well(x, y, nx, ny):
    t = math.hypot(nx, ny)
    return ramp_color(STEEL_D, min(1.0, t), x, y)
disc(im, 7.5, 7.5, 5.6, 5.6, well)
disc(im, 7.5, 7.5, 3.6, 3.6, lambda x,y,nx,ny: ramp_color(PANEL, 0.9, x, y))
for ang in range(6):                                   # rotor holes
    a = math.radians(60*ang + 30)
    hx, hy = 7.5 + 2.2*math.cos(a), 7.5 + 2.2*math.sin(a)
    disc(im, hx, hy, 0.75, 0.75, lambda x,y,nx,ny: (10,12,17,255))
disc(im, 7.5, 7.5, 0.9, 0.9, lambda x,y,nx,ny: ramp_color(STEEL, 0.9, x, y))
auto_outline(im)
save(im, "textures/block/centrifuge.png")

# incubator — domed culture tank
im, d = img()
# frame
for x in range(1,15):
    for y in range(2,15):
        im.putpixel((x,y), ramp_color(STEEL, (x-1)/14.0, x, y))
for (x,y) in [(1,2),(14,2),(1,14),(14,14)]: im.putpixel((x,y),(0,0,0,0))
# inner well
grad(im, (3,4,12,12), PANEL)
grad(im, (3,8,12,12), ACID)
noise(im, (3,8,12,12), 16, 71)
for (x,y) in [(5,10),(9,9),(7,11)]: im.putpixel((x,y), (240,255,190,255))
for (x,y) in [(4,12),(11,11)]: im.putpixel((x,y), (42,84,18,255))
# glass dome highlight
for y in range(5,9):
    im.putpixel((4,y), (230,246,250,160+(9-y)*20))
# lid + gauge
grad(im, (5,1,10,2), STEEL_D)
disc(im, 12.5, 3.0, 1.1, 1.1, lambda x,y,nx,ny: ramp_color(AMBER, 0.8, x, y))
auto_outline(im)
save(im, "textures/block/incubator.png")

# culture plate — petri dish, side view
im, d = img()
grad(im, (1,13,14,14), STEEL_D)                        # base
for x in range(1,15): im.putpixel((x,12), (40,46,56,255))
# glass wall
for y in range(4,12):
    im.putpixel((1,y), ramp_color(GLASS, (y-4)/8.0, 1, y)); im.putpixel((14,y), ramp_color(GLASS,(y-4)/8.0,14,y))
# goo
grad(im, (2,8,13,11), ACID)
noise(im, (2,8,13,11), 15, 81)
for (x,y) in [(4,10),(8,9),(11,10),(6,11)]: im.putpixel((x,y), (240,255,190,255))
for (x,y) in [(5,11),(12,9)]: im.putpixel((x,y), (42,84,18,255))
# rim highlight
for x in range(2,14): im.putpixel((x,4), (255,255,255,255))
for x in range(0,16): im.putpixel((x,15), (17,17,22,255))
auto_outline(im)
save(im, "textures/block/culture_plate.png")

# lab table — steel top & bolted side
im, d = img()
grad(im, (0,0,15,15), STEEL)                           # top plate
noise(im, (0,0,15,15), 6, 91)
for x in range(0,16):                                  # brushed seams
    im.putpixel((x,5), mix(STEEL[0][1]+(255,),(60,66,78,255),0.35))
    im.putpixel((x,10), mix(STEEL[0][1]+(255,),(60,66,78,255),0.30))
for (x,y) in [(1,1),(14,1),(1,14),(14,14)]:             # corner bolts
    im.putpixel((x,y), (40,46,56,255))
    for dx,dy in ((0,1),(1,0)):
        pass
save(im, "textures/block/lab_table_top.png")

im, d = img()
for y in range(0,3):                                   # steel trim
    grad(im, (0,y,15,y), STEEL)
for y in range(3,16):                                  # oak body
    for x in range(16): im.putpixel((x,y), ramp_color(WOOD, (y-3)/13.0, x, y))
# inset steel panel
grad(im, (2,5,13,12), STEEL_D)
for (x,y) in [(3,6),(12,6),(3,11),(12,11)]: im.putpixel((x,y), (240,244,250,255))
noise(im, (0,3,15,15), 8, 93)
save(im, "textures/block/lab_table_side.png")
print("blocks part 1 done")

# ---------- NEW DECORATIVE BLOCKS ----------
# lab counter — steel worktop with sink
im, d = img()
grad(im, (0,0,15,15), STEEL)
noise(im, (0,0,15,15), 7, 101)
for (x,y) in [(1,1),(14,1),(1,14),(14,14)]: im.putpixel((x,y), (40,46,56,255))
# sink basin
def basin(x, y, nx, ny):
    t = math.hypot(nx, ny)
    if t > 0.86: return (40,46,56,255)
    return ramp_color(STEEL_D, t*0.9, x, y)
disc(im, 7.5, 9.0, 4.6, 3.6, basin)
disc(im, 7.5, 9.0, 2.4, 1.8, lambda x,y,nx,ny: ramp_color(PANEL, 0.85, x, y))
im.putpixel((7,9), (10,12,17,255)); im.putpixel((8,9), (10,12,17,255))   # drain
# faucet
for y in range(1,5):
    im.putpixel((7,y), ramp_color(STEEL,0.8,7,y)); im.putpixel((8,y), ramp_color(STEEL,0.5,8,y))
im.putpixel((6,3), (240,244,250,255)); im.putpixel((9,3), (180,190,202,255))
save(im, "textures/block/lab_counter_top.png")

# lab counter — cabinet side (drawers)
im, d = img()
grad(im, (0,0,15,2), STEEL)                            # steel edge
grad(im, (0,3,15,15), CREAM)                           # body
for y in (6,11):                                       # drawer seams
    for x in range(1,15): im.putpixel((x,y), ramp_color(CREAM, 0.15, x, y))
for x in range(5,11):                                  # handles
    im.putpixel((x,5), ramp_color(STEEL, 0.9, x, 5))
    im.putpixel((x,10), ramp_color(STEEL, 0.9, x, 10))
for y in range(13,16):                                 # kick plate
    for x in range(16): im.putpixel((x,y), mix((40,46,56,255),(17,17,22,255),(y-13)/3.0))
noise(im, (0,3,15,12), 6, 103)
save(im, "textures/block/lab_counter_side.png")

# lab cabinet — locker with doors
im, d = img()
grad(im, (0,0,15,15), STEEL_D)
# body frame
grad(im, (1,1,14,14), PANEL)
# two doors
for y in range(2,12):
    for x in range(2,7): im.putpixel((x,y), ramp_color(CREAM, (y-2)/10.0, x, y))
    for x in range(9,14): im.putpixel((x,y), ramp_color(CREAM, (y-2)/10.0, x, y))
for x in range(7,9):                                   # center gap
    for y in range(2,12): im.putpixel((x,y), (17,17,22,255))
# handles
im.putpixel((6,7), (240,244,250,255)); im.putpixel((9,7), (240,244,250,255))
# vents
for y in (12,13):
    for x in (3,5,7,9,11): im.putpixel((x,y), (17,17,22,255))
# teal status LED
im.putpixel((13,1), ramp_color(CYAN, 0.9, 13, 1))
noise(im, (1,1,14,14), 5, 105)
autop = None
save(im, "textures/block/lab_cabinet.png")

# lab wall — hygienic wall panels
im, d = img()
grad(im, (0,0,15,15), CREAM)
for x in (0,8):                                        # panel seams
    for y in range(16):
        im.putpixel((x,y), ramp_color(CREAM, 0.15, x, y))
# grout highlight beside seams
for x in (1,9):
    for y in range(16):
        p = im.getpixel((x,y)); im.putpixel((x,y), mix(CREAM[-1][1]+(255,),(255,255,255,255),0.35))
# rivets at seam intersections
for (x,y) in [(0,0),(8,0),(0,8),(8,8),(0,15),(8,15)]:
    im.putpixel((x,y), (150,150,158,255))
noise(im, (0,0,15,15), 6, 107)
save(im, "textures/block/lab_wall.png")

# lab floor — ceramic tiles with grout
im, d = img()
grad(im, (0,0,15,15), TILE)
for y in range(16):                                    # grout lines
    for x in range(16):
        if x in (0,8) or y in (0,8):
            im.putpixel((x,y), mix(TILE[0][1]+(255,),(70,70,76,255),0.55))
        elif x in (1,9) or y in (1,9):
            p = im.getpixel((x,y)); im.putpixel((x,y), mix(TILE[-1][1]+(255,),(255,255,255,255),0.5))
noise(im, (0,0,15,15), 12, 109)
for (x,y) in [(4,4),(12,12),(12,4),(4,12)]:             # faint bio specks
    im.putpixel((x,y), (150,190,150,120))
save(im, "textures/block/lab_floor.png")

# hazard stripe — diagonal warning bands
im, d = img()
YEL = (238, 200, 54); BLK = (26, 26, 30)
for y in range(16):
    for x in range(16):
        v = (x - y) % 12
        t = 1.0 if v < 6 else 0.0
        # slight wear noise
        rng = random.Random((x*31 + y*17) ^ 0x5bd)
        wob = 0.06 * (rng.random() - 0.5)
        col = mix(BLK, YEL, t)
        if rng.random() < 0.05:
            col = mix(col, (150,150,158), 0.35)          # scuff
        im.putpixel((x, y), min(col, (255,255,255,255)) if False else tuple(int(v) for v in (col[0],col[1],col[2],255)))
# top/bottom edge AO
for x in range(16):
    im.putpixel((x,0), mix(im.getpixel((x,0))[:3]+(255,),(17,17,22,255),0.4))
    im.putpixel((x,15), mix(im.getpixel((x,15))[:3]+(255,),(17,17,22,255),0.5))
save(im, "textures/block/hazard_stripe.png")
print("decor blocks done")

# ---------- EQUIPMENT LAYERS (64x32) ----------
def armor_layer(base, dark, light, broken, seed):
    im = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    rng = random.Random(seed)
    # global smooth vertical gradient
    for y in range(32):
        for x in range(64):
            t = y / 31.0
            c = ramp_color([(0.0, light), (0.45, base), (1.0, dark)], t, x, y)
            im.putpixel((x, y), c)
    # noise speckle
    for y in range(32):
        for x in range(64):
            n = rng.randint(-9, 9)
            p = im.getpixel((x, y))
            im.putpixel((x, y), tuple(max(0, min(255, c + n)) for c in p[:3]) + (255,))
    # waist band (matches prior layout at y 16..18)
    for y in (16, 17):
        for x in range(64):
            im.putpixel((x, y), mix(dark, (17, 17, 22), 0.45))
    # chest strap + hazard chevrons in lower region
    for x in range(64):
        if 22 <= x <= 41:
            for y in (23, 26):
                im.putpixel((x, y), mix(dark, (17, 17, 22), 0.35))
    for x in range(24, 40, 4):
        for y in (24, 25):
            im.putpixel((x, y), (238, 200, 54, 255) if (x // 4) % 2 == 1 else (26, 26, 30, 255))
    if broken:
        # scratches + tears
        for i in range(7):
            x0 = rng.randint(2, 60); y0 = rng.randint(2, 29)
            dx = rng.choice([-1, 1])
            for k in range(rng.randint(3, 6)):
                sx, sy = x0 + k * dx, y0 + k
                if 0 <= sx < 64 and 0 <= sy < 32:
                    im.putpixel((sx, sy), (30, 28, 22, 255))
        for (x, y) in [(12, 8), (30, 13), (46, 20), (20, 25), (52, 10)]:
            im.putpixel((x, y), (17, 17, 22, 255)); im.putpixel((x + 1, y), (17, 17, 22, 255))
    return im

H_LIGHT = (255, 234, 128); H_BASE = (232, 190, 42); H_DARK = (140, 108, 16)
O_LIGHT = (214, 204, 128); O_BASE = (152, 140, 72); O_DARK = (88, 80, 40)

armor_layer(H_BASE, H_DARK, H_LIGHT, False, 131).save(f"{OUT}/textures/entity/equipment/humanoid/hazmat.png")
armor_layer(H_BASE, H_DARK, H_LIGHT, False, 132).save(f"{OUT}/textures/entity/equipment/humanoid_leggings/hazmat.png")
armor_layer(H_BASE, H_DARK, H_LIGHT, False, 133).save(f"{OUT}/textures/entity/equipment/humanoid_baby/hazmat.png")
armor_layer(O_BASE, O_DARK, O_LIGHT, True, 134).save(f"{OUT}/textures/entity/equipment/humanoid/hazmat_broken.png")
armor_layer(O_BASE, O_DARK, O_LIGHT, True, 135).save(f"{OUT}/textures/entity/equipment/humanoid_leggings/hazmat_broken.png")
armor_layer(O_BASE, O_DARK, O_LIGHT, True, 136).save(f"{OUT}/textures/entity/equipment/humanoid_baby/hazmat_broken.png")
print("armor done")

# ---------- MOB EFFECT ICON (18x18) ----------
im = Image.new("RGBA", (18, 18), (0, 0, 0, 0))
cx = cy = 8.5
for y in range(18):
    for x in range(18):
        nx, ny = x - cx, y - cy
        r = math.hypot(nx, ny)
        if r <= 8.2:
            t = min(1.0, r / 8.2)
            c = ramp_color([(0.0,(255,226,120)),(0.55,(240,204,74)),(1.0,(120,96,16))], t, x, y)
            if r > 6.6: c = ramp_color(GOLD, 1.0 - (r-6.6)/2.2, x, y)   # ring
            elif r > 5.2: c = ramp_color([(0.0,(60,46,8)),(1.0,(30,24,4))], 0.2, x, y)  # inner disc
            im.putpixel((x, y), c)
# three blades
for k in range(3):
    a = math.radians(90 + 120 * k)
    bx, by = cx + 3.1 * math.cos(a), cy - 3.1 * math.sin(a)
    for y in range(18):
        for x in range(18):
            if math.hypot(x - bx, y - by) <= 3.15:
                p = im.getpixel((x, y))
                if p[3] and math.hypot(x - cx, y - cy) > 2.1:
                    im.putpixel((x, y), (30, 24, 4, 255))
# core
disc(im, cx, cy, 1.35, 1.35, lambda x, y, nx, ny: ramp_color(GOLD, 0.9, x, y))
disc(im, cx, cy, 0.55, 0.55, lambda x, y, nx, ny: (30, 24, 4, 255))
save(im, "textures/mob_effect/viral_infection.png")
print("effect icon done")

# ---------- MOD ICON (128x128) ----------
S = 128
im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
cx = cy = 63.5
for y in range(S):
    for x in range(S):
        nx, ny = x - cx, y - cy
        r = math.hypot(nx, ny)
        if r <= 62:
            # black disc w/ radial shading
            t = min(1.0, r / 62.0)
            base = ramp_color([(0.0,(22,22,27)),(0.75,(32,32,38)),(1.0,(44,44,52))], t, x, y)
            if r > 52.5:  # gold ring, beveled
                rt = (r - 52.5) / 9.5
                hi = math.cos(math.radians((math.atan2(ny, nx) * 180 / math.pi) + 90)) * 0.5 + 0.5
                base = ramp_color(GOLD, 1.0 - rt * 0.45 - hi * 0.25, x, y)
            im.putpixel((x, y), base)
# trefoil: three lobes + center
for k in range(3):
    a = math.radians(90 + 120 * k)
    bx, by = cx + 15.5 * math.cos(a), cy - 15.5 * math.sin(a)
    for y in range(S):
        for x in range(S):
            if math.hypot(x - bx, y - by) <= 14.5:
                r = math.hypot(x - cx, y - cy)
                if r > 9.5:
                    t = min(1.0, math.hypot(x - bx, y - by) / 14.5)
                    hi = math.cos(math.radians((math.atan2(y - by, x - bx) * 180 / math.pi) + 135)) * 0.5 + 0.5
                    im.putpixel((x, y), ramp_color(GOLD, 1.0 - t * 0.35 - hi * 0.3, x, y))
disc(im, cx, cy, 8.6, 8.6, lambda x, y, nx, ny: ramp_color(GOLD, 0.95, x, y))
disc(im, cx, cy, 4.2, 4.2, lambda x, y, nx, ny: ramp_color([(0.0,(30,24,4)),(1.0,(64,52,10))], 0.3, x, y))
# subtle top-light rim
for y in range(S):
    for x in range(S):
        nx, ny = x - cx, y - cy
        r = math.hypot(nx, ny)
        if 57 < r <= 62 and ny < 0:
            p = im.getpixel((x, y))
            im.putpixel((x, y), mix(p[:3], (255, 246, 190), 0.35))
im.save(f"{OUT}/icon.png")
print("icon done")

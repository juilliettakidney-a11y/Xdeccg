#!/usr/bin/env python3
"""Generates all textures for Pathogen Protocol (16x16 items/blocks, 64x32 armor, 18x18 effect, 128x128 icon)."""
from PIL import Image, ImageDraw
import math, os

OUT = "/home/user/pathogen-protocol/src/main/resources/assets/pathogen_protocol"
os.makedirs(OUT + "/textures/item", exist_ok=True)
os.makedirs(OUT + "/textures/block", exist_ok=True)
os.makedirs(OUT + "/textures/mob_effect", exist_ok=True)
os.makedirs(OUT + "/textures/entity/equipment/humanoid", exist_ok=True)
os.makedirs(OUT + "/textures/entity/equipment/humanoid_baby", exist_ok=True)
os.makedirs(OUT + "/textures/entity/equipment/humanoid_leggings", exist_ok=True)
os.makedirs(OUT + "/textures/entity/equipment/humanoid_baby_leggings", exist_ok=True)

T = {
    "outline": (22, 22, 26, 255),
    "glass": (198, 226, 233, 255),
    "glass_hi": (255, 255, 255, 255),
    "glass_dark": (126, 156, 166, 255),
    "steel": (178, 188, 198, 255),
    "steel_dark": (96, 106, 116, 255),
    "steel_hi": (228, 234, 240, 255),
    "yellow": (232, 200, 50, 255),
    "yellow_dark": (140, 118, 20, 255),
    "yellow_hi": (250, 228, 110, 255),
    "red": (216, 64, 64, 255),
    "red_dark": (140, 31, 31, 255),
    "blue": (63, 140, 224, 255),
    "blue_dark": (31, 78, 140, 255),
    "purple": (155, 76, 224, 255),
    "purple_dark": (90, 31, 140, 255),
    "green": (67, 192, 74, 255),
    "green_dark": (31, 124, 40, 255),
    "pink": (226, 110, 150, 255),
    "pink_dark": (150, 52, 88, 255),
    "gold": (240, 205, 90, 255),
    "gold_dark": (150, 120, 30, 255),
    "cyan": (70, 240, 220, 255),
    "cyan_dark": (20, 120, 110, 255),
    "brown": (96, 66, 40, 255),
    "black": (10, 10, 10, 255),
    "white": (245, 245, 245, 255),
    "amber": (224, 140, 48, 255),
    "amber_dark": (140, 80, 20, 255),
    "wood": (120, 84, 48, 255),
    "wood_dark": (72, 48, 26, 255),
    "leather": (150, 96, 52, 255),
    "dark_panel": (44, 48, 60, 255),
    "dark_panel_hi": (66, 72, 90, 255),
}
virus_colors = {
    "crimson_fever": ("red", "red_dark"),
    "azure_blight": ("blue", "blue_dark"),
    "whispering_pox": ("purple", "purple_dark"),
    "null_rot": ("green", "green_dark"),
}

def img(n, size=16):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)

def save(im, path):
    im.save(path)

def vial(draw, ox, oy, liquid, liquid_dark, scale=1):
    """Draws a vial at pixel offset (ox,oy), 16px art assumed drawn in absolute coords."""
    o = T["outline"]; g = T["glass"]; gh = T["glass_hi"]; gd = T["glass_dark"]
    def P(x, y, c):
        draw.point((ox + x, oy + y), fill=c)
    # neck ring
    for x in range(6, 10): P(x, 1, o)
    P(5, 2, o); P(10, 2, o)
    for x in range(6, 10): P(x, 2, gd)
    P(6, 3, o); P(7, 3, g); P(8, 3, g); P(9, 3, o)
    P(5, 4, o); P(10, 4, o)
    # body
    for y in range(5, 14):
        P(4, y, o); P(11, y, o)
    for y in range(6, 14):
        for x in range(5, 11):
            P(x, y, g)
    P(5, 5, o); P(6, 5, o); P(9, 5, o); P(10, 5, o)
    P(5, 14, o); P(6, 14, o); P(7, 14, o); P(8, 14, o); P(9, 14, o); P(10, 14, o)
    P(5, 13, gd); P(10, 13, gd)
    # liquid
    if liquid:
        lc = T[liquid]; ld = T[liquid_dark]
        for y in range(8, 14):
            for x in range(5, 11):
                P(x, y, lc if y < 12 else ld)
        P(5, 8, ld); P(10, 8, ld)
        # bubbles
        P(6, 11, gh); P(9, 10, gh); P(8, 12, gh)
    # highlight
    P(6, 6, gh); P(6, 7, gh)

def syringe(draw, fluid, fluid_dark, plunger="steel"):
    o = T["outline"]
    g = T["glass"]; gh = T["glass_hi"]; gd = T["glass_dark"]
    pl = T[plunger]
    # needle
    for y in range(12, 16):
        draw.point((7, y) if y < 15 else (7, y), fill=o)
        draw.point((8, y), fill=o)
    # flange
    for x in range(4, 12): draw.point((x, 11), fill=o)
    # barrel
    for y in range(4, 11):
        draw.point((5, y), fill=o); draw.point((10, y), fill=o)
    for y in range(4, 11):
        for x in range(6, 10): draw.point((x, y), fill=g)
    for x in range(5, 11): draw.point((x, 3), fill=o)
    for x in range(5, 11): draw.point((x, 4), fill=o)
    draw.point((6, 4), fill=gd); draw.point((9, 4), fill=gd)
    # fluid in barrel
    if fluid:
        fc = T[fluid]; fd = T[fluid_dark]
        for y in range(7, 11):
            for x in range(6, 10): draw.point((x, y), fill=fc if y < 10 else fd)
        draw.point((7, 8), fill=fd); draw.point((8, 9), fill=fd)
    draw.point((6, 5), fill=gh)
    # plunger
    for y in range(1, 4): draw.point((7, y), fill=o); draw.point((8, y), fill=o)
    for x in range(5, 11): draw.point((x, 0), fill=pl)
    draw.point((5, 0), fill=o); draw.point((10, 0), fill=o)
    for y in range(1, 3): draw.point((6, y), fill=pl); draw.point((9, y), fill=pl)

# ---------- ITEMS ----------
# empty_vial
im, d = img(16); vial(d, 0, 1, None, None); save(im, f"{OUT}/textures/item/empty_vial.png")
# virus vials
for key, (lc, ld) in virus_colors.items():
    im, d = img(16); vial(d, 0, 1, lc, ld); save(im, f"{OUT}/textures/item/virus_vial_{key}.png")
# syringes
im, d = img(16); syringe(d, None, None); save(im, f"{OUT}/textures/item/empty_syringe.png")
for key, (lc, ld) in virus_colors.items():
    im, d = img(16); syringe(d, lc, ld); save(im, f"{OUT}/textures/item/syringe_{key}.png")
# cure syringes (white-gold fluid + colored band)
for key, (lc, ld) in virus_colors.items():
    im, d = img(16)
    syringe(d, "white", "gold")
    c = T[lc]
    d.point((6, 7), fill=c); d.point((9, 7), fill=c)  # virus-tinted ticks on the cure
    save(im, f"{OUT}/textures/item/cure_{key}.png")
# genome chips
for key, (lc, ld) in virus_colors.items():
    im, d = img(16); o = T["outline"]
    lcv = T[lc]; ldv = T[ld]
    # pins
    for y in (5, 8, 11):
        for x in (1, 2, 13, 14): d.point((x, y), fill=T["gold"])
    # board
    for y in range(3, 14):
        for x in range(3, 14): d.point((x, y), fill=T["dark_panel"])
    for x in range(3, 14): d.point((x, 3), fill=o); d.point((x, 13), fill=o)
    for y in range(3, 14): d.point((3, y), fill=o); d.point((13, y), fill=o)
    # DNA helix glyph
    pts = [(6,6),(9,6),(7,8),(8,8),(6,10),(9,10)]
    for (x,y) in pts: d.point((x,y), fill=lcv)
    d.point((7,7), fill=ldv); d.point((8,9), fill=ldv)
    d.point((11,4), fill=T["cyan"]); d.point((4,12), fill=T["cyan"])
    save(im, f"{OUT}/textures/item/genome_{key}.png")
# culture medium (petri dish)
im, d = img(16); o = T["outline"]
for x in range(2, 14): d.point((x, 9), fill=o); d.point((x, 12), fill=o)
for y in range(8, 13): d.point((1, y), fill=o); d.point((14, y), fill=o)
for y in range(9, 12):
    for x in range(2, 14): d.point((x, y), fill=T["amber"])
d.point((5, 10), fill=T["amber_dark"]); d.point((9, 10), fill=T["amber_dark"]); d.point((7, 11), fill=T["amber_dark"]); d.point((11, 11), fill=T["amber_dark"]); d.point((4, 10), fill=T["amber_dark"])
d.point((3, 8), fill=T["glass_hi"]); d.point((4, 8), fill=T["glass_hi"])
save(im, f"{OUT}/textures/item/culture_medium.png")
# antibiotics (pill bottle)
im, d = img(16); o = T["outline"]
for x in range(5, 11): d.point((x, 2), fill=o)
for x in range(4, 12): d.point((x, 3), fill=T["white"] if 5 <= x <= 10 else o)
for x in range(4, 12): d.point((x, 4), fill=o)
for y in range(5, 14):
    d.point((4, y), fill=o); d.point((11, y), fill=o)
for y in range(6, 14):
    for x in range(5, 11): d.point((x, y), fill=T["amber"])
for x in range(5, 11): d.point((x, 14), fill=o)
# white cross label
for y in range(8, 13):
    for x in range(6, 10): d.point((x, y), fill=T["white"])
for y in range(9, 12): d.point((7, y), fill=T["red"]); d.point((8, y), fill=T["red"])
d.point((6, 10), fill=T["red"]); d.point((9, 10), fill=T["red"]); d.point((7, 9), fill=T["white"])
save(im, f"{OUT}/textures/item/antibiotics.png")
# pathogen protein (pink blob)
im, d = img(16); o = T["outline"]
blob = [(6,5),(7,5),(8,5),(9,5),(5,6),(10,6),(4,7),(11,7),(3,8),(12,8),(3,9),(12,9),(3,10),(12,10),(4,11),(11,11),(5,12),(10,12),(6,13),(7,13),(8,13),(9,13)]
for x in range(5, 13): d.point((x, 5), fill=o); d.point((x, 13), fill=o)
for p in blob: d.point(p, fill=o)
for y in range(6, 13):
    for x in range(4, 12):
        d.point((x, y), fill=T["pink"])
for p in [(6,7),(9,8),(5,9),(10,10),(7,11),(8,6)]: d.point(p, fill=T["pink_dark"])
d.point((7, 8), fill=T["glass_hi"]); d.point((6, 9), fill=T["glass_hi"])
save(im, f"{OUT}/textures/item/pathogen_protein.png")
# hazmat suits (chestplate silhouette)
def chestplate(im, d, base, base_dark, base_hi, ripped):
    o = T["outline"]
    # pauldrons
    for y in range(4, 8):
        for x in range(2, 5): d.point((x, y), fill=o)
        for x in range(11, 14): d.point((x, y), fill=o)
    for y in range(5, 8):
        d.point((3, y), fill=base); d.point((12, y), fill=base)
    # torso
    for y in range(4, 15):
        d.point((4, y), fill=o); d.point((11, y), fill=o)
    for y in range(5, 15):
        for x in range(5, 11): d.point((x, y), fill=base)
    for x in range(4, 12): d.point((x, 3), fill=o); d.point((x, 14), fill=o)
    # neck hole
    for x in range(6, 10): d.point((x, 3), fill=o)
    for x in range(7, 9): d.point((x, 4), fill=base_dark)
    # zipper / seams
    for y in range(5, 15): d.point((7, y), fill=base_dark); d.point((8, y), fill=base_dark)
    # hazard stripe diagonally
    for i, (x, y) in enumerate([(5, 10), (6, 9), (9, 11), (10, 12)]):
        d.point((x, y), fill=T["black"] if i % 2 == 0 else T["yellow_hi"])
    # highlight
    d.point((5, 5), fill=base_hi); d.point((5, 6), fill=base_hi)
    if ripped:
        for (x, y) in [(6, 7), (9, 6), (5, 12), (10, 9), (8, 13)]: d.point((x, y), fill=T["black"])
        d.point((4, 11), fill=o); d.point((11, 8), fill=o)
im, d = img(16); chestplate(im, d, T["yellow"], T["yellow_dark"], T["yellow_hi"], False); save(im, f"{OUT}/textures/item/hazmat_suit.png")
im, d = img(16); chestplate(im, d, (170, 160, 90, 255), (90, 82, 30, 255), (200, 192, 120, 255), True); save(im, f"{OUT}/textures/item/broken_hazmat_suit.png")
# hazmat repair kit
im, d = img(16); o = T["outline"]
for x in range(3, 13): d.point((x, 5), fill=o)
for x in range(6, 10): d.point((x, 3), fill=o); d.point((x, 4), fill=o)
for y in range(6, 14):
    d.point((2, y), fill=o); d.point((13, y), fill=o)
for y in range(6, 13):
    for x in range(3, 13): d.point((x, y), fill=T["steel_dark"])
for x in range(3, 13): d.point((x, 13), fill=o)
# wrench glyph
for (x, y) in [(6,8),(7,8),(8,9),(9,10),(6,11),(7,10),(8,8),(9,8)]: d.point((x, y), fill=T["steel_hi"])
d.point((5, 9), fill=T["gold"]); d.point((10, 10), fill=T["gold"])
save(im, f"{OUT}/textures/item/hazmat_repair_kit.png")
print("items done")

#!/usr/bin/env python3
"""New-item & culture-plate art for Pathogen Protocol v1.1 (random genomes)."""
from PIL import Image, ImageDraw
import os

OUT = "/home/user/pathogen-protocol/src/main/resources/assets/pathogen_protocol"
for p in ["textures/item", "textures/block"]:
    os.makedirs(f"{OUT}/{p}", exist_ok=True)

T = {
    "outline": (22, 22, 26, 255),
    "glass": (198, 226, 233, 255),
    "glass_hi": (255, 255, 255, 255),
    "glass_dark": (126, 156, 166, 255),
    "steel": (178, 188, 198, 255),
    "steel_dark": (96, 106, 116, 255),
    "steel_hi": (228, 234, 240, 255),
    "amber": (224, 140, 48, 255),
    "amber_dark": (140, 80, 20, 255),
    "acid": (150, 224, 64, 255),
    "acid_dark": (74, 124, 20, 255),
    "white": (245, 245, 245, 255),
    "gold": (240, 205, 90, 255),
    "gold_dark": (150, 120, 30, 255),
    "cyan": (70, 240, 220, 255),
    "cyan_dark": (20, 120, 110, 255),
    "dark_panel": (44, 48, 60, 255),
    "dark_panel_hi": (66, 72, 90, 255),
}

def img(size=16):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)

def save(im, path):
    im.save(path)

# ---------- virus_vial: unknown strain, sickly glow ----------
im, d = img(); o = T["outline"]; g = T["glass"]; gh = T["glass_hi"]; gd = T["glass_dark"]
for x in range(6, 10): d.point((x, 1), fill=o)
d.point((5, 2), fill=o); d.point((10, 2), fill=o)
for x in range(6, 10): d.point((x, 2), fill=gd)
d.point((6, 3), fill=o); d.point((7, 3), fill=g); d.point((8, 3), fill=g); d.point((9, 3), fill=o)
d.point((5, 4), fill=o); d.point((10, 4), fill=o)
for y in range(5, 14):
    d.point((4, y), fill=o); d.point((11, y), fill=o)
for y in range(6, 14):
    for x in range(5, 11): d.point((x, y), fill=g)
d.point((5, 5), fill=o); d.point((6, 5), fill=o); d.point((9, 5), fill=o); d.point((10, 5), fill=o)
d.point((5, 14), fill=o); d.point((6, 14), fill=o); d.point((7, 14), fill=o); d.point((8, 14), fill=o); d.point((9, 14), fill=o); d.point((10, 14), fill=o)
d.point((5, 13), fill=gd); d.point((10, 13), fill=gd)
for y in range(8, 14):
    for x in range(5, 11): d.point((x, y), fill=T["acid"] if y < 12 else T["acid_dark"])
d.point((5, 8), fill=T["acid_dark"]); d.point((10, 8), fill=T["acid_dark"])
d.point((6, 11), fill=gh); d.point((9, 10), fill=gh); d.point((8, 12), fill=gh)
d.point((6, 6), fill=gh); d.point((6, 7), fill=gh)
save(im, f"{OUT}/textures/item/virus_vial.png")

# ---------- virus_syringe: amber loaded needle ----------
im, d = img(); o = T["outline"]; g = T["glass"]; gh = T["glass_hi"]; gd = T["glass_dark"]
pl = T["steel"]
for y in range(12, 16):
    d.point((7, y), fill=o); d.point((8, y), fill=o)
for x in range(4, 12): d.point((x, 11), fill=o)
for y in range(4, 11):
    d.point((5, y), fill=o); d.point((10, y), fill=o)
for y in range(4, 11):
    for x in range(6, 10): d.point((x, y), fill=g)
for x in range(5, 11): d.point((x, 3), fill=o); d.point((x, 4), fill=o)
d.point((6, 4), fill=gd); d.point((9, 4), fill=gd)
for y in range(7, 11):
    for x in range(6, 10): d.point((x, y), fill=T["amber"] if y < 10 else T["amber_dark"])
d.point((7, 8), fill=T["amber_dark"]); d.point((8, 9), fill=T["amber_dark"])
d.point((6, 5), fill=gh)
for y in range(1, 4): d.point((7, y), fill=o); d.point((8, y), fill=o)
for x in range(5, 11): d.point((x, 0), fill=pl)
d.point((5, 0), fill=o); d.point((10, 0), fill=o)
for y in range(1, 3): d.point((6, y), fill=pl); d.point((9, y), fill=pl)
save(im, f"{OUT}/textures/item/virus_syringe.png")

# ---------- swabs: sterile vs. soiled ----------
def swab(dirty):
    im, d = img(); o = T["outline"]
    # diagonal stick
    for i in range(11):
        d.point((3 + i, 12 - i), fill=T["steel"] if i < 7 else o)
    d.point((2, 13), fill=o)
    # cotton bud
    tip = T["acid"] if dirty else T["white"]
    tip_dark = T["acid_dark"] if dirty else (210, 210, 215, 255)
    for (x, y) in [(11, 3), (12, 2), (13, 2), (12, 3), (13, 3), (12, 1), (13, 1)]:
        d.point((x, y), fill=o)
    for (x, y) in [(12, 2), (13, 2), (12, 3)]:
        d.point((x, y), fill=tip)
    d.point((13, 1), fill=tip_dark)
    return im
save(swab(False), f"{OUT}/textures/item/sterile_swab.png")
save(swab(True), f"{OUT}/textures/item/pathogen_probe.png")

# ---------- genome fragment: decoded chip, cyan core ----------
im, d = img(); o = T["outline"]
for y in (5, 8, 11):
    for x in (1, 2, 13, 14): d.point((x, y), fill=T["gold"])
for y in range(3, 14):
    for x in range(3, 14): d.point((x, y), fill=T["dark_panel"])
for x in range(3, 14): d.point((x, 3), fill=o); d.point((x, 13), fill=o)
for y in range(3, 14): d.point((3, y), fill=o); d.point((13, y), fill=o)
pts = [(6,6),(9,6),(7,8),(8,8),(6,10),(9,10)]
for (x, y) in pts: d.point((x, y), fill=T["cyan"])
d.point((7, 7), fill=T["cyan_dark"]); d.point((8, 9), fill=T["cyan_dark"])
d.point((11, 4), fill=T["gold"]); d.point((4, 12), fill=T["gold"])
save(im, f"{OUT}/textures/item/genome_fragment.png")

# ---------- serum: engineered cure ampoule ----------
im, d = img(); o = T["outline"]; g = T["glass"]; gh = T["glass_hi"]; gd = T["glass_dark"]
for x in range(6, 10): d.point((x, 1), fill=o)
d.point((5, 2), fill=o); d.point((10, 2), fill=o)
for x in range(6, 10): d.point((x, 2), fill=T["gold"])
d.point((6, 3), fill=o); d.point((7, 3), fill=g); d.point((8, 3), fill=g); d.point((9, 3), fill=o)
d.point((5, 4), fill=o); d.point((10, 4), fill=o)
for y in range(5, 14):
    d.point((4, y), fill=o); d.point((11, y), fill=o)
for y in range(6, 14):
    for x in range(5, 11): d.point((x, y), fill=g)
d.point((5, 5), fill=o); d.point((6, 5), fill=o); d.point((9, 5), fill=o); d.point((10, 5), fill=o)
for x in range(5, 11): d.point((x, 14), fill=o)
for y in range(8, 14):
    for x in range(5, 11): d.point((x, y), fill=T["white"] if y < 12 else T["gold"])
d.point((5, 8), fill=T["gold_dark"]); d.point((10, 8), fill=T["gold_dark"])
# cross glyph
for y in range(9, 13): d.point((7, y), fill=(200, 60, 60, 255)); d.point((8, y), fill=(200, 60, 60, 255))
d.point((6, 10), fill=(200, 60, 60, 255)); d.point((9, 10), fill=(200, 60, 60, 255))
d.point((6, 6), fill=gh); d.point((6, 7), fill=gh)
save(im, f"{OUT}/textures/item/serum.png")

# ---------- culture plate block: petri dish seen from the side ----------
im, d = img(); o = T["outline"]
# steel base
for y in range(13, 16):
    for x in range(1, 15): d.point((x, y), fill=T["steel_dark"])
for x in range(1, 15): d.point((x, 12), fill=o)
# glass walls
for y in range(4, 12):
    d.point((1, y), fill=o); d.point((14, y), fill=o)
for y in range(5, 12):
    for x in range(2, 14): d.point((x, y), fill=(180, 210, 220, 60))
# culture goo
for y in range(8, 12):
    for x in range(2, 14): d.point((x, y), fill=T["acid"] if y < 11 else T["acid_dark"])
d.point((4, 10), fill=T["acid_dark"]); d.point((8, 9), fill=T["acid_dark"]); d.point((11, 11), fill=T["acid_dark"]); d.point((6, 11), fill=T["acid_dark"])
# rim highlight
for x in range(2, 14): d.point((x, 4), fill=T["glass_hi"])
d.point((1, 4), fill=o); d.point((14, 4), fill=o)
for x in range(0, 16): d.point((x, 15), fill=o)
d.point((0, 14), fill=o); d.point((15, 14), fill=o)
save(im, f"{OUT}/textures/block/culture_plate.png")

print("new textures done")

package com.pathogen.protocol.client;

import com.mojang.blaze3d.platform.InputConstants;

import com.pathogen.protocol.client.screen.IncubatorScreen;
import com.pathogen.protocol.client.screen.PetriDishScreen;
import com.pathogen.protocol.client.screen.ResearchBenchScreen;
import com.pathogen.protocol.menu.ModMenuTypes;
import com.pathogen.protocol.net.SwabActionPayload;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;

public class PathogenProtocolClient implements ClientModInitializer {
	private static final KeyMapping SWAB_KEY = new KeyMapping(
			"key.pathogen_protocol.swab", InputConstants.KEY_G, KeyMapping.Category.MISC);

	@Override
	public void onInitializeClient() {
		MenuScreens.register(ModMenuTypes.PETRI_DISH, PetriDishScreen::new);
		MenuScreens.register(ModMenuTypes.INCUBATOR, IncubatorScreen::new);
		MenuScreens.register(ModMenuTypes.RESEARCH_BENCH, ResearchBenchScreen::new);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (SWAB_KEY.consumeClick()) {
				if (client.screen == null && client.player != null) {
					ClientPlayNetworking.send(new SwabActionPayload());
				}
			}
		});
	}
}

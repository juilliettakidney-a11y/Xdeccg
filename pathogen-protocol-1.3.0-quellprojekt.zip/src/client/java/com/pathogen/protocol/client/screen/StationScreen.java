package com.pathogen.protocol.client.screen;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;

/**
 * Shared chrome for the laboratory station screens: dark bio-panel, slot
 * frames, label rendering, and a couple of drawing helpers. No textures —
 * everything is drawn, which keeps the client lightweight and portable.
 */
public abstract class StationScreen<M extends AbstractContainerMenu> extends AbstractContainerScreen<M> {
	protected static final int PANEL = 0xFF171B24;
	protected static final int PANEL_EDGE = 0xFF3D4457;
	protected static final int SLOT_BG = 0xFF0D1017;
	protected static final int SLOT_EDGE = 0xFF4A5164;
	protected static final int TEXT = 0xFFE8EAF0;
	protected static final int DIM = 0xFF9AA1B2;
	protected static final int TEAL = 0xFF5CE0C4;
	protected static final int GOLD = 0xFFFFD166;
	protected static final int RED = 0xFFF2555A;
	protected static final int GREEN = 0xFF7DE3A8;

	protected StationScreen(M menu, Inventory inventory, Component title) {
		super(menu, inventory, title);
		this.imageWidth = 176;
		this.imageHeight = 180;
		this.titleLabelX = 10;
		this.titleLabelY = 5;
		this.inventoryLabelX = 8;
		this.inventoryLabelY = 86;
	}

	@Override
	protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
		int x = this.leftPos;
		int y = this.topPos;
		graphics.fill(x, y, x + this.imageWidth, y + this.imageHeight, PANEL);
		graphics.fill(x, y, x + this.imageWidth, y + 1, PANEL_EDGE);
		graphics.fill(x, y + this.imageHeight - 1, x + this.imageWidth, y + this.imageHeight, PANEL_EDGE);
		graphics.fill(x, y, x + 1, y + this.imageHeight, PANEL_EDGE);
		graphics.fill(x + this.imageWidth - 1, y, x + this.imageWidth, y + this.imageHeight, PANEL_EDGE);
		// header divider
		graphics.fill(x + 1, y + 15, x + this.imageWidth - 1, y + 16, PANEL_EDGE);
		// slot frames
		for (Slot slot : this.menu.slots) {
			int sx = x + slot.x - 1;
			int sy = y + slot.y - 1;
			graphics.fill(sx, sy, sx + 18, sy + 18, SLOT_BG);
			graphics.renderOutline(sx, sy, 18, 18, SLOT_EDGE);
		}
		// divider above the player inventory
		graphics.fill(x + 1, y + 94, x + this.imageWidth - 1, y + 95, PANEL_EDGE);
		renderStation(graphics, x, y, mouseX, mouseY);
	}

	/** Station-specific readouts, drawn before the slots themselves. */
	protected abstract void renderStation(GuiGraphics graphics, int x, int y, int mouseX, int mouseY);

	@Override
	protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
		graphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, TEXT, false);
		graphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY, DIM, false);
	}

	protected void bar(GuiGraphics graphics, int x, int y, int width, int height, float progress, int color) {
		float clamped = Math.min(1.0f, Math.max(0.0f, progress));
		graphics.fill(x, y, x + width, y + height, SLOT_BG);
		int filled = Math.round(width * clamped);
		if (filled > 0) {
			graphics.fill(x, y, x + filled, y + height, color);
		}
		graphics.renderOutline(x, y, width, height, SLOT_EDGE);
	}

	protected void buttonPressed(int id) {
		this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, id);
	}

	protected Button stationButton(String label, int index, int x, int y, int width) {
		return Button.builder(Component.literal(label), button -> buttonPressed(index))
				.bounds(x, y, width, 16)
				.build();
	}

	protected static int severityColor(int severity) {
		if (severity >= 8) {
			return RED;
		}
		if (severity >= 5) {
			return GOLD;
		}
		if (severity >= 3) {
			return TEXT;
		}
		return GREEN;
	}

	protected void severityPips(GuiGraphics graphics, int x, int y, int severity, int max) {
		for (int i = 0; i < max; i++) {
			int px = x + i * 8;
			boolean filled = i < severity;
			graphics.fill(px, y, px + 6, y + 5, filled ? severityColor(severity) : SLOT_BG);
			graphics.renderOutline(px, y, 6, 5, SLOT_EDGE);
		}
	}
}

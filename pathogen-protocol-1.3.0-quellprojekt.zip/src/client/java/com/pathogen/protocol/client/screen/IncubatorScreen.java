package com.pathogen.protocol.client.screen;

import com.pathogen.protocol.item.SampleData;
import com.pathogen.protocol.menu.IncubatorMenu;
import com.pathogen.protocol.block.entity.IncubatorBlockEntity;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** The incubator cockpit: temperature dial and feeding telemetry. */
public class IncubatorScreen extends StationScreen<IncubatorMenu> {
	public IncubatorScreen(IncubatorMenu menu, Inventory inventory, Component title) {
		super(menu, inventory, title);
	}

	@Override
	protected void init() {
		super.init();
		int y = this.topPos + 66;
		int x = this.leftPos + 10;
		addRenderableWidget(stationButton("-5", 0, x, y, 26));
		addRenderableWidget(stationButton("-1", 1, x + 30, y, 26));
		addRenderableWidget(stationButton("+1", 2, x + 60, y, 26));
		addRenderableWidget(stationButton("+5", 3, x + 90, y, 26));
		addRenderableWidget(stationButton("37°C", 4, x + 120, y, 38));
	}

	@Override
	protected void renderStation(GuiGraphics graphics, int x, int y, int mouseX, int mouseY) {
		int temp = this.menu.data(IncubatorMenu.DATA_TEMPERATURE);
		int progress = this.menu.data(IncubatorMenu.DATA_PROGRESS);
		int cycleTicks = this.menu.data(IncubatorMenu.DATA_CYCLE);
		int ticksPerCycle = Math.max(1, this.menu.data(IncubatorMenu.DATA_TICKS_PER_CYCLE));
		int deviation = Math.abs(temp - IncubatorBlockEntity.IDEAL_TEMP);

		int textX = x + 36;
		int tempColor = deviation == 0 ? GREEN : deviation <= 4 ? GOLD : deviation <= 8 ? 0xFFFFB3AB : RED;
		float factor = IncubatorBlockEntity.tempFactorFor(temp);
		graphics.drawString(this.font, temp + "°C", textX, y + 19, tempColor, false);
		graphics.drawString(this.font, String.format(java.util.Locale.ROOT, "×%.2f", factor),
				textX + 44, y + 19, DIM, false);
		// feedings
		StringBuilder dots = new StringBuilder("Feedings ");
		for (int i = 0; i < IncubatorBlockEntity.FEEDINGS_PER_HARVEST; i++) {
			dots.append(i < progress ? "●" : "○");
		}
		graphics.drawString(this.font, dots.toString(), textX, y + 30, TEXT, false);
		// cycle progress
		graphics.drawString(this.font, "Cycle", textX, y + 42, DIM, false);
		bar(graphics, textX + 42, y + 43, 66, 6, cycleTicks / (float) ticksPerCycle, TEAL);
		// specimen line
		ItemStack stack = this.menu.getSlot(IncubatorMenu.SLOT_SAMPLE).getItem();
		SampleData.Sample sample = SampleData.read(stack);
		if (sample == null) {
			graphics.drawString(this.font, "idle — load a sample", x + 10, y + 55, DIM, false);
		} else {
			graphics.drawString(this.font, sample.spec().displayName(), x + 10, y + 55, TEAL, false);
		}
	}
}

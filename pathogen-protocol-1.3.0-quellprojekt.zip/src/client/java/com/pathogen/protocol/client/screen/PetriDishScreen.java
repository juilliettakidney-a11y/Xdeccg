package com.pathogen.protocol.client.screen;

import com.pathogen.protocol.item.SampleData;
import com.pathogen.protocol.menu.PetriDishMenu;
import com.pathogen.protocol.VirusSpec;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** The culture dish cockpit: specimen readout and feeding controls. */
public class PetriDishScreen extends StationScreen<PetriDishMenu> {
	public PetriDishScreen(PetriDishMenu menu, Inventory inventory, Component title) {
		super(menu, inventory, title);
	}

	@Override
	protected void init() {
		super.init();
		int y = this.topPos + 66;
		addRenderableWidget(stationButton("Medium", 0, this.leftPos + 13, y, 40));
		addRenderableWidget(stationButton("Carrot", 1, this.leftPos + 58, y, 52));
		addRenderableWidget(stationButton("Harvest", 2, this.leftPos + 115, y, 48));
	}

	@Override
	protected void renderStation(GuiGraphics graphics, int x, int y, int mouseX, int mouseY) {
		ItemStack stack = this.menu.getSlot(PetriDishMenu.SLOT_PLATE).getItem();
		SampleData.Sample sample = SampleData.read(stack);

		int textX = x + 36;
		if (sample == null) {
			graphics.drawString(this.font, "Empty culture dish.", textX, y + 21, DIM, false);
			graphics.drawString(this.font, "Seed it with a virus", textX, y + 33, DIM, false);
			graphics.drawString(this.font, "sample first.", textX, y + 44, DIM, false);
		} else {
			VirusSpec live = sample.liveSpec();
			int severity = this.menu.data(PetriDishMenu.DATA_SEVERITY);
			int fed = this.menu.data(PetriDishMenu.DATA_FED);
			graphics.drawString(this.font, live.displayName(), textX, y + 20, TEAL, false);
			graphics.drawString(this.font, "Severity " + severity + "/" + VirusSpec.MAX_SEVERITY, textX, y + 31, TEXT, false);
			severityPips(graphics, textX, y + 42, severity, VirusSpec.MAX_SEVERITY);
			String spread = switch (live.spread()) {
				case CONTACT -> "Contact";
				case AIRBORNE -> "Airborne";
				case FOOD -> "Foodborne";
			};
			graphics.drawString(this.font, String.format(java.util.Locale.ROOT, "%s · ×%.2f  · feeds %d", spread, live.virulence(), fed),
					textX, y + 51, DIM, false);
		}
	}
}

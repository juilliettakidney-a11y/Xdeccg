package com.pathogen.protocol.client.screen;

import com.pathogen.protocol.item.SampleData;
import com.pathogen.protocol.menu.ResearchBenchMenu;
import com.pathogen.protocol.block.entity.ResearchBenchBlockEntity;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** The research bench cockpit: sequencing progress toward a full decode. */
public class ResearchBenchScreen extends StationScreen<ResearchBenchMenu> {
	public ResearchBenchScreen(ResearchBenchMenu menu, Inventory inventory, Component title) {
		super(menu, inventory, title);
	}

	@Override
	protected void renderStation(GuiGraphics graphics, int x, int y, int mouseX, int mouseY) {
		int textX = x + 36;
		int cycleTicks = this.menu.data(ResearchBenchMenu.DATA_CYCLE);
		int research = this.menu.data(ResearchBenchMenu.DATA_RESEARCH);
		int target = this.menu.data(ResearchBenchMenu.DATA_TARGET);
		boolean decoded = this.menu.data(ResearchBenchMenu.DATA_DECODED) == 1;

		ItemStack stack = this.menu.getSlot(ResearchBenchMenu.SLOT_SAMPLE).getItem();
		SampleData.Sample sample = SampleData.read(stack);
		if (sample == null) {
			graphics.drawString(this.font, "Sequencer idle.", textX, y + 20, DIM, false);
			graphics.drawString(this.font, "Load a sample + medium.", textX, y + 32, DIM, false);
			graphics.drawString(this.font, "Stronger strains demand", textX, y + 48, DIM, false);
			graphics.drawString(this.font, "far more medium.", textX, y + 59, DIM, false);
			return;
		}

		graphics.drawString(this.font, sample.spec().displayName(), textX, y + 20, TEAL, false);
		graphics.drawString(this.font, "Severity " + sample.severity(), textX, y + 31, DIM, false);

		if (decoded) {
			graphics.drawString(this.font, "GENOME DECODED", textX, y + 43, GREEN, false);
			graphics.drawString(this.font, "Engineered Serum unlocked.", textX, y + 54, DIM, false);
		} else {
			int safeTarget = Math.max(1, target);
			graphics.drawString(this.font, "Research", textX, y + 41, DIM, false);
			bar(graphics, textX, y + 51, 106, 7, research / (float) safeTarget, GOLD);
			int pct = Math.min(100, research * 100 / safeTarget);
			graphics.drawString(this.font, research + "/" + safeTarget + " RP (" + pct + "%)",
					textX, y + 62, TEXT, false);
		}
		// cycle progress
		bar(graphics, x + 10, y + 73, 106, 4, cycleTicks / (float) ResearchBenchBlockEntity.CYCLE_TICKS, TEAL);
	}
}

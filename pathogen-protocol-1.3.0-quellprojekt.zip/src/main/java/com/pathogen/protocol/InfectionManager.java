package com.pathogen.protocol;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Core infection logic: application, immunity rules, per-virus symptom pulses,
 * and transmission. Per-host state lives in the entity attachments; the
 * canonical genome ledger lives in the world {@link VirusArchive}.
 */
public final class InfectionManager {
	/** Hard cap on infection strength a hazmat suit can filter. Syringes ignore this entirely. */
	public static final int MAX_SEVERITY = VirusSpec.MAX_SEVERITY;

	private InfectionManager() {
	}

	// -------------------------------------------------------- queries

	public static Infection getInfection(LivingEntity entity) {
		Level level = entity.level();
		if (!(level instanceof ServerLevel serverLevel)) {
			return null;
		}
		MobEffectInstance instance = entity.getEffect(ModEffects.VIRAL_INFECTION);
		if (instance == null) {
			return null;
		}
		String genome = entity.getAttachedOrElse(ModAttachments.GENOME, "");
		if (genome.isEmpty()) {
			entity.removeEffect(ModEffects.VIRAL_INFECTION);
			return null;
		}
		VirusSpec spec = VirusArchive.get(serverLevel).getSpec(genome);
		if (spec == null) {
			// Archive lost this genome (evicted or world data replaced). The illness can't be resolved — lift it.
			entity.removeEffect(ModEffects.VIRAL_INFECTION);
			return null;
		}
		int severity = Math.min(MAX_SEVERITY, Math.max(1, entity.getAttachedOrElse(ModAttachments.SEVERITY, spec.severity())));
		return new Infection(spec, severity);
	}

	public static boolean isHazmatSealed(LivingEntity entity) {
		return entity instanceof Player
				&& entity.getItemBySlot(EquipmentSlot.CHEST).getItem() == ModItems.HAZMAT_SUIT;
	}

	private static boolean isCreativeImmune(Player player) {
		return player.getAbilities().instabuild || player.isSpectator();
	}

	// -------------------------------------------------------- application

	/** Respects normal protection (sealed hazmat suit, creative/spectator). Returns true if infected. */
	public static boolean tryInfect(LivingEntity entity, VirusSpec spec, int severity, LivingEntity source) {
		if (entity instanceof Player player && isCreativeImmune(player)) {
			return false;
		}
		if (isHazmatSealed(entity)) {
			return false;
		}
		if (getInfection(entity) != null) {
			return false;
		}
		forceInfect(entity, spec, severity, source);
		return true;
	}

	/** Bypasses the hazmat suit — for syringes and imposed infections. */
	public static void forceInfect(LivingEntity entity, VirusSpec spec, int severity, Entity source) {
		int clamped = Math.min(MAX_SEVERITY, Math.max(1, severity));
		entity.setAttached(ModAttachments.GENOME, spec.id());
		entity.setAttached(ModAttachments.SEVERITY, clamped);
		boolean recipientIsPlayer = entity instanceof Player;
		entity.addEffect(new MobEffectInstance(
				ModEffects.VIRAL_INFECTION, spec.durationTicks(clamped), 0, false, recipientIsPlayer, recipientIsPlayer), source);
		if (entity instanceof Player player) {
			player.displayClientMessage(Component.literal("§4You feel a creeping, burning chill... §f(" + spec.displayName() + ")"), false);
		}
	}

	/** Removes any viral infection plus its markers. Returns the infection that was lifted. */
	public static Infection cure(LivingEntity entity) {
		Infection current = getInfection(entity);
		if (current == null) {
			return null;
		}
		entity.removeEffect(ModEffects.VIRAL_INFECTION);
		entity.setAttached(ModAttachments.GENOME, "");
		entity.setAttached(ModAttachments.SEVERITY, 1);
		return current;
	}

	/** Called from the damage pipeline: a damager carrying a virus may pass it on. */
	public static void onAfterDamage(LivingEntity victim, DamageSource source) {
		if (!(victim instanceof ServerPlayer player)) {
			return;
		}
		Entity attacker = source.getEntity();
		if (!(attacker instanceof LivingEntity living)) {
			return;
		}
		Infection carrier = getInfection(living);
		if (carrier == null) {
			return;
		}
		VirusSpec spec = carrier.spec();
		float chance;
		if (spec.spread() == VirusSpec.Spread.FOOD) {
			chance = 0.0f;
		} else if (living instanceof Zombie) {
			chance = 0.32f + 0.03f * carrier.severity();
		} else if (living instanceof Player) {
			chance = 0.07f + 0.015f * carrier.severity();
		} else {
			chance = 0.13f + 0.02f * carrier.severity();
		}
		chance = Math.min(chance, 0.6f);
		if (chance <= 0.0f || player.getRandom().nextFloat() >= chance) {
			return;
		}
		if (isHazmatSealed(player)) {
			player.displayClientMessage(Component.literal("§bYour suit's seals hiss — the exposure is filtered out."), false);
			return;
		}
		if (tryInfect(player, spec, carrier.severity(), living)) {
			player.displayClientMessage(Component.literal("§4" + living.getType().getDescription().getString()
					+ " tears you open... §c" + spec.displayName() + " takes hold."), false);
		}
	}

	// -------------------------------------------------------- food-borne reservoir

	/**
	 * The background strain living in the food supply, generated once per world.
	 * Anyone who eats risks exposure; strength gates on the reservoir's severity.
	 */
	public static Infection foodReservoir(ServerLevel level) {
		VirusArchive archive = VirusArchive.get(level);
		VirusSpec spec = archive.getSpec("food_reservoir");
		if (spec == null) {
			spec = VirusSpec.generateFoodReservoir(level.getRandom());
			archive.registerGenome(spec);
		}
		return new Infection(spec, spec.severity());
	}

	// -------------------------------------------------------- per-virus ticking

	public static void tickInfection(ServerLevel level, LivingEntity entity, Infection infection, int remainingTicks) {
		VirusSpec spec = infection.spec();
		int severity = infection.severity();
		int duration = spec.durationTicks(severity);
		int elapsed = Math.max(0, duration - remainingTicks);
		int stage = infection.stage(elapsed);

		// Drifting colored motes betray the infected.
		spawnVirusParticles(level, entity, spec, 4);

		for (VirusSpec.Symptom symptom : spec.symptoms()) {
			int amplifier = Math.min(2, severity / 3);
			switch (symptom) {
				case NAUSEA -> {
					if (entity.getRandom().nextInt(100) < 15) {
						addQuiet(entity, MobEffects.NAUSEA, 100 + 40 * stage, 0);
					}
				}
				case HUNGER -> {
					if (entity.getRandom().nextInt(100) < 20) {
						addQuiet(entity, MobEffects.HUNGER, 140 + 60 * stage, 0);
					}
				}
				case WEAKNESS -> {
					if (stage >= 2 && entity.getRandom().nextInt(100) < 25) {
						addQuiet(entity, MobEffects.WEAKNESS, 160, amplifier);
					}
				}
				case MINING_FATIGUE -> {
					if (stage >= 2 && entity.getRandom().nextInt(100) < 15) {
						addQuiet(entity, MobEffects.MINING_FATIGUE, 220, amplifier);
					}
				}
				case BLINDNESS -> {
					if (stage >= 2 && entity.getRandom().nextInt(100) < 15) {
						addQuiet(entity, MobEffects.BLINDNESS, 90 + 30 * stage, 0);
					}
				}
				case SLOWNESS -> {
					if (entity.getRandom().nextInt(100) < 30) {
						addQuiet(entity, MobEffects.SLOWNESS, 160, Math.min(3, amplifier + (stage >= 3 ? 1 : 0)));
					}
				}
				case WITHER -> {
					if (stage >= 2 && entity.getRandom().nextInt(100) < 25) {
						addQuiet(entity, MobEffects.WITHER, 80 + 20 * stage, 0);
					}
				}
			}
		}

		// Stage 3: the strain feeds on you. (Players only — the corrupted mobs are spared their own.)
		if (stage >= 3 && elapsed % 80 == 0 && entity instanceof Player player) {
			hurt(level, player, infection.stageThreeDamage());
		}

		// Airborne viruses seep into everyone breathing the same air.
		if (spec.spread() == VirusSpec.Spread.AIRBORNE && entity instanceof ServerPlayer spreader
				&& level.getGameTime() % 120 == 0) {
			spreadAirborne(level, spreader, infection);
		}
	}

	private static void spreadAirborne(ServerLevel level, ServerPlayer spreader, Infection infection) {
		VirusSpec spec = infection.spec();
		double radius = infection.effectiveRadius();
		double radiusSq = radius * radius;
		float chance = Math.min(0.3f, 0.12f + 0.025f * infection.severity());
		for (ServerPlayer other : level.getServer().getPlayerList().getPlayers()) {
			if (other == spreader || other.level() != level) {
				continue;
			}
			if (other.distanceToSqr(spreader) > radiusSq) {
				continue;
			}
			if (isCreativeImmune(other) || isHazmatSealed(other)) {
				continue;
			}
			if (getInfection(other) != null) {
				continue;
			}
			if (spreader.getRandom().nextFloat() < chance && tryInfect(other, spec, infection.severity(), spreader)) {
				other.displayClientMessage(Component.literal("§5The air turns sour... §f" + spec.displayName() + " seeps into your lungs."), false);
			}
		}
	}

	private static void spawnVirusParticles(ServerLevel level, LivingEntity entity, VirusSpec spec, int count) {
		double y = entity.getY() + entity.getBbHeight() * 0.6;
		level.sendParticles(new DustParticleOptions(spec.color(), 1.0f),
				entity.getX(), y, entity.getZ(), count, 0.35, 0.35, 0.35, 0.02);
	}

	private static void addQuiet(LivingEntity entity, net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int duration, int amplifier) {
		MobEffectInstance instance = new MobEffectInstance(effect, duration, amplifier, false, false, false);
		entity.addEffect(instance);
	}

	private static void hurt(ServerLevel level, LivingEntity entity, float amount) {
		entity.hurtServer(level, level.damageSources().magic(), amount);
	}

	public static Component tagline(VirusSpec spec) {
		return Component.literal("§f" + spec.displayName());
	}
}

package com.pathogen.protocol;

/**
 * One living thing, one infection: which genome, how strong.
 * Resolved from the entity attachments plus the world archive.
 */
public record Infection(VirusSpec spec, int severity) {

	/** Stage thresholds in ticks since infection began (stage 1/2/3). */
	public int stage(int elapsed) {
		return elapsed < 7200 ? 1 : elapsed < 18000 ? 2 : 3;
	}

	public float stageThreeDamage() {
		return spec.stageThreeDamage(severity);
	}

	public double effectiveRadius() {
		return spec.effectiveRadius(severity);
	}

	public int durationTicks() {
		return spec.durationTicks(severity);
	}
}

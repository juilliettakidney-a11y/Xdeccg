package com.pathogen.protocol;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import net.minecraft.util.RandomSource;
import java.util.Set;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;

/**
 * A procedurally generated pathogen. Every virus in the outbreak is one of
 * these — randomly assembled from a name generator, a color, a transmission
 * vector, a symptom profile and a severity — and persisted per-world in the
 * {@link VirusArchive} so every carrier of the same strain carries the same
 * disease.
 *
 * <p>Viruses never mutate on their own; "strengthening" happens by feeding a
 * sample more and more culture medium at a Culture Plate, which is stored as
 * the sample's current severity rather than as a separate axis. All balance
 * numbers derive from {@code severity} so there is a single dial of doom.</p>
 */
public record VirusSpec(String id, String displayName, int color, Spread spread, double radius,
		int severity, List<Symptom> symptoms, String lore, float virulence) {

	public static final Codec<VirusSpec> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.STRING.fieldOf("id").forGetter(VirusSpec::id),
			Codec.STRING.fieldOf("name").forGetter(VirusSpec::displayName),
			Codec.INT.fieldOf("color").forGetter(VirusSpec::color),
			Codec.STRING.xmap(Spread::valueOf, Spread::name).fieldOf("spread").forGetter(VirusSpec::spread),
			Codec.DOUBLE.fieldOf("radius").forGetter(VirusSpec::radius),
			Codec.INT.fieldOf("severity").forGetter(VirusSpec::severity),
			Codec.STRING.listOf().xmap(list -> list.stream().map(Symptom::valueOf).toList(),
					list -> list.stream().map(Symptom::name).toList()).fieldOf("symptoms").forGetter(VirusSpec::symptoms),
			Codec.STRING.fieldOf("lore").forGetter(VirusSpec::lore),
			Codec.FLOAT.optionalFieldOf("virulence", 1.0f).forGetter(VirusSpec::virulence)
	).apply(instance, VirusSpec::new));

	public enum Spread {
		CONTACT,
		AIRBORNE,
		FOOD
	}

	public enum Symptom {
		NAUSEA,
		HUNGER,
		WEAKNESS,
		MINING_FATIGUE,
		BLINDNESS,
		SLOWNESS,
		WITHER;

		public String label() {
			return switch (this) {
				case NAUSEA -> "Nausea";
				case HUNGER -> "Ravenous hunger";
				case WEAKNESS -> "Weakness";
				case MINING_FATIGUE -> "Lethargy (mining fatigue)";
				case BLINDNESS -> "Blindness";
				case SLOWNESS -> "Slowness";
				case WITHER -> "Tissue withering";
			};
		}
	}

	public static final int MAX_SEVERITY = 10;

	public VirusSpec withSeverity(int newSeverity) {
		return new VirusSpec(id, displayName, color, spread, radius,
				Math.min(MAX_SEVERITY, Math.max(1, newSeverity)), symptoms, lore, virulence);
	}

	/** Returns a copy with the transmission virulence adjusted (clamped 0.6 – 1.8). */
	public VirusSpec withVirulence(float newVirulence) {
		return new VirusSpec(id, displayName, color, spread, radius, severity, symptoms, lore,
				Math.max(0.6f, Math.min(1.8f, newVirulence)));
	}

	/** Returns a copy with the airborne reach / spread range adjusted (never negative). */
	public VirusSpec withRadius(double newRadius) {
		return new VirusSpec(id, displayName, color, spread, Math.max(0.0, newRadius), severity, symptoms, lore, virulence);
	}

	/** Returns a copy with a different symptom profile. */
	public VirusSpec withSymptoms(List<Symptom> newSymptoms) {
		return new VirusSpec(id, displayName, color, spread, radius, severity, newSymptoms, lore, virulence);
	}

	/** Returns a copy with a shifted hue — the strain visibly re-tinted itself. */
	public VirusSpec withColor(int newColor) {
		return new VirusSpec(id, displayName, newColor, spread, radius, severity, symptoms, lore, virulence);
	}

	// ---------------------------------------------------------- balance math

	/** Stage-3 pulse damage every 4 seconds. Severity 10 hits like a truck full of rebar. */
	public float stageThreeDamage(int severity) {
		return 0.5f + 0.75f * (severity - 1);
	}

	/** Infection length scales with severity — the worse the strain, the longer the fight. */
	public int durationTicks(int severity) {
		return 36000 + 4000 * (severity - 1);
	}

	/** Wild samples infect their handlers at this rate; feeding raises it further. */
	public float contactChance(int severity) {
		return Math.min(0.75f, (0.10f + 0.05f * severity) * virulence);
	}

	/** Chance per food item consumed, while the harvest-borne strain hunts the supply chain. */
	public float foodChance(int severity) {
		return Math.min(0.4f, (0.06f + 0.022f * severity) * virulence);
	}

	/** Airborne reach grows when the culture is fed. */
	public double effectiveRadius(int severity) {
		return (radius + 0.4 * (severity - this.severity)) * virulence;
	}

	/** Research points needed to decode. Severity 1 = 4 medium, severity 10 = 31 medium. */
	public int researchTarget(int severity) {
		return 100 + 75 * (severity - 1);
	}

	public String severityBar(int severity) {
		StringBuilder sb = new StringBuilder();
		int filled = Math.min(severity, MAX_SEVERITY);
		for (int i = 0; i < MAX_SEVERITY; i++) {
			sb.append(i < filled ? "▮" : "▯");
		}
		return sb.toString();
	}

	public String dangerLabel(int severity) {
		if (severity <= 1) {
			return "Contained";
		} else if (severity <= 3) {
			return "Serious";
		} else if (severity <= 5) {
			return "Severe";
		} else if (severity <= 7) {
			return "Critical";
		} else if (severity <= 9) {
			return "Catastrophic";
		}
		return "Extinction-class";
	}

	public String colorHex() {
		return String.format("#%06X", color);
	}

	// ---------------------------------------------------------- item-tag codec

	private static final String T_GENOME = "genome";
	private static final String T_NAME = "name";
	private static final String T_COLOR = "color";
	private static final String T_SPREAD = "spread";
	private static final String T_RADIUS = "radius";
	private static final String T_SEVERITY = "severity";
	private static final String T_SYMPTOMS = "symptoms";
	private static final String T_LORE = "lore";
	private static final String T_VIRULENCE = "virulence";

	/** Serializes this specimen into a sample tag, carrying the given current severity. */
	public CompoundTag toTag(int severity) {
		CompoundTag tag = new CompoundTag();
		tag.putString(T_GENOME, id);
		tag.putString(T_NAME, displayName);
		tag.putInt(T_COLOR, color);
		tag.putString(T_SPREAD, spread.name());
		tag.putDouble(T_RADIUS, radius);
		tag.putInt(T_SEVERITY, Math.min(MAX_SEVERITY, Math.max(1, severity)));
		ListTag symptomsTag = new ListTag();
		for (Symptom symptom : symptoms) {
			CompoundTag entry = new CompoundTag();
			entry.putString("symptom", symptom.name());
			symptomsTag.addAndUnwrap(entry);
		}
		tag.put(T_SYMPTOMS, symptomsTag);
		tag.putString(T_LORE, lore);
		tag.putFloat(T_VIRULENCE, virulence);
		return tag;
	}

	/** Reads a sample tag back into a specimen; {@code severity} carries the amplified value. */
	public static VirusSpec fromTag(CompoundTag tag) {
		String id = tag.getStringOr(T_GENOME, "");
		String name = tag.getStringOr(T_NAME, "");
		if (id.isEmpty() || name.isEmpty()) {
			return null;
		}
		try {
			Spread spread = Spread.valueOf(tag.getStringOr(T_SPREAD, "CONTACT"));
			List<Symptom> symptoms = new ArrayList<>();
			ListTag list = tag.getListOrEmpty(T_SYMPTOMS);
			for (int i = 0; i < list.size(); i++) {
				String symptom = list.getCompoundOrEmpty(i).getStringOr("symptom", "");
				if (!symptom.isEmpty()) {
					symptoms.add(Symptom.valueOf(symptom));
				}
			}
			float virulence = Math.max(0.6f, Math.min(1.8f, tag.getFloatOr(T_VIRULENCE, 1.0f)));
			return new VirusSpec(id, name, tag.getIntOr(T_COLOR, 0xFFFFFF), spread,
					tag.getDoubleOr(T_RADIUS, 0.0), tag.getIntOr(T_SEVERITY, 1), symptoms,
					tag.getStringOr(T_LORE, ""), virulence);
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	/** Convenience: current severity stored in the tag (1 when absent). */
	public static int severityOf(CompoundTag tag) {
		return Math.min(MAX_SEVERITY, Math.max(1, tag.getIntOr(T_SEVERITY, 1)));
	}


	// ---------------------------------------------------------- mutation

	public enum Mutation {
		VIRULENCE_UP, VIRULENCE_DOWN, RADIUS_UP, RADIUS_DOWN, SYMPTOM_ADDED, SYMPTOM_LOST, HUE_SHIFT
	}

	/**
	 * Rolls one random mutation into this specimen. The returned pair carries the re-written
	 * spec and a human-readable description for the archive's mutation ledger.
	 */
	public java.util.AbstractMap.SimpleEntry<VirusSpec, String> mutate(net.minecraft.util.RandomSource random) {
		java.util.List<Mutation> pool = new java.util.ArrayList<>();
		pool.add(Mutation.VIRULENCE_UP);
		pool.add(Mutation.VIRULENCE_DOWN);
		if (spread == Spread.AIRBORNE) {
			pool.add(Mutation.RADIUS_UP);
			pool.add(Mutation.RADIUS_DOWN);
		}
		if (symptoms.size() < 5) {
			pool.add(Mutation.SYMPTOM_ADDED);
		}
		if (symptoms.size() > 1) {
			pool.add(Mutation.SYMPTOM_LOST);
		}
		pool.add(Mutation.HUE_SHIFT);

		Mutation pick = pool.get(random.nextInt(pool.size()));
		return switch (pick) {
			case VIRULENCE_UP -> {
				VirusSpec raised = withVirulence(virulence + 0.08f + random.nextFloat() * 0.07f);
				yield new java.util.AbstractMap.SimpleEntry<>(raised,
						String.format("Virulence %.2f → %.2f", virulence, raised.virulence()));
			}
			case VIRULENCE_DOWN -> {
				VirusSpec lowered = withVirulence(virulence - 0.05f - random.nextFloat() * 0.05f);
				yield new java.util.AbstractMap.SimpleEntry<>(lowered,
						String.format("Virulence %.2f → %.2f", virulence, lowered.virulence()));
			}
			case RADIUS_UP -> {
				VirusSpec raised = withRadius(radius + 0.4 + random.nextDouble() * 0.3);
				yield new java.util.AbstractMap.SimpleEntry<>(raised,
						String.format("Airborne reach %.1f → %.1f", radius, raised.radius()));
			}
			case RADIUS_DOWN -> {
				VirusSpec lowered = withRadius(radius - 0.3 - random.nextDouble() * 0.2);
				yield new java.util.AbstractMap.SimpleEntry<>(lowered,
						String.format("Airborne reach %.1f → %.1f", radius, lowered.radius()));
			}
			case SYMPTOM_ADDED -> {
				java.util.List<Symptom> remaining = new java.util.ArrayList<>();
				for (Symptom symptom : Symptom.values()) {
					if (!symptoms.contains(symptom)) {
						remaining.add(symptom);
					}
				}
				if (remaining.isEmpty()) {
					yield new java.util.AbstractMap.SimpleEntry<>(this, "No change (symptom pool exhausted)");
				}
				Symptom added = remaining.get(random.nextInt(remaining.size()));
				java.util.List<Symptom> updated = new java.util.ArrayList<>(symptoms);
				updated.add(added);
				yield new java.util.AbstractMap.SimpleEntry<>(withSymptoms(updated), "Gained symptom: " + added.label());
			}
			case SYMPTOM_LOST -> {
				java.util.List<Symptom> updated = new java.util.ArrayList<>(symptoms);
				Symptom lost = updated.remove(random.nextInt(updated.size()));
				yield new java.util.AbstractMap.SimpleEntry<>(withSymptoms(updated), "Lost symptom: " + lost.label());
			}
			case HUE_SHIFT -> {
				float[] hsb = java.awt.Color.RGBtoHSB((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, null);
				int shifted = java.awt.Color.HSBtoRGB((hsb[0] + 0.08f + random.nextFloat() * 0.1f) % 1.0f, hsb[1], hsb[2]) & 0xFFFFFF;
				yield new java.util.AbstractMap.SimpleEntry<>(withColor(shifted),
						String.format("Hue drift #%06X → #%06X", color, shifted));
			}
		};
	}

	// ---------------------------------------------------------- generation

	private static final String[] PREFIXES = {
			"Ashen", "Cinder", "Gloam", "Pale", "Silent", "Ember", "Umbral", "Verdant",
			"Howling", "Rusting", "Marrow", "Weeping", "Hollow", "Saffron", "Viral", "Null",
			"Porcelain", "Howl", "Crimson", "Ferrous", "Bleak", "Thorned", "Shattered", "Vile"
	};

	private static final String[] ROOTS = {
			"Vexira", "Morosk", "Kharv", "Ostrel", "Thryze", "Belun", "Ostrix", "Quorin",
			"Zagrel", "Ilyx", "Drovven", "Sarka", "Velune", "Orosk", "Thae", "Nymil",
			"Craith", "Ulvox", "Seyros", "Brae"
	};

	private static final String[] VECTOR_SUFFIX = {
			"Blight",   // CONTACT
			"Miasma",   // AIRBORNE
			"Scourge"   // FOOD
	};

	private static final String[] CONTACT_LORE = {
			"Blood, bites and saliva carry it. Gloves are a suggestion; seals are survival.",
			"It rides every scratch and every open wound. Close range is all it needs.",
			"Transmitted by blood-to-blood contact. Anything that once bled can betray you."
	};

	private static final String[] AIRBORNE_LORE = {
			"Every breath is a lottery. It rides the air between you and the infected.",
			"Transmitted through shared air. Masks and sealed suits filter it; lungs do not.",
			"It lingers in the lungs of the afflicted and waits for an inhale."
	};

	private static final String[] FOOD_LORE = {
			"The harvest turned. Every bite is a gamble against the spore.",
			"It breeds in the grain and the butchered meat. Hunger is its vector.",
			"Transmitted by consumption. Nothing you eat is guaranteed clean."
	};


	/** Fully random wild specimen. Severity is weighted toward the survivable end for wild spawns. */
	public static VirusSpec generate(RandomSource random) {
		String id = java.util.UUID.randomUUID().toString().substring(0, 8);

		int severityRoll = random.nextInt(100);
		int wildSeverity;
		if (severityRoll < 42) {
			wildSeverity = 1;
		} else if (severityRoll < 72) {
			wildSeverity = 2;
		} else if (severityRoll < 91) {
			wildSeverity = 3;
		} else {
			wildSeverity = 4;
		}

		int vectorRoll = random.nextInt(100);
		Spread spread;
		double radius = 0.0;
		if (vectorRoll < 45) {
			spread = Spread.CONTACT;
		} else if (vectorRoll < 75) {
			spread = Spread.AIRBORNE;
			radius = 3.5 + random.nextDouble() * 3.5;
		} else {
			spread = Spread.FOOD;
		}

		float hue = random.nextFloat();
		float saturation = 0.55f + random.nextFloat() * 0.3f;
		float brightness = 0.5f + random.nextFloat() * 0.35f;
		int color = java.awt.Color.HSBtoRGB(hue, saturation, brightness) & 0xFFFFFF;

		List<Symptom> symptoms = rollSymptoms(random, wildSeverity);
		String name = PREFIXES[random.nextInt(PREFIXES.length)] + " "
				+ ROOTS[random.nextInt(ROOTS.length)] + " "
				+ VECTOR_SUFFIX[spread.ordinal()];
		String lore = switch (spread) {
			case CONTACT -> CONTACT_LORE[random.nextInt(CONTACT_LORE.length)];
			case AIRBORNE -> AIRBORNE_LORE[random.nextInt(AIRBORNE_LORE.length)];
			case FOOD -> FOOD_LORE[random.nextInt(FOOD_LORE.length)];
		};

		float virulence = 0.9f + random.nextFloat() * 0.3f;
		return new VirusSpec(id, name, color, spread, radius, wildSeverity, symptoms, lore, virulence);
	}

	/** The background strain living in the food supply. Fixed id, generated once per world. */
	public static VirusSpec generateFoodReservoir(RandomSource random) {
		String name = PREFIXES[random.nextInt(PREFIXES.length)] + " "
				+ ROOTS[random.nextInt(ROOTS.length)] + " Scourge";
		List<Symptom> symptoms = rollSymptoms(random, 2);
		return new VirusSpec("food_reservoir", name, 0xC9A13B, Spread.FOOD, 0.0,
				2, symptoms, FOOD_LORE[random.nextInt(FOOD_LORE.length)], 1.0f);
	}

	private static List<Symptom> rollSymptoms(net.minecraft.util.RandomSource random, int severity) {
		Set<Symptom> picked = new HashSet<>();
		Symptom[] mild = {Symptom.NAUSEA, Symptom.HUNGER, Symptom.WEAKNESS, Symptom.MINING_FATIGUE};
		while (picked.size() < 2 + Math.min(severity, 2)) {
			picked.add(mild[random.nextInt(mild.length)]);
		}
		if (severity >= 2) {
			picked.add(random.nextBoolean() ? Symptom.BLINDNESS : Symptom.SLOWNESS);
		}
		if (severity >= 3 && !picked.contains(Symptom.SLOWNESS)) {
			picked.add(Symptom.SLOWNESS);
		}
		if (severity >= 4) {
			picked.add(Symptom.WITHER);
		}
		return new ArrayList<>(picked);
	}
}

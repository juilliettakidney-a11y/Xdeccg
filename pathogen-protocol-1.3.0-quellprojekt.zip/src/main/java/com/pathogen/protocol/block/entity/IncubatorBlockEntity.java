package com.pathogen.protocol.block.entity;

import java.util.List;

import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.VirusArchive;
import com.pathogen.protocol.VirusSpec;
import com.pathogen.protocol.item.SampleData;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * The incubator breeds a loaded culture to splitting maturity. Temperature is
 * the dial that decides how fast: 37 °C is physiologically ideal, and every
 * degree away from it stretches each growth cycle out — push it past the
 * danger zone and the culture barely divides at all.
 *
 * <p>Slots: 0 = virus sample, 1 = culture medium, 2 = harvested vials.</p>
 */
public class IncubatorBlockEntity extends BlockEntity {
	public static final int BASE_CYCLE_TICKS = 100;
	public static final int MAX_MEDIUM = 16;
	public static final int FEEDINGS_PER_HARVEST = 3;
	public static final int YIELD = 2;
	public static final int MIN_TEMP = 20;
	public static final int MAX_TEMP = 45;
	public static final int IDEAL_TEMP = 37;

	public static final int SLOT_SAMPLE = 0;
	public static final int SLOT_MEDIUM = 1;
	public static final int SLOT_OUTPUT = 2;

	private final SimpleContainer inventory = new SimpleContainer(3) {
		@Override
		public void setChanged() {
			super.setChanged();
			IncubatorBlockEntity.this.setChanged();
		}
	};

	private int temperature = IDEAL_TEMP;
	private int progress = 0;
	private int cycleTicks = 0;

	public IncubatorBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.INCUBATOR, pos, state);
	}

	public SimpleContainer inventory() {
		return inventory;
	}

	public int temperature() {
		return temperature;
	}

	public void setTemperature(int celsius) {
		int clamped = Math.max(MIN_TEMP, Math.min(MAX_TEMP, celsius));
		if (clamped != temperature) {
			temperature = clamped;
			setChanged();
		}
	}

	public float tempFactor() {
		return tempFactorFor(temperature);
	}

	/** Growth-rate multiplier for a temperature; 1.7x at ideal (37 °C), floors at 0.15x. */
	public static float tempFactorFor(int celsius) {
		float deviation = Math.abs(celsius - IDEAL_TEMP);
		return Math.max(0.15f, 1.7f - 0.075f * deviation);
	}

	/** Ticks per medium at the current temperature. */
	public int ticksPerCycle() {
		return Math.max(10, Math.round(BASE_CYCLE_TICKS / tempFactor()));
	}

	public int progressCount() {
		return progress;
	}

	public int cycleTicks() {
		return cycleTicks;
	}

	public boolean isLoaded() {
		return SampleData.hasSample(inventory.getItem(SLOT_SAMPLE));
	}

	public SampleData.Sample specimen() {
		return isLoaded() ? SampleData.read(inventory.getItem(SLOT_SAMPLE)) : null;
	}

	public VirusSpec loadedSpec() {
		SampleData.Sample sample = specimen();
		return sample == null ? null : sample.spec();
	}

	public int loadedSeverity() {
		SampleData.Sample sample = specimen();
		return sample == null ? 0 : sample.severity();
	}

	public int mediumCount() {
		return inventory.getItem(SLOT_MEDIUM).getCount();
	}

	// -------------------------------------------------------- ticking

	public static void tick(Level level, BlockPos pos, BlockState state, IncubatorBlockEntity incubator) {
		if (level.isClientSide()) {
			return;
		}
		ServerLevel serverLevel = (ServerLevel) level;
		ItemStack sampleStack = incubator.inventory.getItem(SLOT_SAMPLE);
		ItemStack mediumStack = incubator.inventory.getItem(SLOT_MEDIUM);
		if (!SampleData.hasSample(sampleStack) || mediumStack.isEmpty() || mediumStack.getItem() != ModItems.CULTURE_MEDIUM) {
			return;
		}
		// A finished harvest waiting for output room must not eat medium.
		if (incubator.progress >= FEEDINGS_PER_HARVEST) {
			ItemStack output = incubator.inventory.getItem(SLOT_OUTPUT);
			int room = output.isEmpty() ? YIELD : output.getMaxStackSize() - output.getCount();
			if (room < YIELD) {
				return;
			}
		}
		incubator.cycleTicks++;
		if (incubator.cycleTicks < incubator.ticksPerCycle()) {
			return;
		}
		incubator.cycleTicks = 0;
		mediumStack.shrink(1);
		if (mediumStack.isEmpty()) {
			incubator.inventory.setItem(SLOT_MEDIUM, ItemStack.EMPTY);
		}
		incubator.progress++;
		incubator.setChanged();

		serverLevel.sendParticles(ParticleTypes.ENCHANT,
				pos.getX() + 0.5, pos.getY() + 1.3, pos.getZ() + 0.5, 10, 0.25, 0.3, 0.25, 0.15);

		// Rare drift during cultivation — the ledger remembers.
		SampleData.Sample current = SampleData.read(sampleStack);
		if (current != null && serverLevel.getRandom().nextFloat() < 0.12f) {
			java.util.AbstractMap.SimpleEntry<VirusSpec, String> drift = current.spec().mutate(serverLevel.getRandom());
			VirusSpec mutated = drift.getKey().withSeverity(current.severity());
			incubator.inventory.setItem(SLOT_SAMPLE, SampleData.createSample(ModItems.VIRUS_VIAL, mutated, current.severity()));
			VirusArchive archive = VirusArchive.get(serverLevel);
			archive.registerGenome(mutated);
			archive.logMutation(current.spec().id(), drift.getValue());
		}

		if (incubator.progress >= FEEDINGS_PER_HARVEST) {
			// Room for the full yield was verified above, before we consumed any medium.
			SampleData.Sample out = SampleData.read(incubator.inventory.getItem(SLOT_SAMPLE));
			VirusSpec spec = out.spec();
			int severity = out.severity();
			ItemStack output = incubator.inventory.getItem(SLOT_OUTPUT);
			for (int i = 0; i < YIELD; i++) {
				ItemStack vial = SampleData.createSample(ModItems.VIRUS_VIAL, spec, severity);
				if (output.isEmpty()) {
					incubator.inventory.setItem(SLOT_OUTPUT, vial);
					output = incubator.inventory.getItem(SLOT_OUTPUT);
				} else {
					output.grow(1);
				}
			}
			incubator.inventory.setItem(SLOT_SAMPLE, ItemStack.EMPTY);
			incubator.progress = 0;
			level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1.0f, 1.6f);
			serverLevel.sendParticles(ParticleTypes.ENCHANTED_HIT,
					pos.getX() + 0.5, pos.getY() + 1.4, pos.getZ() + 0.5, 24, 0.3, 0.4, 0.3, 0.25);
		}
		incubator.setChanged();
	}

	/** Takes the loaded specimen out (used when breaking the block or via the menu). */
	public ItemStack unloadSample() {
		ItemStack stack = inventory.getItem(SLOT_SAMPLE);
		if (!SampleData.hasSample(stack)) {
			return ItemStack.EMPTY;
		}
		inventory.setItem(SLOT_SAMPLE, ItemStack.EMPTY);
		progress = 0;
		cycleTicks = 0;
		setChanged();
		return stack;
	}

	/** Legacy unload path for shift-interact emptying. */
	public CompoundTag unloadTag() {
		ItemStack stack = unloadSample();
		SampleData.Sample sample = SampleData.read(stack);
		return sample == null ? null : sample.spec().toTag(sample.severity());
	}

	public boolean loadSample(VirusSpec spec, int severity, long gameTime) {
		if (isLoaded()) {
			return false;
		}
		inventory.setItem(SLOT_SAMPLE, SampleData.createSample(ModItems.VIRUS_VIAL, spec, severity));
		progress = 0;
		cycleTicks = 0;
		setChanged();
		return true;
	}

	public boolean addMedium(int count) {
		ItemStack medium = inventory.getItem(SLOT_MEDIUM);
		int current = medium.isEmpty() ? 0 : medium.getCount();
		if (current >= MAX_MEDIUM) {
			return false;
		}
		inventory.setItem(SLOT_MEDIUM, new ItemStack(ModItems.CULTURE_MEDIUM, Math.min(MAX_MEDIUM, current + count)));
		setChanged();
		return true;
	}

	// -------------------------------------------------------- persistence

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		inventory.clearContent();
		input.read("Items", ItemStack.OPTIONAL_CODEC.listOf()).ifPresent(list -> {
			for (int i = 0; i < Math.min(inventory.getContainerSize(), list.size()); i++) {
				inventory.setItem(i, list.get(i));
			}
		});
		temperature = input.getIntOr("temperature", IDEAL_TEMP);
		progress = input.getIntOr("progress", 0);
		cycleTicks = input.getIntOr("cycleTicks", 0);
		// Migration path: pre-1.3 dishes stored a bare specimen tag plus separate counters.
		if (!isLoaded()) {
			CompoundTag legacy = input.read("sample", CompoundTag.CODEC).orElse(null);
			if (legacy != null) {
				VirusSpec legacySpec = VirusSpec.fromTag(legacy);
				if (legacySpec != null) {
					inventory.setItem(SLOT_SAMPLE, SampleData.createSample(ModItems.VIRUS_VIAL, legacySpec, VirusSpec.severityOf(legacy)));
				}
			}
			int legacyMedium = input.getIntOr("medium", 0);
			if (legacyMedium > 0 && inventory.getItem(SLOT_MEDIUM).isEmpty()) {
				inventory.setItem(SLOT_MEDIUM, new ItemStack(ModItems.CULTURE_MEDIUM, Math.min(MAX_MEDIUM, legacyMedium)));
			}
		}
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		super.saveAdditional(output);
		output.store("Items", ItemStack.OPTIONAL_CODEC.listOf(), inventory.getItems());
		output.putInt("temperature", temperature);
		output.putInt("progress", progress);
		output.putInt("cycleTicks", cycleTicks);
	}
}

package com.pathogen.protocol.block.entity;

import java.util.List;

import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.VirusArchive;
import com.pathogen.protocol.VirusSpec;
import com.pathogen.protocol.item.SampleData;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * The sequencing bench. Feeds a specimen + culture medium and ticks toward a
 * decoded genome, banking research points in the world archive as it goes.
 *
 * <p>Slots: 0 = pathogen sample, 1 = culture medium, 2 = genome fragments.</p>
 */
public class ResearchBenchBlockEntity extends BlockEntity {
	public static final int CYCLE_TICKS = 200;
	public static final int MAX_MEDIUM = 16;
	public static final int POINTS_PER_MEDIUM = 25;

	public static final int SLOT_SAMPLE = 0;
	public static final int SLOT_MEDIUM = 1;
	public static final int SLOT_FRAGMENTS = 2;

	private final SimpleContainer inventory = new SimpleContainer(3) {
		@Override
		public void setChanged() {
			super.setChanged();
			ResearchBenchBlockEntity.this.setChanged();
		}
	};

	private int cycleTicks = 0;
	private long lastAnnounced = 0L;

	public ResearchBenchBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.RESEARCH_BENCH, pos, state);
	}

	public SimpleContainer inventory() {
		return inventory;
	}

	public boolean isLoaded() {
		return SampleData.hasSample(inventory.getItem(SLOT_SAMPLE));
	}

	public boolean isRunning() {
		return SampleData.hasSample(inventory.getItem(SLOT_SAMPLE))
				&& !inventory.getItem(SLOT_MEDIUM).isEmpty();
	}

	public int cycleTicks() {
		return cycleTicks;
	}

	public int mediumCount() {
		return inventory.getItem(SLOT_MEDIUM).getCount();
	}

	public VirusSpec loadedSpec() {
		ItemStack stack = inventory.getItem(SLOT_SAMPLE);
		SampleData.Sample sample = SampleData.read(stack);
		return sample == null ? null : sample.spec();
	}

	public int loadedSeverity() {
		ItemStack stack = inventory.getItem(SLOT_SAMPLE);
		SampleData.Sample sample = SampleData.read(stack);
		return sample == null ? 0 : sample.severity();
	}

	public boolean addMedium(int count) {
		ItemStack medium = inventory.getItem(SLOT_MEDIUM);
		int current = medium.isEmpty() ? 0 : medium.getCount();
		if (current >= MAX_MEDIUM) {
			return false;
		}
		inventory.setItem(SLOT_MEDIUM, new ItemStack(ModItems.CULTURE_MEDIUM, Math.min(MAX_MEDIUM, current + count)));
		setChanged();
		return true;
	}

	/** Takes the loaded specimen out (block break or menu eject). */
	public ItemStack unloadSample() {
		ItemStack stack = inventory.getItem(SLOT_SAMPLE);
		if (!SampleData.hasSample(stack)) {
			return ItemStack.EMPTY;
		}
		inventory.setItem(SLOT_SAMPLE, ItemStack.EMPTY);
		cycleTicks = 0;
		setChanged();
		return stack;
	}

	public CompoundTag unloadTag() {
		ItemStack stack = unloadSample();
		SampleData.Sample sample = SampleData.read(stack);
		return sample == null ? null : sample.spec().toTag(sample.severity());
	}

	public boolean loadSample(VirusSpec spec, int severity, long gameTime) {
		ItemStack stack = inventory.getItem(SLOT_SAMPLE);
		if (SampleData.hasSample(stack)) {
			return false;
		}
		inventory.setItem(SLOT_SAMPLE, SampleData.createSample(ModItems.VIRUS_VIAL, spec, severity));
		cycleTicks = 0;
		lastAnnounced = gameTime;
		setChanged();
		return true;
	}

	public boolean loadIngredient(ItemStack stack) {
		ItemStack medium = inventory.getItem(SLOT_MEDIUM);
		if (stack.is(ModItems.CULTURE_MEDIUM)) {
			return addMedium(stack.getCount());
		}
		return false;
	}

	/** Pull research progress for the loaded genome; used by the menu screen. */
	public int researchOf(VirusArchive archive, String genomeId) {
		return archive.progressOf(genomeId);
	}

	// -------------------------------------------------------- ticking

	public static void tick(Level level, BlockPos pos, BlockState state, ResearchBenchBlockEntity bench) {
		if (level.isClientSide()) {
			return;
		}
		ServerLevel serverLevel = (ServerLevel) level;
		ItemStack sampleStack = bench.inventory.getItem(SLOT_SAMPLE);
		ItemStack mediumStack = bench.inventory.getItem(SLOT_MEDIUM);
		SampleData.Sample sample = SampleData.read(sampleStack);
		if (sample == null || mediumStack.isEmpty()) {
			return;
		}
		VirusSpec spec = sample.spec();
		VirusArchive archive = VirusArchive.get(serverLevel);
		archive.registerGenome(spec);
		bench.cycleTicks++;
		if (bench.cycleTicks < CYCLE_TICKS) {
			if (bench.cycleTicks % 40 == 0) {
				serverLevel.sendParticles(ParticleTypes.ENCHANT,
						pos.getX() + 0.5, pos.getY() + 1.5, pos.getZ() + 0.5, 4, 0.25, 0.2, 0.25, 0.1);
			}
			return;
		}
		bench.cycleTicks = 0;
		mediumStack.shrink(1);
		if (mediumStack.isEmpty()) {
			bench.inventory.setItem(SLOT_MEDIUM, ItemStack.EMPTY);
		}

		int before = archive.progressOf(spec.id());
		boolean newlyDecoded = archive.addResearch(spec, sample.severity(), POINTS_PER_MEDIUM);
		bench.pushFragment(serverLevel, pos);
		serverLevel.sendParticles(ParticleTypes.ENCHANTED_HIT,
				pos.getX() + 0.5, pos.getY() + 1.5, pos.getZ() + 0.5, 18, 0.3, 0.3, 0.3, 0.25);
		serverLevel.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 0.8f, 1.4f);

		int after = archive.progressOf(spec.id());
		if (newlyDecoded) {
			for (ServerPlayer player : serverLevel.players()) {
				player.displayClientMessage(Component.literal("§bDecoding complete: §f" + archive.displayNameOf(spec)
						+ " §7— genome fully sequenced. The archive can cure against it now."), false);
			}
		}
		bench.setChanged();
	}

	private void pushFragment(ServerLevel serverLevel, BlockPos pos) {
		ItemStack fragment = new ItemStack(ModItems.GENOME_FRAGMENT);
		ItemStack output = inventory.getItem(SLOT_FRAGMENTS);
		if (output.isEmpty()) {
			inventory.setItem(SLOT_FRAGMENTS, fragment);
		} else if (output.is(ModItems.GENOME_FRAGMENT) && output.getCount() < output.getMaxStackSize()) {
			output.grow(1);
		} else {
			net.minecraft.world.Containers.dropItemStack(serverLevel, pos.getX() + 0.5, pos.getY() + 1.0,
					pos.getZ() + 0.5, fragment);
		}
	}

	// -------------------------------------------------------- persistence

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		inventory.clearContent();
		input.read("Items", ItemStack.OPTIONAL_CODEC.listOf()).ifPresent(list -> {
			for (int i = 0; i < Math.min(inventory.getContainerSize(), list.size()); i++) {
				inventory.setItem(i, list.get(i));
			}
		});
		cycleTicks = input.getIntOr("cycleTicks", 0);
		// Migration path: pre-1.3 dishes stored a bare specimen tag plus separate counters.
		if (!SampleData.hasSample(inventory.getItem(SLOT_SAMPLE))) {
			CompoundTag legacy = input.read("sample", CompoundTag.CODEC).orElse(null);
			if (legacy != null) {
				VirusSpec legacySpec = VirusSpec.fromTag(legacy);
				if (legacySpec != null) {
					inventory.setItem(SLOT_SAMPLE, SampleData.createSample(ModItems.VIRUS_VIAL, legacySpec, VirusSpec.severityOf(legacy)));
				}
			}
			int legacyMedium = input.getIntOr("medium", 0);
			if (legacyMedium > 0 && inventory.getItem(SLOT_MEDIUM).isEmpty()) {
				inventory.setItem(SLOT_MEDIUM, new ItemStack(ModItems.CULTURE_MEDIUM, Math.min(MAX_MEDIUM, legacyMedium)));
			}
		}
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		super.saveAdditional(output);
		output.store("Items", ItemStack.OPTIONAL_CODEC.listOf(), inventory.getItems());
		output.putInt("cycleTicks", cycleTicks);
	}
}

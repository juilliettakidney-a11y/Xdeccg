package com.pathogen.protocol.block;

import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.VirusArchive;
import com.pathogen.protocol.VirusSpec;
import com.pathogen.protocol.item.SampleData;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Hold a sample up to the lens to read its dossier: severity, danger,
 * transmission vector, symptoms, and how close the research bench is to a
 * full sequence.
 */
public class MicroscopeBlock extends Block {
	public MicroscopeBlock(Properties properties) {
		super(properties);
	}

	private static boolean isSampleStack(ItemStack held) {
		return (held.getItem() == ModItems.VIRUS_VIAL || held.getItem() == ModItems.PATHOGEN_PROBE
				|| held.getItem() == ModItems.VIRUS_SYRINGE)
				&& SampleData.hasSample(held);
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		ItemStack held = player.getMainHandItem();
		if (!isSampleStack(held)) {
			if (!level.isClientSide()) {
				player.displayClientMessage(Component.literal("§8The Electron Microscope hums quietly. Hold a sample, probe or syringe to inspect it."), false);
			}
			return InteractionResult.SUCCESS;
		}
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		SampleData.Sample sample = SampleData.read(held);
		VirusSpec live = sample.liveSpec();
		VirusArchive archive = VirusArchive.get((ServerLevel) level);
		archive.registerGenome(sample.spec());
		archive.markScanned(live.id(), player.getName().getString());
		String custom = archive.customNameOf(live.id());
		String shownName = custom != null ? custom + " §8(" + live.displayName() + ")" : live.displayName();
		boolean decoded = archive.isDecoded(live.id());
		int target = Math.max(archive.targetOf(live.id()), live.researchTarget(sample.severity()));

		String spread = switch (live.spread()) {
			case CONTACT -> "Contact (blood & saliva)";
			case AIRBORNE -> "Airborne (radius " + (int) live.effectiveRadius(sample.severity()) + ")";
			case FOOD -> "Foodborne (the harvest)";
		};

		player.displayClientMessage(Component.literal("§6──── Microscope Analysis ────"), false);
		player.displayClientMessage(Component.literal("§7Organism: §f" + shownName + " §8(№ " + live.id() + ")"), false);
		player.displayClientMessage(Component.literal("§7Severity: §c" + live.severityBar(sample.severity())
				+ " §8(" + sample.severity() + "/" + VirusSpec.MAX_SEVERITY + ")"), false);
		player.displayClientMessage(Component.literal("§7Danger:   §6" + live.dangerLabel(sample.severity())), false);
		player.displayClientMessage(Component.literal("§7Transmission: §f" + spread), false);
		player.displayClientMessage(Component.literal("§7Symptoms: §f" + String.join("§7, §f", SampleData.symptomLabels(sample))), false);
		player.displayClientMessage(Component.literal("§7Research: " + (decoded
				? "§aGENOME DECODED — serum may be brewed"
				: "§e" + archive.progressOf(live.id()) + "/" + target + " research")), false);
		player.displayClientMessage(Component.literal("§8" + live.lore()), false);
		level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 0.5f, 1.8f);
		return InteractionResult.SUCCESS;
	}
}

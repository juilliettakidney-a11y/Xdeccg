package com.pathogen.protocol.block;

import com.mojang.serialization.MapCodec;

import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.VirusSpec;
import com.pathogen.protocol.block.entity.IncubatorBlockEntity;
import com.pathogen.protocol.block.entity.ModBlockEntities;
import com.pathogen.protocol.item.SampleData;
import com.pathogen.protocol.menu.MenuOpener;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Grows a loaded culture: feed it medium and after three feedings
 * it splits into two vials of the same strain — at the severity bred into it.
 */
public class IncubatorBlock extends BaseEntityBlock {
	public static final MapCodec<IncubatorBlock> CODEC = simpleCodec(IncubatorBlock::new);

	public IncubatorBlock(BlockBehaviour.Properties properties) {
		super(properties);
	}

	@Override
	protected MapCodec<IncubatorBlock> codec() {
		return CODEC;
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new IncubatorBlockEntity(pos, state);
	}

	@Override
	public <T extends BlockEntity> net.minecraft.world.level.block.entity.BlockEntityTicker<T> getTicker(
			Level level, BlockState state, net.minecraft.world.level.block.entity.BlockEntityType<T> type) {
		return level.isClientSide()
				? null
				: createTickerHelper(type, ModBlockEntities.INCUBATOR, IncubatorBlockEntity::tick);
	}

	private static boolean isSampleStack(ItemStack held) {
		return (held.getItem() == ModItems.VIRUS_VIAL || held.getItem() == ModItems.PATHOGEN_PROBE)
				&& SampleData.hasSample(held);
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		BlockEntity entity = level.getBlockEntity(pos);
		if (!(entity instanceof IncubatorBlockEntity incubator)) {
			return InteractionResult.PASS;
		}
		ItemStack held = player.getMainHandItem();

		if (isSampleStack(held)) {
			SampleData.Sample sample = SampleData.read(held);
			if (incubator.loadSample(sample.spec(), sample.severity(), level.getGameTime())) {
				held.shrink(1);
				level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1.0f, 1.5f);
				player.displayClientMessage(Component.literal("§7Culture of §f" + sample.spec().displayName()
						+ " §7seeded (severity " + sample.severity() + "). Feed it medium ("
						+ IncubatorBlockEntity.FEEDINGS_PER_HARVEST + " feedings to harvest)."), false);
			} else {
				player.displayClientMessage(Component.literal("§cThe incubator already holds a culture. Shift+interact with an empty hand to eject it."), false);
			}
			return InteractionResult.SUCCESS;
		}
		if (held.getItem() == ModItems.CULTURE_MEDIUM) {
			if (incubator.addMedium(1)) {
				held.shrink(1);
				player.displayClientMessage(Component.literal("§7Culture medium loaded. (" + incubator.mediumCount() + "/16)"), false);
			} else {
				player.displayClientMessage(Component.literal("§cThe incubator can't hold any more medium."), false);
			}
			return InteractionResult.SUCCESS;
		}
		if (held.isEmpty()) {
			if (player.isShiftKeyDown() && incubator.isLoaded()) {
				ItemStack ejected = incubator.unloadSample();
				if (!ejected.isEmpty()) {
					Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, ejected);
				}
				player.displayClientMessage(Component.literal("§7Ejected the culture."), false);
				return InteractionResult.SUCCESS;
			}
			player.openMenu(MenuOpener.incubator(pos));
			return InteractionResult.SUCCESS;
		}
		return InteractionResult.PASS;
	}

	@Override
	public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
		BlockEntity entity = level.getBlockEntity(pos);
		if (entity instanceof IncubatorBlockEntity incubator && incubator.isLoaded() && !level.isClientSide()) {
			ItemStack dropped = incubator.unloadSample();
			if (!dropped.isEmpty()) {
				Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, dropped);
			}
		}
		return super.playerWillDestroy(level, pos, state, player);
	}
}

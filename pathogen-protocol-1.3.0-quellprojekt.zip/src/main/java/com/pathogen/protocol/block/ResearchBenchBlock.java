package com.pathogen.protocol.block;

import com.mojang.serialization.MapCodec;

import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.VirusArchive;
import com.pathogen.protocol.VirusSpec;
import com.pathogen.protocol.block.entity.ModBlockEntities;
import com.pathogen.protocol.block.entity.ResearchBenchBlockEntity;
import com.pathogen.protocol.item.SampleData;
import com.pathogen.protocol.menu.MenuOpener;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.BlockHitResult;

/**
 * The sequencer. Load a sample, feed it culture medium, and it will
 * slowly decode the genome — unlocking an Engineered Serum. Stronger
 * specimens demand much more medium before the truth comes out.
 */
public class ResearchBenchBlock extends BaseEntityBlock {
	public static final MapCodec<ResearchBenchBlock> CODEC = simpleCodec(ResearchBenchBlock::new);

	public ResearchBenchBlock(BlockBehaviour.Properties properties) {
		super(properties);
	}

	@Override
	protected MapCodec<ResearchBenchBlock> codec() {
		return CODEC;
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new ResearchBenchBlockEntity(pos, state);
	}

	@Override
	public <T extends BlockEntity> net.minecraft.world.level.block.entity.BlockEntityTicker<T> getTicker(
			Level level, BlockState state, net.minecraft.world.level.block.entity.BlockEntityType<T> type) {
		return level.isClientSide()
				? null
				: createTickerHelper(type, ModBlockEntities.RESEARCH_BENCH, ResearchBenchBlockEntity::tick);
	}

	private static boolean isSampleStack(ItemStack held) {
		return (held.getItem() == ModItems.VIRUS_VIAL || held.getItem() == ModItems.PATHOGEN_PROBE)
				&& SampleData.hasSample(held);
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		BlockEntity entity = level.getBlockEntity(pos);
		if (!(entity instanceof ResearchBenchBlockEntity bench)) {
			return InteractionResult.PASS;
		}
		ItemStack held = player.getMainHandItem();

		if (isSampleStack(held)) {
			SampleData.Sample sample = SampleData.read(held);
			if (bench.loadSample(sample.spec(), sample.severity(), level.getGameTime())) {
				held.shrink(1);
				level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1.0f, 1.7f);
				player.displayClientMessage(Component.literal("§7Sequencer loaded with §f" + sample.spec().displayName()
						+ " §8(severity " + sample.severity() + ")§7. Feed it culture medium — worse strains want much more of it."), false);
			} else {
				player.displayClientMessage(Component.literal("§cThe sequencer already holds a sample. Shift+interact with an empty hand to eject it."), false);
			}
			return InteractionResult.SUCCESS;
		}
		if (held.getItem() == ModItems.CULTURE_MEDIUM) {
			if (bench.addMedium(1)) {
				held.shrink(1);
				player.displayClientMessage(Component.literal("§7Culture medium loaded. (" + bench.mediumCount() + "/16)"), false);
			} else {
				player.displayClientMessage(Component.literal("§cThe bench can't hold any more medium."), false);
			}
			return InteractionResult.SUCCESS;
		}
		if (held.isEmpty()) {
			if (player.isShiftKeyDown() && bench.isLoaded()) {
				ItemStack ejected = bench.unloadSample();
				VirusSpec spec = null;
				SampleData.Sample read = SampleData.read(ejected);
				if (read != null) {
					spec = read.spec();
				}
				Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, ejected);
				player.displayClientMessage(Component.literal("§7Ejected the " + (spec != null ? spec.displayName() : "sample") + " sample."), false);
				return InteractionResult.SUCCESS;
			}
			player.openMenu(MenuOpener.researchBench(pos));
			return InteractionResult.SUCCESS;
		}
		return InteractionResult.PASS;
	}

	@Override
	public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
		BlockEntity entity = level.getBlockEntity(pos);
		if (entity instanceof ResearchBenchBlockEntity bench && bench.isLoaded() && !level.isClientSide()) {
			ItemStack dropped = bench.unloadSample();
			if (!dropped.isEmpty()) {
				Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, dropped);
			}
		}
		return super.playerWillDestroy(level, pos, state, player);
	}
}

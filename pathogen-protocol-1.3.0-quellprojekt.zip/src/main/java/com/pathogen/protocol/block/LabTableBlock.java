package com.pathogen.protocol.block;

import net.minecraft.world.level.block.CraftingTableBlock;

/**
 * The workhorse of the field lab — a proper crafting surface dressed as one.
 */
public class LabTableBlock extends CraftingTableBlock {
	public LabTableBlock(Properties properties) {
		super(properties);
	}
}

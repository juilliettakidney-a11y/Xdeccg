package com.pathogen.protocol.block.entity;

import com.pathogen.protocol.ModBlocks;
import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.VirusArchive;
import com.pathogen.protocol.VirusSpec;
import com.pathogen.protocol.item.SampleData;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * A petri dish of living culture. The specimen lives on the stack inside its
 * single slot, so menus can display it directly and the block survives chunk
 * reloads exactly like any container.
 *
 * <p>Feeding behaviour:</p>
 * <ul>
 *   <li><b>Culture medium</b> — the classic regimen: +1 severity, one roll on the mutation table.</li>
 *   <li><b>Golden carrot</b> — a rich sugar hit: one randomly chosen property of the strain improves.</li>
 * </ul>
 */
public class CulturePlateBlockEntity extends BlockEntity {
	public static final int MAX_STAGE = 3;

	private final SimpleContainer inventory = new SimpleContainer(1) {
		@Override
		public void setChanged() {
			super.setChanged();
			CulturePlateBlockEntity.this.setChanged();
		}
	};

	private int fedCount = 0;

	public CulturePlateBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.CULTURE_PLATE, pos, state);
	}

	public SimpleContainer inventory() {
		return inventory;
	}

	// -------------------------------------------------------- specimen access

	public boolean hasSample() {
		return SampleData.hasSample(inventory.getItem(0));
	}

	public SampleData.Sample specimen() {
		return hasSample() ? SampleData.read(inventory.getItem(0)) : null;
	}

	public VirusSpec loadedSpec() {
		SampleData.Sample sample = specimen();
		return sample == null ? null : sample.spec();
	}

	public int loadedSeverity() {
		SampleData.Sample sample = specimen();
		return sample == null ? 0 : sample.severity();
	}

	public int fedCount() {
		return fedCount;
	}

	/** Growth stage used for the block model, derived from total feeds. */
	public int stage() {
		if (!hasSample()) {
			return 0;
		}
		return Math.min(MAX_STAGE, 1 + fedCount / 2);
	}

	public boolean loadSample(VirusSpec spec, int severity) {
		if (hasSample()) {
			return false;
		}
		inventory.setItem(0, SampleData.createSample(ModItems.VIRUS_VIAL, spec, severity));
		setChanged();
		return true;
	}

	/** Takes the specimen out of the dish. */
	public ItemStack unloadSample() {
		ItemStack stack = inventory.getItem(0);
		if (!SampleData.hasSample(stack)) {
			return ItemStack.EMPTY;
		}
		inventory.setItem(0, ItemStack.EMPTY);
		fedCount = 0;
		setChanged();
		return stack;
	}

	public String statusLine() {
		SampleData.Sample sample = specimen();
		if (sample == null) {
			return "idle";
		}
		return sample.spec().displayName() + " — severity " + sample.severity() + "/" + VirusSpec.MAX_SEVERITY;
	}

	// -------------------------------------------------------- feeding

	/**
	 * Applies one culture-medium feeding: +1 severity, and a 25% mutation roll.
	 * Returns the new severity, or -1 when nothing could be fed.
	 */
	public int feedMedium(net.minecraft.server.level.ServerLevel level, BlockPos pos) {
		SampleData.Sample sample = specimen();
		if (sample == null) {
			return -1;
		}
		int current = sample.severity();
		if (current >= VirusSpec.MAX_SEVERITY) {
			return -1;
		}
		VirusSpec hardened = sample.spec().withSeverity(current + 1);
		inventory.setItem(0, SampleData.createSample(ModItems.VIRUS_VIAL, hardened, current + 1));
		String mutation = rollMutation(level, hardened, current + 1, 0.25f);
		fedCount++;
		setChanged();
		return current + 1;
	}

	/**
	 * Applies a golden carrot: one randomly chosen trait of the strain improves
	 * (severity, airborne reach, virulence, or an extra symptom), then a small
	 * mutation roll. Returns a human-readable description of what flared.
	 */
	public String feedGoldenCarrot(net.minecraft.server.level.ServerLevel level, BlockPos pos) {
		SampleData.Sample sample = specimen();
		if (sample == null) {
			return null;
		}
		VirusSpec spec = sample.spec();
		int severity = sample.severity();
		java.util.List<String> options = new java.util.ArrayList<>();

		if (severity < VirusSpec.MAX_SEVERITY) {
			options.add("severity");
		}
		if (spec.spread() == VirusSpec.Spread.AIRBORNE) {
			options.add("radius");
		}
		options.add("virulence");
		long symptomRoom = VirusSpec.Symptom.values().length - spec.symptoms().size();
		if (symptomRoom > 0) {
			options.add("symptom");
		}
		options.add("endurance"); // flavor-only boost that still expresses as virulence

		String pick = options.get(level.getRandom().nextInt(options.size()));
		String label;
		VirusSpec updated = spec;
		int newSeverity = severity;
		switch (pick) {
			case "severity" -> {
				newSeverity = Math.min(VirusSpec.MAX_SEVERITY, severity + 1);
				updated = spec.withSeverity(newSeverity);
				label = "severity " + severity + " → " + newSeverity;
			}
			case "radius" -> {
				double raised = spec.radius() + 0.5 + level.getRandom().nextDouble() * 0.3;
				updated = spec.withRadius(raised);
				label = String.format(java.util.Locale.ROOT, "airborne reach %.1f → %.1f", spec.radius(), raised);
			}
			case "virulence" -> {
				float raised = Math.min(1.8f, spec.virulence() + 0.12f + level.getRandom().nextFloat() * 0.1f);
				updated = spec.withVirulence(raised);
				label = String.format(java.util.Locale.ROOT, "virulence %.2f → %.2f", spec.virulence(), raised);
			}
			case "symptom" -> {
				java.util.List<VirusSpec.Symptom> remaining = new java.util.ArrayList<>();
				for (VirusSpec.Symptom symptom : VirusSpec.Symptom.values()) {
					if (!spec.symptoms().contains(symptom)) {
						remaining.add(symptom);
					}
				}
				VirusSpec.Symptom gained = remaining.get(level.getRandom().nextInt(remaining.size()));
				java.util.List<VirusSpec.Symptom> symptoms = new java.util.ArrayList<>(spec.symptoms());
				symptoms.add(gained);
				updated = spec.withSymptoms(symptoms);
				label = "gained symptom: " + gained.label();
			}
			default -> {
				float raised = Math.min(1.8f, spec.virulence() + 0.08f);
				updated = spec.withVirulence(raised);
				label = String.format(java.util.Locale.ROOT, "endurance: virulence %.2f → %.2f", spec.virulence(), raised);
			}
		}
		inventory.setItem(0, SampleData.createSample(ModItems.VIRUS_VIAL, updated.withSeverity(newSeverity), newSeverity));
		VirusArchive archive = VirusArchive.get(level);
		archive.registerGenome(spec);
		archive.registerGenome(updated.withSeverity(newSeverity));
		archive.logMutation(spec.id(), "Golden carrot — " + label);
		rollMutation(level, updated.withSeverity(newSeverity), newSeverity, 0.15f);
		fedCount++;
		setChanged();
		return label;
	}

	/** Shared mutation roll; logs to the archive ledger when it fires. */
	private String rollMutation(net.minecraft.server.level.ServerLevel level, VirusSpec spec, int severity, float chance) {
		if (level.getRandom().nextFloat() >= chance) {
			return null;
		}
		java.util.AbstractMap.SimpleEntry<VirusSpec, String> result = spec.mutate(level.getRandom());
		VirusSpec mutated = result.getKey().withSeverity(severity);
		String description = result.getValue();
		inventory.setItem(0, SampleData.createSample(ModItems.VIRUS_VIAL, mutated, severity));
		VirusArchive archive = VirusArchive.get(level);
		archive.registerGenome(mutated);
		archive.logMutation(spec.id(), description);
		return description;
	}

	// -------------------------------------------------------- persistence

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		inventory.clearContent();
		input.read("Items", ItemStack.OPTIONAL_CODEC.listOf()).ifPresent(list -> {
			for (int i = 0; i < Math.min(inventory.getContainerSize(), list.size()); i++) {
				inventory.setItem(i, list.get(i));
			}
		});
		fedCount = input.getIntOr("fedCount", 0);
		// Migration path: pre-1.3 dishes stored a bare specimen tag instead of a stack.
		if (!hasSample()) {
			CompoundTag legacy = input.read("sample", CompoundTag.CODEC).orElse(null);
			if (legacy != null) {
				VirusSpec legacySpec = VirusSpec.fromTag(legacy);
				if (legacySpec != null) {
					inventory.setItem(0, SampleData.createSample(ModItems.VIRUS_VIAL, legacySpec, VirusSpec.severityOf(legacy)));
				}
			}
		}
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		super.saveAdditional(output);
		output.store("Items", ItemStack.OPTIONAL_CODEC.listOf(), inventory.getItems());
		output.putInt("fedCount", fedCount);
	}
}

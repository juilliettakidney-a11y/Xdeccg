package com.pathogen.protocol.block;

import com.mojang.serialization.MapCodec;

import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.VirusSpec;
import com.pathogen.protocol.block.entity.CulturePlateBlockEntity;
import com.pathogen.protocol.block.entity.ModBlockEntities;
import com.pathogen.protocol.item.SampleData;
import com.pathogen.protocol.menu.MenuOpener;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * A culture dish of living virus. Feed it medium and it breeds something
 * deadlier; drain it back into a vial when it's as mean as you can stand.
 * Break it open and the culture spills its secrets onto the ground.
 */
public class CulturePlateBlock extends BaseEntityBlock {
	public static final MapCodec<CulturePlateBlock> CODEC = simpleCodec(CulturePlateBlock::new);

	public CulturePlateBlock(Properties properties) {
		super(properties);
	}

	@Override
	protected MapCodec<CulturePlateBlock> codec() {
		return CODEC;
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new CulturePlateBlockEntity(pos, state);
	}

	@Override
	public <T extends BlockEntity> net.minecraft.world.level.block.entity.BlockEntityTicker<T> getTicker(
			Level level, BlockState state, net.minecraft.world.level.block.entity.BlockEntityType<T> type) {
		return null; // Passive block — it dreams, it does not act.
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		BlockEntity entity = level.getBlockEntity(pos);
		if (!(entity instanceof CulturePlateBlockEntity plate)) {
			return InteractionResult.PASS;
		}
		ServerLevel serverLevel = (ServerLevel) level;
		ItemStack held = player.getMainHandItem();

		// Feed the culture: +1 severity per medium.
		if (held.getItem() == ModItems.CULTURE_MEDIUM) {
			if (!plate.hasSample()) {
				player.displayClientMessage(Component.literal("§8The dish is empty. Seed it with a virus sample first."), false);
				return InteractionResult.SUCCESS;
			}
			int updated = plate.feedMedium(serverLevel, pos);
			if (updated < 0) {
				player.displayClientMessage(Component.literal("§cThe culture has reached its limit of cruelty (severity "
						+ VirusSpec.MAX_SEVERITY + "). No feeding can push it further."), false);
				return InteractionResult.SUCCESS;
			}
			held.shrink(1);
			VirusSpec spec = plate.loadedSpec();
			serverLevel.sendParticles(new DustParticleOptions(spec.color(), 1.4f),
					pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5, 24, 0.25, 0.15, 0.25, 0.05);
			level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1.0f, 0.8f + updated * 0.1f);
			player.displayClientMessage(Component.literal("§6The culture divides, hungers, rewrites itself... §f"
					+ spec.displayName() + " §6— severity §c" + updated + "§6/10."), false);
			return InteractionResult.SUCCESS;
		}

		// Feed the culture rich sugar: golden carrot flares one trait of the strain.
		if (held.getItem() == net.minecraft.world.item.Items.GOLDEN_CARROT) {
			if (!plate.hasSample()) {
				player.displayClientMessage(Component.literal("§8The dish is empty. Seed it with a virus sample first."), false);
				return InteractionResult.SUCCESS;
			}
			held.shrink(1);
			String label = plate.feedGoldenCarrot(serverLevel, pos);
			VirusSpec spec = plate.loadedSpec();
			serverLevel.sendParticles(new DustParticleOptions(0xF2C230, 1.6f),
					pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5, 32, 0.25, 0.15, 0.25, 0.06);
			level.playSound(null, pos, SoundEvents.GLOW_ITEM_FRAME_ADD_ITEM, SoundSource.BLOCKS, 0.9f, 1.35f);
			player.displayClientMessage(Component.literal("§6The strain flares at the rich feed — §e" + label + "§6."), false);
			return InteractionResult.SUCCESS;
		}

		// Seed the dish with a vial or a probe.
		if ((held.getItem() == ModItems.VIRUS_VIAL || held.getItem() == ModItems.PATHOGEN_PROBE)
				&& SampleData.hasSample(held)) {
			SampleData.Sample sample = SampleData.read(held);
			if (plate.loadSample(sample.spec(), sample.severity())) {
				held.shrink(1);
				level.playSound(null, pos, SoundEvents.SLIME_BLOCK_HIT, SoundSource.BLOCKS, 0.8f, 1.3f);
				player.displayClientMessage(Component.literal("§7Culture seeded with §f" + sample.spec().displayName()
						+ " §8(severity " + sample.severity() + ")§7. Feed it medium to breed it stronger."), false);
			} else {
				player.displayClientMessage(Component.literal("§cThe dish already holds a culture. Shift+interact with an empty hand to harvest."), false);
			}
			return InteractionResult.SUCCESS;
		}

		// Drain the dish into an empty vial (or empty-handed harvest with shift).
		if (held.getItem() == ModItems.EMPTY_VIAL || (held.isEmpty() && player.isShiftKeyDown())) {
			VirusSpec loaded = plate.loadedSpec();
			if (loaded == null) {
				player.displayClientMessage(Component.literal("§8The dish is empty."), false);
				return InteractionResult.SUCCESS;
			}
			int severity = plate.loadedSeverity();
			if (held.getItem() == ModItems.EMPTY_VIAL) {
				held.shrink(1);
			}
			ItemStack drained = plate.unloadSample();
			if (drained.isEmpty()) {
				drained = SampleData.createSample(ModItems.VIRUS_VIAL, loaded, severity);
			}
			net.minecraft.world.Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, drained);
			serverLevel.sendParticles(ParticleTypes.ENCHANT, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
					16, 0.3, 0.2, 0.3, 0.1);
			level.playSound(null, pos, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 0.6f, 1.4f);
			player.displayClientMessage(Component.literal("§7You decant the culture: §f" + loaded.displayName()
					+ " §8(severity " + severity + ")§7. Handle it like it owes you money."), false);
			return InteractionResult.SUCCESS;
		}

		if (held.isEmpty()) {
			player.openMenu(MenuOpener.petriDish(pos));
			return InteractionResult.SUCCESS;
		}
		return InteractionResult.PASS;
	}

	@Override
	public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
		BlockEntity entity = level.getBlockEntity(pos);
		if (entity instanceof CulturePlateBlockEntity plate && plate.hasSample() && !level.isClientSide()) {
			ItemStack drained = plate.unloadSample();
			if (!drained.isEmpty()) {
				net.minecraft.world.Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, drained);
			}
		}
		return super.playerWillDestroy(level, pos, state, player);
	}
}

package com.pathogen.protocol.block.entity;

import com.pathogen.protocol.ModBlocks;
import com.pathogen.protocol.PathogenProtocol;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.BlockEntityType;

public final class ModBlockEntities {
	public static BlockEntityType<ResearchBenchBlockEntity> RESEARCH_BENCH;
	public static BlockEntityType<IncubatorBlockEntity> INCUBATOR;
	public static BlockEntityType<CulturePlateBlockEntity> CULTURE_PLATE;

	private ModBlockEntities() {
	}

	public static void register() {
		RESEARCH_BENCH = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE,
				Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, "research_bench"),
				FabricBlockEntityTypeBuilder.create(ResearchBenchBlockEntity::new, ModBlocks.RESEARCH_BENCH).build());
		INCUBATOR = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE,
				Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, "incubator"),
				FabricBlockEntityTypeBuilder.create(IncubatorBlockEntity::new, ModBlocks.INCUBATOR).build());
		CULTURE_PLATE = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE,
				Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, "culture_plate"),
				FabricBlockEntityTypeBuilder.create(CulturePlateBlockEntity::new, ModBlocks.CULTURE_PLATE).build());
	}
}

package com.pathogen.protocol.block;

import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.item.SampleData;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Spins a sample at absurd RPMs and isolates pure pathogen protein —
 * the raw ingredient of every researched cure.
 */
public class CentrifugeBlock extends Block {
	public CentrifugeBlock(Properties properties) {
		super(properties);
	}

	private static boolean isSampleStack(ItemStack held) {
		return (held.getItem() == ModItems.VIRUS_VIAL || held.getItem() == ModItems.PATHOGEN_PROBE)
				&& SampleData.hasSample(held);
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		ItemStack held = player.getMainHandItem();
		if (!isSampleStack(held)) {
			if (!level.isClientSide()) {
				player.displayClientMessage(Component.literal("§8The centrifuge hums at idle. Feed it a virus sample or a probe."), false);
			}
			return InteractionResult.SUCCESS;
		}
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		SampleData.Sample sample = SampleData.read(held);
		held.shrink(1);
		Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
				new ItemStack(ModItems.PATHOGEN_PROTEIN, 2));
		level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1.0f, 1.8f);
		player.displayClientMessage(Component.literal("§7The rotor shrieks... §f2 Pathogen Protein §7isolated from "
				+ sample.spec().displayName() + "."), false);
		return InteractionResult.SUCCESS;
	}
}

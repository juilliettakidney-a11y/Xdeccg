package com.pathogen.protocol;

import com.mojang.serialization.Codec;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

/**
 * Per-entity pathogen markers. The genome id keys into the world's
 * {@link VirusArchive}; the severity is the living specimen's current strength
 * (fed cultures carry a higher value than the wild genome).
 */
public final class ModAttachments {
	/** Genome id of the infecting specimen; empty string = not infected by us. */
	public static final AttachmentType<String> GENOME = AttachmentRegistry.<String>builder()
			.initializer(() -> "")
			.persistent(Codec.STRING)
			.copyOnDeath()
			.buildAndRegister(PathogenProtocol.id("genome"));

	/** Current strength of the infecting strain in this host (1..MAX_SEVERITY). */
	public static final AttachmentType<Integer> SEVERITY = AttachmentRegistry.<Integer>builder()
			.initializer(() -> 1)
			.persistent(Codec.INT)
			.copyOnDeath()
			.buildAndRegister(PathogenProtocol.id("severity"));

	/** Last seen hunger value, for detecting eating (the food-borne vector). */
	public static final AttachmentType<Integer> LAST_FOOD = AttachmentRegistry.<Integer>builder()
			.initializer(() -> -1)
			.persistent(Codec.INT)
			.buildAndRegister(PathogenProtocol.id("last_food"));

	private ModAttachments() {
	}

	public static void register() {
		// Forces class-load so the attachment types register before the game freezes registries.
	}
}

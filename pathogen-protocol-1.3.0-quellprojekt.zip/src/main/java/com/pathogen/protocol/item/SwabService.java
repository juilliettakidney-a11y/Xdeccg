package com.pathogen.protocol.item;

import java.util.Optional;

import com.pathogen.protocol.Infection;
import com.pathogen.protocol.InfectionManager;
import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.VirusArchive;
import com.pathogen.protocol.VirusSpec;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext;

/**
 * One place that knows how a sterile swab behaves — used by the swab item
 * itself and by the G-key handler, so both paths always agree.
 */
public final class SwabService {
	private SwabService() {
	}

	/** Finds a usable swab in the player's hands first, then anywhere in the inventory. */
	public static ItemStack findSwab(Player player) {
		ItemStack main = player.getMainHandItem();
		if (main.is(ModItems.STERILE_SWAB)) {
			return main;
		}
		ItemStack off = player.getOffhandItem();
		if (off.is(ModItems.STERILE_SWAB)) {
			return off;
		}
		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			ItemStack stack = player.getInventory().getItem(i);
			if (stack.is(ModItems.STERILE_SWAB)) {
				return stack;
			}
		}
		return ItemStack.EMPTY;
	}

	/** Swab an infected creature. Consumes one swab on success. */
	public static InteractionResult swabEntity(Player player, ItemStack swab, LivingEntity target, Level level) {
		Infection infection = InfectionManager.getInfection(target);
		if (infection == null) {
			return InteractionResult.PASS;
		}
		return drawProbe(player, swab, infection, target.blockPosition(), level);
	}

	/** Swab a block an infected carrier tainted. Consumes one swab on success. */
	public static InteractionResult swabBlock(Player player, ItemStack swab, Level level, BlockPos pos) {
		if (!(level instanceof ServerLevel serverLevel)) {
			return InteractionResult.FAIL;
		}
		VirusArchive archive = VirusArchive.get(serverLevel);
		VirusArchive.Contamination mark = archive.contaminationAt(pos);
		if (mark == null) {
			return InteractionResult.PASS;
		}
		VirusSpec spec = archive.getSpec(mark.genome());
		if (spec == null) {
			return InteractionResult.PASS;
		}
		return drawProbe(player, swab, new Infection(spec, mark.severity()), pos, serverLevel);
	}

	/**
	 * The G-key behaviour: swab whatever the player is looking at — an infected
	 * living creature or a contaminated block — using the nearest swab in hand
	 * or inventory. Failing to find anything worth swab-ing never consumes a swab.
	 */
	public static void swabContextual(ServerPlayer player) {
		Level level = player.level();
		ItemStack swab = findSwab(player);
		if (swab.isEmpty()) {
			player.displayClientMessage(Component.literal("§8You need a sterile swab to collect a sample (look at an infected creature or a contaminated block)."), true);
			return;
		}

		Vec3 eye = player.getEyePosition();
		Vec3 look = player.getLookAngle();
		double reach = 4.5;
		Vec3 end = eye.add(look.scale(reach));

		BlockHitResult blockHit = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE,
				ClipContext.Fluid.NONE, player));
		double blockDistance = blockHit != null && blockHit.getType() != HitResult.Type.MISS
				? blockHit.getLocation().distanceTo(eye) : Double.MAX_VALUE;

		LivingEntity target = null;
		double bestDistance = Double.MAX_VALUE;
		net.minecraft.world.phys.AABB searchBox = new net.minecraft.world.phys.AABB(
				Math.min(eye.x, end.x) - 0.5, Math.min(eye.y, end.y) - 0.5, Math.min(eye.z, end.z) - 0.5,
				Math.max(eye.x, end.x) + 0.5, Math.max(eye.y, end.y) + 0.5, Math.max(eye.z, end.z) + 0.5);
		for (LivingEntity candidate : level.getEntitiesOfClass(LivingEntity.class, searchBox,
				entity -> entity != player)) {
			Optional<Vec3> hit = candidate.getBoundingBox().inflate(0.3).clip(eye, end);
			if (hit.isPresent()) {
				double distance = hit.get().distanceTo(eye);
				if (distance < bestDistance && distance <= blockDistance + 0.2) {
					bestDistance = distance;
					target = candidate;
				}
			}
		}

		if (target != null && InfectionManager.getInfection(target) != null) {
			swabEntity(player, swab, target, level);
			return;
		}
		if (blockHit != null && blockHit.getType() == HitResult.Type.BLOCK
				&& swabBlock(player, swab, level, blockHit.getBlockPos()).consumesAction()) {
			return;
		}
		player.displayClientMessage(Component.literal("§8Nothing worth swabb-ing there — you need an infected creature or a contaminated block."), true);
	}

	private static InteractionResult drawProbe(Player player, ItemStack swab, Infection infection, BlockPos pos, Level level) {
		swab.shrink(1);
		ItemStack probe = SampleData.createSample(ModItems.PATHOGEN_PROBE, infection.spec(), infection.severity());
		if (!player.getInventory().add(probe)) {
			net.minecraft.world.Containers.dropItemStack(level, player.getX(), player.getY() + 0.5, player.getZ(), probe);
		}
		level.playSound(null, pos, SoundEvents.SLIME_BLOCK_HIT, SoundSource.PLAYERS, 0.7f, 1.6f);
		player.displayClientMessage(Component.literal("§7Probe sealed: §f" + infection.spec().displayName()
				+ " §8(severity " + infection.severity() + ")"), false);
		return InteractionResult.SUCCESS;
	}
}

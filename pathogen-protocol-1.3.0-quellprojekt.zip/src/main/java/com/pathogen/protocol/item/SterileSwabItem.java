package com.pathogen.protocol.item;

import com.pathogen.protocol.ModItems;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/**
 * A sterile swab. Run it over an infected creature — or a block an infected
 * person has handled — to draw off a Pathogen Probe you can research.
 *
 * <p>The same behaviour backs the G-key shortcut (see {@link SwabService}).</p>
 */
public class SterileSwabItem extends Item {
	public SterileSwabItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
		Level level = target.level();
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		return SwabService.swabEntity(player, stack, target, level);
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Level level = context.getLevel();
		if (level.isClientSide() || !(level instanceof ServerLevel serverLevel)) {
			return level.isClientSide() ? InteractionResult.SUCCESS : InteractionResult.FAIL;
		}
		Player player = context.getPlayer();
		if (player == null) {
			return InteractionResult.FAIL;
		}
		return SwabService.swabBlock(player, context.getItemInHand(), serverLevel, context.getClickedPos());
	}
}

package com.pathogen.protocol.item;

import java.util.function.Consumer;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;

/**
 * A genome fragment decoded by the Research Bench. Combine Antibiotics +
 * three fragments + Nether Wart to brew an Engineered Serum.
 */
public class GenomeFragmentItem extends Item {
	public GenomeFragmentItem(Properties properties) {
		super(properties);
	}

	@SuppressWarnings("deprecation") // 26.3 still routes item tooltips through this hook; no replacement override exists on Item.
	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display,
			Consumer<Component> consumer, TooltipFlag flag) {
		consumer.accept(Component.literal("§3A fragment of a decoded genome."));
		consumer.accept(Component.literal("§7Brew §fAntibiotics §7+ §f3 Genome Fragments §7+ §fNether Wart"));
		consumer.accept(Component.literal("§7into an §fEngineered Serum§7."));
	}
}

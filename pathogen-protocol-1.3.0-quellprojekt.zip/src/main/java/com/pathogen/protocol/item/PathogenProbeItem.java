package com.pathogen.protocol.item;

import java.util.function.Consumer;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;

/**
 * A swab run over something contaminated. Carries the exact specimen that
 * marked the surface it was taken from — feed it to the Research Bench.
 */
public class PathogenProbeItem extends Item {
	public PathogenProbeItem(Properties properties) {
		super(properties);
	}

	@SuppressWarnings("deprecation") // 26.3 still routes item tooltips through this hook; no replacement override exists on Item.
	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display,
			Consumer<Component> consumer, TooltipFlag flag) {
		SampleData.appendTooltip(stack, consumer);
	}
}

package com.pathogen.protocol.item;

import java.util.List;

import com.pathogen.protocol.VirusSpec;

import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.component.CustomData;

/**
 * Reads and writes virus samples stored on item stacks. A sample is the full
 * spec plus its current (possibly fed) severity, so every consumer — tooltips,
 * microscopes, benches — works client-side without touching the world archive.
 */
public final class SampleData {
	private static final String KEY = "pathogen_protocol";

	private SampleData() {
	}

	/** A specimen read off a stack: the spec, with the tag's current severity applied. */
	public record Sample(VirusSpec spec, int severity) {
		public VirusSpec liveSpec() {
			return spec.withSeverity(severity);
		}
	}

	public static ItemStack createSample(net.minecraft.world.item.Item item, VirusSpec spec, int severity) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_DATA, CustomData.of(singleKey(spec.toTag(severity))));
		return stack;
	}

	/** Rebuilds a sample stack from a bare specimen tag (as stored by block entities). */
	public static ItemStack createFromTag(net.minecraft.world.item.Item item, CompoundTag tag) {
		VirusSpec spec = VirusSpec.fromTag(tag);
		if (spec == null) {
			return ItemStack.EMPTY;
		}
		return createSample(item, spec, VirusSpec.severityOf(tag));
	}

	private static CompoundTag singleKey(CompoundTag tag) {
		CompoundTag wrapper = new CompoundTag();
		wrapper.put(KEY, tag);
		return wrapper;
	}

	public static boolean hasSample(ItemStack stack) {
		return read(stack) != null;
	}

	/** Null when the stack carries no valid sample. */
	public static Sample read(ItemStack stack) {
		CustomData data = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY);
		CompoundTag root = data.copyTag();
		CompoundTag tag = root.getCompoundOrEmpty(KEY);
		if (tag.isEmpty()) {
			// Tolerate a bare tag.
			tag = root;
		}
		VirusSpec spec = VirusSpec.fromTag(tag);
		if (spec == null) {
			return null;
		}
		return new Sample(spec, VirusSpec.severityOf(tag));
	}

	/** Overwrites the whole specimen on the stack (used when cultivation mutates it). */
	public static boolean rewrite(ItemStack stack, VirusSpec spec, int severity) {
		if (read(stack) == null) {
			return false;
		}
		stack.set(DataComponents.CUSTOM_DATA, CustomData.of(singleKey(spec.toTag(severity))));
		return true;
	}

	/** Overwrites the sample's current severity on the stack (culture-plate feeding). */
	public static boolean setSeverity(ItemStack stack, int severity) {
		Sample sample = read(stack);
		if (sample == null) {
			return false;
		}
		stack.set(DataComponents.CUSTOM_DATA, CustomData.of(singleKey(sample.spec().toTag(severity))));
		return true;
	}

	public static String specimenName(Sample sample) {
		return sample.liveSpec().displayName();
	}

	public static List<String> symptomLabels(Sample sample) {
		return sample.spec().symptoms().stream().map(VirusSpec.Symptom::label).toList();
	}

	/** The full dossier block, shared by vials, probes and syringes. */
	public static void appendTooltip(ItemStack stack, Consumer<Component> consumer) {
		Sample sample = read(stack);
		if (sample == null) {
			consumer.accept(Component.literal("§8An inert, unreadable sample."));
			return;
		}
		VirusSpec live = sample.liveSpec();
		String spread = switch (live.spread()) {
			case CONTACT -> "Contact (blood & saliva)";
			case AIRBORNE -> "Airborne (radius " + (int) live.effectiveRadius(sample.severity()) + ")";
			case FOOD -> "Foodborne (the harvest)";
		};
		consumer.accept(Component.literal("§8" + live.lore()));
		consumer.accept(Component.literal("§7Severity: §c" + live.severityBar(sample.severity())
				+ " §8(" + sample.severity() + "/" + VirusSpec.MAX_SEVERITY + ")"));
		consumer.accept(Component.literal("§7Danger:   §6" + live.dangerLabel(sample.severity())));
		consumer.accept(Component.literal("§7Transmission: §f" + spread));
		consumer.accept(Component.literal("§7Symptoms: §f" + String.join("§7, §f", symptomLabels(sample))));
		consumer.accept(Component.literal("§8Genome № " + live.id()));
	}
}

package com.pathogen.protocol.item;

import com.pathogen.protocol.Infection;
import com.pathogen.protocol.InfectionManager;
import com.pathogen.protocol.ModEffects;
import com.pathogen.protocol.VirusArchive;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Engineered Serum — an antibiotic programmed against every genome the
 * Research Bench has fully decoded in this world. If your affliction isn't
 * understood yet, it might as well be acid.
 */
public class SerumItem extends Item {
	public SerumItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		ItemStack stack = player.getItemInHand(hand);
		Infection current = InfectionManager.getInfection(player);
		if (current == null) {
			player.displayClientMessage(Component.literal("§7You are not infected. Save it for the dark days."), false);
			return InteractionResult.FAIL;
		}
		VirusArchive archive = VirusArchive.get((ServerLevel) level);
		if (!archive.isDecoded(current.spec().id())) {
			player.displayClientMessage(Component.literal("§cThe serum finds no purchase — §f" + current.spec().displayName()
					+ " §chas not been sequenced. Bring a sample to the Research Bench."), false);
			return InteractionResult.FAIL;
		}
		InfectionManager.cure(player);
		stack.shrink(1);
		level.playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0f, 1.35f);
		player.displayClientMessage(Component.literal("§aYour blood remembers the enemy. The serum burns §f" + current.spec().displayName()
				+ " §aout of your system."), false);
		return InteractionResult.SUCCESS;
	}

	@SuppressWarnings("deprecation") // 26.3 still routes item tooltips through this hook; no replacement override exists on Item.
	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context,
			net.minecraft.world.item.component.TooltipDisplay display,
			java.util.function.Consumer<Component> consumer, net.minecraft.world.item.TooltipFlag flag) {
		consumer.accept(Component.literal("§aEngineered to erase any fully-decoded genome."));
		consumer.accept(Component.literal("§7Brew: §fAntibiotics §7+ §f3 Genome Fragments §7+ §fNether Wart"));
		consumer.accept(Component.literal("§8Undecoded strains are unaffected."));
	}
}

package com.pathogen.protocol.item;

import com.pathogen.protocol.Infection;
import com.pathogen.protocol.InfectionManager;
import com.pathogen.protocol.ModEffects;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Broad-spectrum antibiotics. Only effective against the weakest wild
 * specimen (severity 1) — anything stronger shrugs it off like acid.
 */
public class AntibioticItem extends Item {
	public AntibioticItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		ItemStack stack = player.getItemInHand(hand);
		Infection current = InfectionManager.getInfection(player);
		if (current == null) {
			player.displayClientMessage(Component.literal("§7You are not infected."), false);
			return InteractionResult.FAIL;
		}
		if (current.severity() > 1) {
			player.displayClientMessage(Component.literal("§cAntibiotics can't touch " + current.spec().displayName()
					+ " §8(severity " + current.severity() + ")§c. It demands a sequenced serum."), false);
			return InteractionResult.FAIL;
		}
		InfectionManager.cure(player);
		stack.shrink(1);
		level.playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0f, 1.1f);
		player.displayClientMessage(Component.literal("§aThe antibiotics flush the fever out of your system."), false);
		return InteractionResult.SUCCESS;
	}
}

package com.pathogen.protocol.item;

import java.util.function.Consumer;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;

/**
 * A sealed vial of living sample. The full specimen (genome, color, symptoms,
 * severity) is carried on the stack — see {@link SampleData}.
 */
public class VirusVialItem extends Item {
	public VirusVialItem(Properties properties) {
		super(properties);
	}

	@SuppressWarnings("deprecation") // 26.3 still routes item tooltips through this hook; no replacement override exists on Item.
	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display,
			Consumer<Component> consumer, TooltipFlag flag) {
		SampleData.appendTooltip(stack, consumer);
	}
}

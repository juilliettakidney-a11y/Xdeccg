package com.pathogen.protocol.item;

import com.pathogen.protocol.Infection;
import com.pathogen.protocol.InfectionManager;
import com.pathogen.protocol.ModItems;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Right-click an infected creature to extract a viable sample of its strain.
 * The sample carries the exact severity living inside the host.
 */
public class EmptyVialItem extends Item {
	public EmptyVialItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
		Level level = target.level();
		Infection infection = InfectionManager.getInfection(target);
		if (infection == null) {
			return InteractionResult.PASS;
		}
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		stack.shrink(1);
		ItemStack sample = SampleData.createSample(ModItems.VIRUS_VIAL, infection.spec(), infection.severity());
		Containers.dropItemStack(level, target.getX(), target.getY() + 0.5, target.getZ(), sample);
		if (level instanceof ServerLevel serverLevel) {
			serverLevel.sendParticles(ParticleTypes.ENCHANT, target.getX(), target.getY() + 1.0, target.getZ(),
					12, 0.3, 0.4, 0.3, 0.15);
		}
		level.playSound(null, target.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0f, 0.7f);
		player.displayClientMessage(Component.literal("§7You draw a " + infection.spec().displayName()
				+ " sample — it clatters to the ground."), false);
		return InteractionResult.SUCCESS;
	}
}

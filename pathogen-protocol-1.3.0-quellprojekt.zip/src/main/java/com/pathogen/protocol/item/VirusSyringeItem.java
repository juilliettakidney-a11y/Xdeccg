package com.pathogen.protocol.item;

import com.pathogen.protocol.Infection;
import com.pathogen.protocol.InfectionManager;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * A loaded syringe. Unlike a contaminated scratch, a needle bypasses a sealed
 * hazmat suit — delivery is guaranteed. The specimen rides on the stack.
 */
public class VirusSyringeItem extends Item {
	public VirusSyringeItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
		Level level = target.level();
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}
		SampleData.Sample sample = SampleData.read(stack);
		if (sample == null) {
			player.displayClientMessage(Component.literal("§8The syringe is empty and inert. Dual-wield it with a vial to load it."), false);
			return InteractionResult.FAIL;
		}
		Infection current = InfectionManager.getInfection(target);
		if (current != null && current.spec().id().equals(sample.spec().id())) {
			player.displayClientMessage(Component.literal("That host already carries " + sample.spec().displayName() + "."), false);
			return InteractionResult.PASS;
		}
		// Direct delivery — the suit cannot filter a syringe.
		InfectionManager.forceInfect(target, sample.spec(), sample.severity(), player);
		stack.shrink(1);
		level.playSound(null, target.blockPosition(), SoundEvents.BREWING_STAND_BREW, SoundSource.PLAYERS, 1.0f, 0.6f);
		if (target instanceof Player victim) {
			victim.displayClientMessage(Component.literal("§4A needle slips through your defenses — §f" + sample.spec().displayName() + " §4takes hold."), false);
		}
		player.displayClientMessage(Component.literal("Injected " + target.getType().getDescription().getString()
				+ " with §f" + sample.spec().displayName() + "§7 (severity " + sample.severity() + ")."), false);
		return InteractionResult.SUCCESS;
	}

	@SuppressWarnings("deprecation") // 26.3 still routes item tooltips through this hook; no replacement override exists on Item.
	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context,
			net.minecraft.world.item.component.TooltipDisplay display,
			java.util.function.Consumer<Component> consumer, net.minecraft.world.item.TooltipFlag flag) {
		SampleData.appendTooltip(stack, consumer);
		consumer.accept(Component.literal("§cBypasses sealed hazmat suits."));
	}
}

package com.pathogen.protocol;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;

public final class ModEffects {
	public static Holder.Reference<MobEffect> VIRAL_INFECTION;

	private ModEffects() {
	}

	public static void register() {
		Identifier id = Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, "viral_infection");
		VIRAL_INFECTION = Registry.registerForHolder(BuiltInRegistries.MOB_EFFECT, id, new ViralInfectionEffect());
	}
}

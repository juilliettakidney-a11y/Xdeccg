package com.pathogen.protocol;

import net.fabricmc.api.ModInitializer;

import net.minecraft.resources.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PathogenProtocol implements ModInitializer {
	public static final String MOD_ID = "pathogen_protocol";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModAttachments.register();
		ModEffects.register();
		ModItems.register();
		ModBlocks.register();
		com.pathogen.protocol.block.entity.ModBlockEntities.register();
		com.pathogen.protocol.menu.ModMenuTypes.register();
		com.pathogen.protocol.net.ModNetworking.register();
		ModCreativeTab.register();
		InfectionEvents.register();
		PathogenCommand.register();
		LOGGER.info("Pathogen Protocol initialized — containment is recommended.");
	}
}

package com.pathogen.protocol;

import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Blocks touched by someone carrying a virus remain contagious for a while.
 * Infected handling, breathing, leaning and sneezing on a thing leaves the
 * thing marked; a later player who touches it risks the same strain.
 *
 * <p>Contamination only applies in the overworld (the ledger lives in the
 * overworld's saved data) and fades after {@link #CONTAMINATION_TICKS}.</p>
 */
public final class ContaminationManager {
	/** Five minutes of contagion per touch. */
	public static final int CONTAMINATION_TICKS = 6000;

	private ContaminationManager() {
	}

	/** True when this level is the one the contamination ledger tracks. */
	public static boolean isTrackedLevel(Level level) {
		return level instanceof ServerLevel serverLevel && serverLevel.dimension() == Level.OVERWORLD;
	}

	public static void contaminate(ServerLevel level, BlockPos pos, Infection infection) {
		if (!isTrackedLevel(level)) {
			return;
		}
		VirusArchive archive = VirusArchive.get(level);
		archive.contaminate(pos.immutable(), infection.spec().id(), infection.severity(), CONTAMINATION_TICKS);
	}

	/**
	 * Everything a player does on a block: infected hands leave a mark, and a
	 * marked block has teeth. Call on use, attack and break.
	 */
	public static void touch(LivingEntity player, ServerLevel level, BlockPos pos) {
		if (!isTrackedLevel(level)) {
			return;
		}
		VirusArchive archive = VirusArchive.get(level);

		Infection carrier = InfectionManager.getInfection(player);
		if (carrier != null) {
			archive.contaminate(pos.immutable(), carrier.spec().id(), carrier.severity(), CONTAMINATION_TICKS);
		}

		VirusArchive.Contamination mark = archive.contaminationAt(pos);
		if (mark == null) {
			return;
		}
		if (!(player instanceof net.minecraft.server.level.ServerPlayer serverPlayer)) {
			return;
		}
		if (InfectionManager.isHazmatSealed(serverPlayer)
				|| serverPlayer.getAbilities().instabuild || serverPlayer.isSpectator()) {
			return;
		}
		if (InfectionManager.getInfection(serverPlayer) != null) {
			return;
		}
		VirusSpec spec = archive.getSpec(mark.genome());
		if (spec == null) {
			return;
		}
		float chance = Math.min(0.4f, 0.12f + 0.04f * mark.severity());
		if (serverPlayer.getRandom().nextFloat() >= chance) {
			return;
		}
		if (InfectionManager.tryInfect(serverPlayer, spec, mark.severity(), null)) {
			serverPlayer.displayClientMessage(Component.literal(
					"§5Something on that block seeps into your fingertips... §f" + spec.displayName() + " §5takes hold."), false);
		}
	}

	/** World tick: decays taints, and puffs colored dust off still-tainted blocks. */
	public static void tick(ServerLevel level) {
		if (!isTrackedLevel(level)) {
			return;
		}
		long time = level.getGameTime();
		if (time % 20 != 0) {
			return;
		}
		VirusArchive archive = VirusArchive.get(level);
		List<VirusArchive.Contamination> alive = archive.tickContaminations(20);
		if (alive.isEmpty()) {
			return;
		}
		for (VirusArchive.Contamination mark : alive) {
			BlockPos pos = mark.pos();
			if (!level.isLoaded(pos)) {
				continue;
			}
			BlockState state = level.getBlockState(pos);
			if (state.isAir()) {
				archive.clearContamination(pos);
				continue;
			}
			VirusSpec spec = archive.getSpec(mark.genome());
			if (spec == null) {
				continue;
			}
			level.sendParticles(new DustParticleOptions(spec.color(), 0.8f),
					pos.getX() + 0.5, pos.getY() + 0.9, pos.getZ() + 0.5,
					2, 0.3, 0.25, 0.3, 0.01);
		}
	}

	public static void clearAt(ServerLevel level, BlockPos pos) {
		if (!isTrackedLevel(level)) {
			return;
		}
		VirusArchive.get(level).clearContamination(pos);
	}
}

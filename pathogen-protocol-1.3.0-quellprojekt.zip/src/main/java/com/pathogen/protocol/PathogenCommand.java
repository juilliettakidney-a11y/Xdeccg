package com.pathogen.protocol;

import java.util.List;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;

import com.pathogen.protocol.item.SampleData;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

/**
 * /pathogen_protocol name &lt;name…&gt; — name the specimen you are holding.
 * Only the player who first analyzed a strain under the microscope owns the
 * naming rights for it.
 *
 * /pathogen_protocol journal — print the mutation ledger of the held specimen.
 */
public final class PathogenCommand {
	private PathogenCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(literal("pathogen_protocol")
						.then(literal("name")
								.then(argument("name", StringArgumentType.greedyString())
										.executes(PathogenCommand::name)))
						.then(literal("journal").executes(PathogenCommand::journal))));
	}

	private static SampleData.Sample heldSample(CommandSourceStack source) {
		ServerPlayer player = source.getPlayer();
		if (player == null) {
			return null;
		}
		ItemStack main = player.getMainHandItem();
		SampleData.Sample sample = SampleData.read(main);
		if (sample == null) {
			SampleData.Sample off = SampleData.read(player.getOffhandItem());
			return off;
		}
		return sample;
	}

	private static int name(CommandContext<CommandSourceStack> ctx) {
		CommandSourceStack source = ctx.getSource();
		ServerPlayer player = source.getPlayer();
		if (player == null) {
			source.sendFailure(Component.literal("§cOnly players can name a strain."));
			return 0;
		}
		SampleData.Sample sample = heldSample(source);
		if (sample == null) {
			source.sendFailure(Component.literal("§cHold the specimen you want to name (vial, probe or syringe)."));
			return 0;
		}
		String requested = StringArgumentType.getString(ctx, "name");
		VirusArchive archive = VirusArchive.get((ServerLevel) player.level());
		VirusSpec spec = sample.spec();
		archive.registerGenome(spec);

		String error = archive.nameGenome(spec.id(), player.getName().getString(), requested);
		if (error != null) {
			source.sendFailure(Component.literal("§c" + error));
			return 0;
		}
		source.sendSuccess(() -> Component.literal("§aThe specimen is catalogued as §l" + requested.trim()
				+ "§r§a. The archive will remember."), false);
		return 1;
	}

	private static int journal(CommandContext<CommandSourceStack> ctx) {
		CommandSourceStack source = ctx.getSource();
		ServerPlayer player = source.getPlayer();
		if (player == null) {
			source.sendFailure(Component.literal("§cOnly players can read the ledger."));
			return 0;
		}
		SampleData.Sample sample = heldSample(source);
		if (sample == null) {
			source.sendFailure(Component.literal("§cHold the specimen whose history you want to read."));
			return 0;
		}
		VirusArchive archive = VirusArchive.get((ServerLevel) player.level());
		List<String> ledger = archive.mutationsOf(sample.spec().id());
		String name = archive.displayNameOf(sample.spec());
		source.sendSuccess(() -> Component.literal("§6──── Mutation Ledger — §f" + name + " §6────"), false);
		if (ledger.isEmpty()) {
			source.sendSuccess(() -> Component.literal("§8No recorded mutations. The strain is, so far, true to its nature."), false);
			return 1;
		}
		int from = Math.max(0, ledger.size() - 8);
		for (int i = from; i < ledger.size(); i++) {
			int index = i + 1;
			String line = ledger.get(i);
			source.sendSuccess(() -> Component.literal("§7" + index + ". §f" + line), false);
		}
		source.sendSuccess(() -> Component.literal("§8" + ledger.size() + " recorded event(s)" + (from > 0 ? " — showing last 8" : "") + "."), false);
		return 1;
	}
}

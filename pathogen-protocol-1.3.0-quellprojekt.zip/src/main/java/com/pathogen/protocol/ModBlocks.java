package com.pathogen.protocol;

import java.util.function.Function;

import com.pathogen.protocol.block.CentrifugeBlock;
import com.pathogen.protocol.block.CulturePlateBlock;
import com.pathogen.protocol.block.IncubatorBlock;
import com.pathogen.protocol.block.LabTableBlock;
import com.pathogen.protocol.block.MicroscopeBlock;
import com.pathogen.protocol.block.ResearchBenchBlock;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class ModBlocks {
	public static Block LAB_TABLE;
	public static Block MICROSCOPE;
	public static Block CENTRIFUGE;
	public static Block INCUBATOR;
	public static Block RESEARCH_BENCH;
	public static Block CULTURE_PLATE;
	public static Block LAB_COUNTER;
	public static Block LAB_CABINET;
	public static Block LAB_WALL;
	public static Block LAB_FLOOR;
	public static Block HAZARD_STRIPE;

	private ModBlocks() {
	}

	public static void register() {
		LAB_TABLE = register("lab_table", key -> new LabTableBlock(
				BlockBehaviour.Properties.of().strength(3.0f, 4.0f).sound(SoundType.WOOD).setId(key)));
		MICROSCOPE = register("microscope", key -> new MicroscopeBlock(
				BlockBehaviour.Properties.of().strength(4.0f, 6.0f).sound(SoundType.METAL).noOcclusion().setId(key)));
		CENTRIFUGE = register("centrifuge", key -> new CentrifugeBlock(
				BlockBehaviour.Properties.of().strength(4.0f, 6.0f).sound(SoundType.METAL).noOcclusion().setId(key)));
		INCUBATOR = register("incubator", key -> new IncubatorBlock(
				BlockBehaviour.Properties.of().strength(4.0f, 6.0f).sound(SoundType.METAL).noOcclusion().setId(key)));
		RESEARCH_BENCH = register("research_bench", key -> new ResearchBenchBlock(
				BlockBehaviour.Properties.of().strength(4.0f, 6.0f).sound(SoundType.METAL).noOcclusion().setId(key)));
		CULTURE_PLATE = register("culture_plate", key -> new CulturePlateBlock(
				BlockBehaviour.Properties.of().strength(2.0f, 3.0f).sound(SoundType.GLASS).noOcclusion().setId(key)));
		LAB_COUNTER = register("lab_counter", key -> new Block(
				BlockBehaviour.Properties.of().strength(3.5f, 6.0f).sound(SoundType.METAL).setId(key)));
		LAB_CABINET = register("lab_cabinet", key -> new Block(
				BlockBehaviour.Properties.of().strength(3.5f, 6.0f).sound(SoundType.METAL).setId(key)));
		LAB_WALL = register("lab_wall", key -> new Block(
				BlockBehaviour.Properties.of().strength(3.0f, 5.0f).sound(SoundType.STONE).setId(key)));
		LAB_FLOOR = register("lab_floor", key -> new Block(
				BlockBehaviour.Properties.of().strength(3.5f, 5.0f).sound(SoundType.STONE).setId(key)));
		HAZARD_STRIPE = register("hazard_stripe", key -> new Block(
				BlockBehaviour.Properties.of().strength(2.0f, 3.0f).sound(SoundType.STONE).setId(key)));
	}

	private static Block register(String name, Function<ResourceKey<Block>, Block> factory) {
		Identifier id = Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, name);
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
		Block block = factory.apply(blockKey);
		Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
		Item blockItem = new BlockItem(block, new Item.Properties().setId(itemKey));
		Registry.register(BuiltInRegistries.ITEM, itemKey, blockItem);
		ModItems.ALL.add(blockItem);
		ModItems.BLOCK_ITEMS.add(blockItem);
		return block;
	}
}

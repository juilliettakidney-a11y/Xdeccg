package com.pathogen.protocol;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public final class ModCreativeTab {
	private ModCreativeTab() {
	}

	public static void register() {
		CreativeModeTab tab = FabricItemGroup.builder()
				.title(Component.translatable("itemGroup.pathogen_protocol.pathogen_protocol"))
				.icon(() -> new ItemStack(ModItems.VIRUS_VIAL))
				.displayItems((parameters, output) -> {
					for (var item : ModItems.BLOCK_ITEMS) {
						output.accept(item);
					}
					for (var item : ModItems.ALL) {
						if (!ModItems.BLOCK_ITEMS.contains(item)) {
							output.accept(item);
						}
					}
				})
				.build();
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB,
				Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, "pathogen_protocol"), tab);
	}
}

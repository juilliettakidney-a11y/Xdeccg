package com.pathogen.protocol;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;

/**
 * One effect for the whole outbreak. Which genome lives inside the host —
 * and how strong it has grown — rides in the entity attachments, not the
 * amplifier, so strains of any strength share this marker.
 */
public class ViralInfectionEffect extends MobEffect {
	public ViralInfectionEffect() {
		super(MobEffectCategory.HARMFUL, 0x8A1F2D);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		// Pulse every 2 seconds; stage derives from elapsed time, not amplifier.
		return duration % 40 == 0;
	}

	@Override
	public boolean applyEffectTick(ServerLevel level, LivingEntity entity, int amplifier) {
		Infection infection = InfectionManager.getInfection(entity);
		if (infection == null) {
			// Orphaned marker (genome lost from the archive) — lifted by getInfection already.
			return true;
		}
		MobEffectInstance instance = entity.getEffect(ModEffects.VIRAL_INFECTION);
		int remaining = instance != null ? instance.getDuration() : infection.durationTicks();
		InfectionManager.tickInfection(level, entity, infection, remaining);
		return true;
	}
}

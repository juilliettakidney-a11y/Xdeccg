package com.pathogen.protocol;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.pathogen.protocol.item.AntibioticItem;
import com.pathogen.protocol.item.EmptyVialItem;
import com.pathogen.protocol.item.GenomeFragmentItem;
import com.pathogen.protocol.item.PathogenProbeItem;
import com.pathogen.protocol.item.SerumItem;
import com.pathogen.protocol.item.SterileSwabItem;
import com.pathogen.protocol.item.VirusSyringeItem;
import com.pathogen.protocol.item.VirusVialItem;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class ModItems {
	public static Item EMPTY_VIAL;
	public static Item EMPTY_SYRINGE;
	public static Item CULTURE_MEDIUM;
	public static Item PATHOGEN_PROTEIN;
	public static Item ANTIBIOTICS;
	public static Item SERUM;
	public static Item GENOME_FRAGMENT;
	public static Item HAZMAT_REPAIR_KIT;
	public static Item HAZMAT_SUIT;
	public static Item BROKEN_HAZMAT_SUIT;

	public static Item VIRUS_VIAL;
	public static Item VIRUS_SYRINGE;
	public static Item PATHOGEN_PROBE;
	public static Item STERILE_SWAB;

	/** Every registered item, block items appended by ModBlocks.register(). */
	public static final List<Item> ALL = new ArrayList<>();
	/** Just the block items (first in the creative tab). */
	public static final List<Item> BLOCK_ITEMS = new ArrayList<>();

	// Custom equipment assets point at assets/pathogen_protocol/equipment/<name>.json
	public static final ResourceKey<EquipmentAsset> HAZMAT_ASSET =
			ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, "hazmat"));
	public static final ResourceKey<EquipmentAsset> HAZMAT_BROKEN_ASSET =
			ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, "hazmat_broken"));

	public static final ArmorMaterial HAZMAT_MATERIAL = new ArmorMaterial(
			15, Map.of(ArmorType.CHESTPLATE, 6), 8, SoundEvents.ARMOR_EQUIP_IRON,
			1.0f, 0.0f, ItemTags.REPAIRS_IRON_ARMOR, HAZMAT_ASSET);

	/** A torn suit: no armor, no seal, no salvation. Cosmetic warning for the corrected. */
	public static final ArmorMaterial HAZMAT_BROKEN_MATERIAL = new ArmorMaterial(
			8, Map.of(ArmorType.CHESTPLATE, 0), 1, SoundEvents.ARMOR_EQUIP_LEATHER,
			0.0f, 0.0f, ItemTags.REPAIRS_LEATHER_ARMOR, HAZMAT_BROKEN_ASSET);

	private ModItems() {
	}

	public static void register() {
		EMPTY_VIAL = register("empty_vial", id -> new EmptyVialItem(props(id)));
		EMPTY_SYRINGE = register("empty_syringe", id -> new Item(props(id)));
		CULTURE_MEDIUM = register("culture_medium", id -> new Item(props(id)));
		PATHOGEN_PROTEIN = register("pathogen_protein", id -> new Item(props(id)));
		ANTIBIOTICS = register("antibiotics", id -> new AntibioticItem(props(id)));
		SERUM = register("serum", id -> new SerumItem(props(id).stacksTo(16).rarity(net.minecraft.world.item.Rarity.RARE)));
		GENOME_FRAGMENT = register("genome_fragment", id -> new GenomeFragmentItem(props(id).stacksTo(16).rarity(net.minecraft.world.item.Rarity.UNCOMMON)));
		HAZMAT_REPAIR_KIT = register("hazmat_repair_kit", id -> new Item(props(id)));

		VIRUS_VIAL = register("virus_vial", id -> new VirusVialItem(props(id).stacksTo(16).rarity(net.minecraft.world.item.Rarity.UNCOMMON)));
		VIRUS_SYRINGE = register("virus_syringe", id -> new VirusSyringeItem(props(id).stacksTo(16).rarity(net.minecraft.world.item.Rarity.UNCOMMON)));
		PATHOGEN_PROBE = register("pathogen_probe", id -> new PathogenProbeItem(props(id).stacksTo(16).rarity(net.minecraft.world.item.Rarity.UNCOMMON)));
		STERILE_SWAB = register("sterile_swab", id -> new SterileSwabItem(props(id)));

		HAZMAT_SUIT = register("hazmat_suit", id -> new Item(props(id).humanoidArmor(HAZMAT_MATERIAL, ArmorType.CHESTPLATE)));
		BROKEN_HAZMAT_SUIT = register("broken_hazmat_suit", id -> new Item(props(id).humanoidArmor(HAZMAT_BROKEN_MATERIAL, ArmorType.CHESTPLATE)));
	}

	private static Item.Properties props(ResourceKey<Item> id) {
		return new Item.Properties().setId(id);
	}

	private static Item register(String name, java.util.function.Function<ResourceKey<Item>, Item> factory) {
		Identifier id = Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, name);
		ResourceKey<Item> key = ResourceKey.create(net.minecraft.core.registries.Registries.ITEM, id);
		Item registered = factory.apply(key);
		Registry.register(BuiltInRegistries.ITEM, key, registered);
		ALL.add(registered);
		return registered;
	}
}

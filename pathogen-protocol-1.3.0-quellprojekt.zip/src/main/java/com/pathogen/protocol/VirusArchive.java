package com.pathogen.protocol;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

/**
 * The world's record of the outbreak: every genome ever generated, how far
 * its sequencing has progressed, which genomes are fully decoded, and which
 * blocks are still contaminated with a sample.
 *
 * <p>Progress is tracked per genome id, but the decoding target is raised by
 * the severity of the strongest sample ever loaded at a bench — so feeding a
 * Culture Plate genuinely makes an outbreak harder to cure, not just deadlier.</p>
 */
public final class VirusArchive extends SavedData {
	public static final int MAX_GENOMES = 1024;
	public static final int MAX_CONTAMINATIONS = 128;

	private static final Codec<Set<String>> SET_CODEC =
			Codec.STRING.listOf().xmap(HashSet::new, ArrayList::new);

	public record Contamination(BlockPos pos, String genome, int severity, int ticksLeft) {
		public static final Codec<Contamination> CODEC = RecordCodecBuilder.create(instance -> instance.group(
				BlockPos.CODEC.fieldOf("pos").forGetter(Contamination::pos),
				Codec.STRING.fieldOf("genome").forGetter(Contamination::genome),
				Codec.INT.fieldOf("severity").forGetter(Contamination::severity),
				Codec.INT.fieldOf("ticks_left").forGetter(Contamination::ticksLeft)
			).apply(instance, Contamination::new));
	}

	public static final Codec<VirusArchive> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.unboundedMap(Codec.STRING, VirusSpec.CODEC).optionalFieldOf("genomes", Map.of())
					.forGetter(archive -> archive.genomes),
			Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("progress", Map.of())
					.forGetter(archive -> archive.progress),
			Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("targets", Map.of())
					.forGetter(archive -> archive.targets),
			SET_CODEC.optionalFieldOf("decoded", Set.of())
					.forGetter(archive -> archive.decoded),
			Contamination.CODEC.listOf().optionalFieldOf("contaminated", List.of())
					.forGetter(archive -> archive.contaminations),
			Codec.unboundedMap(Codec.STRING, Codec.STRING).optionalFieldOf("discoverers", Map.of())
					.forGetter(archive -> archive.discoverers),
			Codec.unboundedMap(Codec.STRING, Codec.STRING).optionalFieldOf("custom_names", Map.of())
					.forGetter(archive -> archive.customNames),
			SET_CODEC.optionalFieldOf("scanned", Set.of())
					.forGetter(archive -> archive.scanned),
			Codec.unboundedMap(Codec.STRING, Codec.STRING.listOf()).optionalFieldOf("mutations", Map.of())
					.forGetter(archive -> archive.mutations))
			.apply(instance, VirusArchive::new));

	public static final SavedDataType<VirusArchive> TYPE = new SavedDataType<>(
			Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, "virus_archive").toString(),
			VirusArchive::new, CODEC, DataFixTypes.LEVEL);

	private final Map<String, VirusSpec> genomes;
	private final Map<String, Integer> progress;
	private final Map<String, Integer> targets;
	private final Set<String> decoded;
	private final List<Contamination> contaminations;
	/** genomeId -> name of the player who first analyzed it (the one who may name it). */
	private final Map<String, String> discoverers;
	/** genomeId -> the name the discoverer gave the strain. */
	private final Map<String, String> customNames;
	/** genomeIds that have been looked at through a microscope at least once. */
	private final Set<String> scanned;
	/** genomeId -> chronological log of observed mutations (culture feeding, golden carrot, drift). */
	private final Map<String, List<String>> mutations;

	public VirusArchive() {
		this(new HashMap<>(), new HashMap<>(), new HashMap<>(), new HashSet<>(), new ArrayList<>(),
				new HashMap<>(), new HashMap<>(), new HashSet<>(), new HashMap<>());
	}

	private VirusArchive(Map<String, VirusSpec> genomes, Map<String, Integer> progress,
			Map<String, Integer> targets, Set<String> decoded, List<Contamination> contaminations,
			Map<String, String> discoverers, Map<String, String> customNames, Set<String> scanned,
			Map<String, List<String>> mutations) {
		this.genomes = new HashMap<>(genomes);
		this.progress = new HashMap<>(progress);
		this.targets = new HashMap<>(targets);
		this.decoded = new HashSet<>(decoded);
		this.contaminations = new ArrayList<>(contaminations);
		this.discoverers = new HashMap<>(discoverers);
		this.customNames = new HashMap<>(customNames);
		this.scanned = new HashSet<>(scanned);
		this.mutations = new HashMap<>();
		for (Map.Entry<String, List<String>> entry : mutations.entrySet()) {
			this.mutations.put(entry.getKey(), new ArrayList<>(entry.getValue()));
		}
		sanitize();
	}

	private void sanitize() {
		// Anything we no longer recognize (e.g. pre-1.1 identifiers) is dropped rather than trusted.
		progress.keySet().removeIf(id -> !genomes.containsKey(id));
		targets.keySet().removeIf(id -> !genomes.containsKey(id));
		decoded.removeIf(id -> !genomes.containsKey(id));
		contaminations.removeIf(entry -> !genomes.containsKey(entry.genome()));
		discoverers.keySet().removeIf(id -> !genomes.containsKey(id));
		customNames.keySet().removeIf(id -> !genomes.containsKey(id));
		scanned.removeIf(id -> !genomes.containsKey(id));
		mutations.keySet().removeIf(id -> !genomes.containsKey(id));
		setDirty();
	}

	public static VirusArchive get(ServerLevel level) {
		return level.getServer().overworld().getDataStorage().computeIfAbsent(TYPE);
	}

	// ---------------------------------------------------------- genomes

	public VirusSpec getSpec(String id) {
		return genomes.get(id);
	}

	/** Registers a freshly generated specimen. Evicts the oldest entry if the archive is full. */
	public void registerGenome(VirusSpec spec) {
		if (genomes.containsKey(spec.id())) {
			return;
		}
		if (genomes.size() >= MAX_GENOMES) {
			String eldest = genomes.keySet().iterator().next();
			genomes.remove(eldest);
			progress.remove(eldest);
			targets.remove(eldest);
			decoded.remove(eldest);
			contaminations.removeIf(entry -> entry.genome().equals(eldest));
			discoverers.remove(eldest);
			customNames.remove(eldest);
			scanned.remove(eldest);
			mutations.remove(eldest);
		}
		genomes.put(spec.id(), spec);
		setDirty();
	}

	public boolean isRegistered(String id) {
		return genomes.containsKey(id);
	}

	// ---------------------------------------------------------- research

	public int progressOf(String genomeId) {
		return progress.getOrDefault(genomeId, 0);
	}

	/** The current decoding threshold; grows to the hardest specimen ever loaded. */
	public int targetOf(String genomeId) {
		return targets.getOrDefault(genomeId, 100);
	}

	public boolean isDecoded(String genomeId) {
		return decoded.contains(genomeId);
	}

	public int percentComplete(String genomeId) {
		int target = targetOf(genomeId);
		return Math.min(100, progressOf(genomeId) * 100 / Math.max(1, target));
	}

	/**
	 * Adds points toward the genome, raising (never lowering) the decoding target if the
	 * loaded sample is stronger than anything seen before. Returns true once, the moment
	 * the genome crosses into decoded.
	 */
	public boolean addResearch(VirusSpec spec, int currentSeverity, int points) {
		if (decoded.contains(spec.id())) {
			setDirty();
			return false;
		}
		int demanded = spec.researchTarget(currentSeverity);
		int target = Math.max(targets.getOrDefault(spec.id(), 100), demanded);
		targets.put(spec.id(), target);

		int next = Math.min(target, progress.getOrDefault(spec.id(), 0) + points);
		progress.put(spec.id(), next);
		boolean newlyDecoded = next >= target;
		if (newlyDecoded) {
			decoded.add(spec.id());
		}
		setDirty();
		return newlyDecoded;
	}

	// ---------------------------------------------------------- discovery & naming

	public String discovererOf(String genomeId) {
		return discoverers.get(genomeId);
	}

	public String customNameOf(String genomeId) {
		return customNames.get(genomeId);
	}

	/** The name to show players: the discoverer's chosen name, else the generated one. */
	public String displayNameOf(VirusSpec spec) {
		String custom = customNames.get(spec.id());
		return custom != null ? custom : spec.displayName();
	}

	public boolean isScanned(String genomeId) {
		return scanned.contains(genomeId);
	}

	/** Marks the genome as analyzed at a microscope; the first analyzer becomes its discoverer. */
	public void markScanned(String genomeId, String playerName) {
		scanned.add(genomeId);
		discoverers.putIfAbsent(genomeId, playerName);
		setDirty();
	}

	/**
	 * Names a strain. Only the recorded discoverer may do it, once. Returns an error
	 * string on failure, or null on success.
	 */
	public String nameGenome(String genomeId, String playerName, String requestedName) {
		if (!genomes.containsKey(genomeId)) {
			return "That genome is not in the archive.";
		}
		String discoverer = discoverers.get(genomeId);
		if (discoverer == null) {
			return "Analyze this strain at a microscope first — the first to look owns the naming rights.";
		}
		if (!discoverer.equals(playerName)) {
			return "Only the discoverer (" + discoverer + ") may name this strain.";
		}
		String cleaned = requestedName == null ? "" : requestedName.trim();
		if (cleaned.length() < 2 || cleaned.length() > 48) {
			return "Names must be 2–48 characters.";
		}
		if (!cleaned.matches("[A-Za-z0-9][A-Za-z0-9 '-]*")) {
			return "Only letters, digits, spaces and ' - are allowed.";
		}
		customNames.put(genomeId, cleaned);
		setDirty();
		return null;
	}

	// ---------------------------------------------------------- mutation ledger

	public void logMutation(String genomeId, String description) {
		mutations.computeIfAbsent(genomeId, key -> new ArrayList<>()).add(description);
		// keep the ledger bounded so the archive can't balloon forever
		List<String> log = mutations.get(genomeId);
		if (log.size() > 64) {
			mutations.put(genomeId, new ArrayList<>(log.subList(log.size() - 64, log.size())));
		}
		setDirty();
	}

	public List<String> mutationsOf(String genomeId) {
		return List.copyOf(mutations.getOrDefault(genomeId, List.of()));
	}

	public int genomeCount() {
		return genomes.size();
	}

	/** All archived genomes, oldest first. */
	public List<VirusSpec> allSpecs() {
		return new ArrayList<>(genomes.values());
	}

	// ---------------------------------------------------------- contaminated blocks

	/** Marks a block contaminated with a specimen. Refreshes the timer if already tainted. */
	public void contaminate(BlockPos pos, String genome, int severity, int ticks) {
		for (int i = 0; i < contaminations.size(); i++) {
			Contamination entry = contaminations.get(i);
			if (entry.pos().equals(pos)) {
				contaminations.set(i, new Contamination(pos, genome, Math.max(severity, entry.severity()), ticks));
				setDirty();
				return;
			}
		}
		if (contaminations.size() >= MAX_CONTAMINATIONS) {
			contaminations.remove(0);
		}
		contaminations.add(new Contamination(pos, genome, severity, ticks));
		setDirty();
	}

	public Contamination contaminationAt(BlockPos pos) {
		for (Contamination entry : contaminations) {
			if (entry.pos().equals(pos)) {
				return entry;
			}
		}
		return null;
	}

	/** Decrements timers, returns the still-contaminated entries for particle work. */
	public List<Contamination> tickContaminations(int ticksToDecay) {
		boolean changed = false;
		List<Contamination> alive = new ArrayList<>(contaminations.size());
		for (Contamination entry : contaminations) {
			int left = entry.ticksLeft() - ticksToDecay;
			if (left > 0) {
				alive.add(new Contamination(entry.pos(), entry.genome(), entry.severity(), left));
			}
			changed = true;
		}
		if (changed) {
			contaminations.clear();
			contaminations.addAll(alive);
			setDirty();
		}
		return alive;
	}

	public void clearContamination(BlockPos pos) {
		if (contaminations.removeIf(entry -> entry.pos().equals(pos))) {
			setDirty();
		}
	}
}

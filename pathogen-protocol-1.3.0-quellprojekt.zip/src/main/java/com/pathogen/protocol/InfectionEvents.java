package com.pathogen.protocol;

import com.pathogen.protocol.item.SampleData;

import net.minecraft.core.BlockPos;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;

/**
 * Wires up the infection lifecycle: infected zombies enter the world carrying
 * a generated strain, players can eat it into themselves, everything an
 * infected person handles stays contaminated for a while, and the whole thing
 * persists through the world archive.
 */
public final class InfectionEvents {
	public static final String TAG_ROLLED = "pathogen_protocol.rolled";

	private InfectionEvents() {
	}

	public static void register() {
		// ---------------------------------------------------- genesis: infected zombies walk in
		ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> {
			if (!(entity instanceof Zombie zombie) || !(level instanceof ServerLevel serverLevel)) {
				return;
			}
			if (zombie.getTags().contains(TAG_ROLLED)) {
				return;
			}
			zombie.addTag(TAG_ROLLED);

			float roll = zombie.getRandom().nextFloat();
			if (roll < 0.25f && InfectionManager.getInfection(zombie) == null) {
				VirusSpec spec = VirusSpec.generate(zombie.getRandom());
				VirusArchive.get(serverLevel).registerGenome(spec);
				InfectionManager.forceInfect(zombie, spec, spec.severity(), null);
			}
			if (zombie.getItemBySlot(EquipmentSlot.CHEST).isEmpty()
					&& zombie.getRandom().nextFloat() < 0.22f) {
				zombie.setItemSlot(EquipmentSlot.CHEST, new ItemStack(ModItems.BROKEN_HAZMAT_SUIT));
				zombie.setDropChance(EquipmentSlot.CHEST, 0.15f);
			}
		});

		// ---------------------------------------------------- contact: getting bitten
		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, amount, dealt, blocked) ->
				InfectionManager.onAfterDamage(entity, source));

		// ---------------------------------------------------- drops: vials and protein
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (!(entity instanceof Zombie zombie)) {
				return;
			}
			Infection carried = InfectionManager.getInfection(zombie);
			if (carried == null) {
				return;
			}
			Level level = zombie.level();
			Containers.dropItemStack(level, zombie.getX(), zombie.getY(), zombie.getZ(),
					SampleData.createSample(ModItems.VIRUS_VIAL, carried.spec(), carried.severity()));
			int protein = 1 + zombie.getRandom().nextInt(2);
			Containers.dropItemStack(level, zombie.getX(), zombie.getY(), zombie.getZ(),
					new ItemStack(ModItems.PATHOGEN_PROTEIN, protein));
		});

		// ---------------------------------------------------- contaminated blocks: tick + decay
		ServerTickEvents.END_WORLD_TICK.register(ContaminationManager::tick);

		// ---------------------------------------------------- food-borne: did anyone just eat?
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				int food = player.getFoodData().getFoodLevel();
				int last = player.getAttachedOrElse(ModAttachments.LAST_FOOD, -1);
				player.setAttached(ModAttachments.LAST_FOOD, food);
				if (last < 0 || food <= last) {
					continue;
				}
				Infection reservoir = InfectionManager.foodReservoir(server.overworld());
				VirusSpec spec = reservoir.spec();
				float chance = spec.foodChance(spec.severity());
				if (player.getRandom().nextFloat() < chance
						&& InfectionManager.tryInfect(player, spec, spec.severity(), null)) {
					player.displayClientMessage(Component.literal("§6Something in that bite wasn't right... §f"
							+ spec.displayName() + " §6stirs in your gut."), false);
				}
			}
		});

		// ---------------------------------------------------- contaminated blocks: touching, attacking, breaking
		UseBlockCallback.EVENT.register((player, level, hand, hitResult) -> {
			if (player instanceof ServerPlayer serverPlayer && level instanceof ServerLevel serverLevel) {
				ContaminationManager.touch(serverPlayer, serverLevel, hitResult.getBlockPos());
			}
			return InteractionResult.PASS;
		});
		AttackBlockCallback.EVENT.register((player, level, hand, pos, direction) -> {
			if (player instanceof ServerPlayer serverPlayer && level instanceof ServerLevel serverLevel) {
				ContaminationManager.touch(serverPlayer, serverLevel, pos);
			}
			return InteractionResult.PASS;
		});
		PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, blockEntity) -> {
			if (player instanceof ServerPlayer serverPlayer && level instanceof ServerLevel serverLevel) {
				ContaminationManager.touch(serverPlayer, serverLevel, pos);
			}
			return true;
		});
		PlayerBlockBreakEvents.AFTER.register((Level level, Player player, BlockPos pos, BlockState state, BlockEntity blockEntity) -> {
			if (level instanceof ServerLevel serverLevel) {
				ContaminationManager.clearAt(serverLevel, pos);
			}
		});

		// ---------------------------------------------------- the syringe: loading it takes finesse
		UseItemCallback.EVENT.register((player, level, hand) -> {
			if (!(level instanceof ServerLevel serverLevel)) {
				return InteractionResult.PASS;
			}
			ItemStack main = player.getItemInHand(hand);
			if (main.getItem() != ModItems.EMPTY_SYRINGE) {
				return InteractionResult.PASS;
			}
			InteractionHand otherHand = hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
			ItemStack off = player.getItemInHand(otherHand);
			boolean offIsVial = off.getItem() == ModItems.VIRUS_VIAL;
			boolean offIsProbe = off.getItem() == ModItems.PATHOGEN_PROBE;
			if (!offIsVial && !offIsProbe) {
				return InteractionResult.PASS;
			}
			SampleData.Sample sample = SampleData.read(off);
			if (sample == null) {
				return InteractionResult.PASS;
			}
			ItemStack filled = SampleData.createSample(ModItems.VIRUS_SYRINGE, sample.spec(), sample.severity());
			player.setItemInHand(hand, filled);
			player.setItemInHand(otherHand, offIsVial ? new ItemStack(ModItems.EMPTY_VIAL) : ItemStack.EMPTY);
			level.playSound(null, player.blockPosition(), SoundEvents.BOTTLE_FILL, SoundSource.PLAYERS, 0.8f, 0.7f);
			player.displayClientMessage(Component.literal("§7Syringe loaded with §f" + sample.spec().displayName()
					+ " §8(severity " + sample.severity() + ")§7. Handle with respect."), false);
			return InteractionResult.SUCCESS;
		});
	}
}

package com.pathogen.protocol.net;

import com.pathogen.protocol.item.SwabService;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

/** Payload registration and server-side handlers. */
public final class ModNetworking {
	private ModNetworking() {
	}

	public static void register() {
		PayloadTypeRegistry.playC2S().register(SwabActionPayload.TYPE, SwabActionPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(SwabActionPayload.TYPE, (payload, ctx) ->
				ctx.server().execute(() -> SwabService.swabContextual(ctx.player())));
	}
}

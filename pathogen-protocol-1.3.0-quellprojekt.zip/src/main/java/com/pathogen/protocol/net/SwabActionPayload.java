package com.pathogen.protocol.net;

import com.pathogen.protocol.PathogenProtocol;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Client → server: "the player pressed the swab hotkey". Carries no data of its own. */
public record SwabActionPayload() implements CustomPacketPayload {
	public static final Type<SwabActionPayload> TYPE =
			new Type<>(Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, "swab_action"));
	public static final StreamCodec<RegistryFriendlyByteBuf, SwabActionPayload> CODEC =
			StreamCodec.unit(new SwabActionPayload());

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}

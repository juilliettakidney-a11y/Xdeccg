package com.pathogen.protocol.menu;

import com.pathogen.protocol.ModItems;

import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;

/** Culture media only — anything else just gets in the way of science. */
public class CultureMediumSlot extends Slot {
	public CultureMediumSlot(Container container, int index, int x, int y) {
		super(container, index, x, y);
	}

	@Override
	public boolean mayPlace(ItemStack stack) {
		return stack.is(ModItems.CULTURE_MEDIUM);
	}
}

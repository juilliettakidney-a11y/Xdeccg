package com.pathogen.protocol.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntSupplier;

import com.pathogen.protocol.ModBlocks;
import com.pathogen.protocol.VirusArchive;
import com.pathogen.protocol.block.entity.ResearchBenchBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;

/**
 * The research bench cockpit: sample + medium slots, an output slot for
 * genome fragments, and a live readout of the sequencing progress toward a
 * full decode. The heavy lifting happens in the tick loop; this menu is a
 * window into it.
 */
public class ResearchBenchMenu extends AbstractContainerMenu {
	public static final int SLOT_SAMPLE = 0;
	public static final int SLOT_MEDIUM = 1;
	public static final int SLOT_FRAGMENTS = 2;
	public static final int SLOT_INVENTORY_START = 3;
	public static final int SLOT_COUNT = 39;

	public static final int DATA_CYCLE = 0;
	public static final int DATA_RESEARCH = 1;
	public static final int DATA_TARGET = 2;
	public static final int DATA_DECODED = 3;
	public static final int DATA_COUNT = 4;

	private final net.minecraft.world.Container container;
	private final ContainerLevelAccess access;
	private final LiveContainerData data;
	private final BlockPos pos;

	public ResearchBenchMenu(int syncId, Inventory playerInv, BlockPos pos) {
		this(syncId, playerInv, resolveContainer(playerInv, pos), pos);
	}

	private ResearchBenchMenu(int syncId, Inventory playerInv, net.minecraft.world.Container container, BlockPos pos) {
		super(ModMenuTypes.RESEARCH_BENCH, syncId);
		checkContainerSize(container, 3);

		this.container = container;
		this.pos = pos;
		this.access = ContainerLevelAccess.create(playerInv.player.level(), pos);
		container.startOpen(playerInv.player);

		addSlot(new SampleSlot(container, ResearchBenchBlockEntity.SLOT_SAMPLE, 10, 24));
		addSlot(new CultureMediumSlot(container, ResearchBenchBlockEntity.SLOT_MEDIUM, 10, 48));
		addSlot(new OutputSlot(container, ResearchBenchBlockEntity.SLOT_FRAGMENTS, 152, 36));
		addStandardInventorySlots(playerInv, 8, 98);

		boolean client = playerInv.player.level().isClientSide();
		ResearchBenchBlockEntity bench = container instanceof ResearchBenchBlockEntity b ? b : null;
		Level level = playerInv.player.level();
		List<IntSupplier> suppliers = new ArrayList<>();
		if (client || bench == null) {
			suppliers.addAll(LiveContainerData.clientPlaceholders(DATA_COUNT));
		} else {
			VirusArchive archive = VirusArchive.get((net.minecraft.server.level.ServerLevel) level);
			suppliers.add(bench::cycleTicks);
			suppliers.add(() -> {
				var spec = bench.loadedSpec();
				return spec == null ? 0 : archive.progressOf(spec.id());
			});
			suppliers.add(() -> {
				var spec = bench.loadedSpec();
				return spec == null ? 0 : Math.max(archive.targetOf(spec.id()),
						spec.researchTarget(bench.loadedSeverity() > 0 ? bench.loadedSeverity() : 1));
			});
			suppliers.add(() -> {
				var spec = bench.loadedSpec();
				return spec != null && archive.isDecoded(spec.id()) ? 1 : 0;
			});
		}
		this.data = new LiveContainerData(client, suppliers);
		checkContainerDataCount(data, DATA_COUNT);
		addDataSlots(data);
	}

	private static net.minecraft.world.Container resolveContainer(Inventory inv, BlockPos pos) {
		Level level = inv.player.level();
		if (!level.isClientSide()) {
			BlockEntity be = level.getBlockEntity(pos);
			if (be instanceof ResearchBenchBlockEntity bench) {
				return bench.inventory();
			}
		}
		return new SimpleContainer(3);
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		this.container.stopOpen(player);
	}

	@Override
	public boolean stillValid(Player player) {
		return stillValid(this.access, player, ModBlocks.RESEARCH_BENCH);
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasItem()) {
			return ItemStack.EMPTY;
		}
		ItemStack stack = slot.getItem();
		ItemStack original = stack.copy();

		switch (index) {
			case SLOT_SAMPLE, SLOT_MEDIUM, SLOT_FRAGMENTS -> {
				if (!moveItemStackTo(stack, SLOT_INVENTORY_START, SLOT_COUNT, true)) {
					return ItemStack.EMPTY;
				}
			}
			default -> {
				if (stack.is(com.pathogen.protocol.ModItems.CULTURE_MEDIUM)) {
					if (!moveItemStackTo(stack, SLOT_MEDIUM, SLOT_MEDIUM + 1, false)) {
						return ItemStack.EMPTY;
					}
				} else if (!moveItemStackTo(stack, SLOT_SAMPLE, SLOT_SAMPLE + 1, false)) {
					return ItemStack.EMPTY;
				}
			}
		}
		if (stack.isEmpty()) {
			slot.set(ItemStack.EMPTY);
		} else {
			slot.setChanged();
		}
		slot.onTake(player, stack);
		return original;
	}

	public int data(int index) {
		return this.data.get(index);
	}
}

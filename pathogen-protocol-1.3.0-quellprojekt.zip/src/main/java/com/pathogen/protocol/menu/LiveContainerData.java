package com.pathogen.protocol.menu;

import java.util.List;
import java.util.function.IntSupplier;

import net.minecraft.world.inventory.ContainerData;

/**
 * Bridges server-side state to the client: on the server the values are
 * computed lazily on every broadcast; on the client they land in a shadow
 * buffer filled by the sync packets. Pass the same number of suppliers on
 * both sides — client-side suppliers are never read.
 */
public final class LiveContainerData implements ContainerData {
	private final boolean client;
	private final List<IntSupplier> suppliers;
	private final int[] shadow;

	public LiveContainerData(boolean client, List<IntSupplier> suppliers) {
		this.client = client;
		this.suppliers = suppliers;
		this.shadow = new int[suppliers.size()];
	}

	public static List<IntSupplier> clientPlaceholders(int count) {
		return java.util.Collections.nCopies(count, () -> 0);
	}

	@Override
	public int get(int index) {
		return client ? shadow[index] : suppliers.get(index).getAsInt();
	}

	@Override
	public void set(int index, int value) {
		shadow[index] = value;
	}

	@Override
	public int getCount() {
		return suppliers.size();
	}
}

package com.pathogen.protocol.menu;

import com.pathogen.protocol.PathogenProtocol;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.BlockPos;

/** Menu types for the laboratory stations. */
public final class ModMenuTypes {
	public static MenuType<PetriDishMenu> PETRI_DISH;
	public static MenuType<IncubatorMenu> INCUBATOR;
	public static MenuType<ResearchBenchMenu> RESEARCH_BENCH;

	private ModMenuTypes() {
	}

	public static void register() {
		PETRI_DISH = register("petri_dish",
				(syncId, inv, pos) -> new PetriDishMenu(syncId, inv, pos));
		INCUBATOR = register("incubator",
				(syncId, inv, pos) -> new IncubatorMenu(syncId, inv, pos));
		RESEARCH_BENCH = register("research_bench",
				(syncId, inv, pos) -> new ResearchBenchMenu(syncId, inv, pos));
	}

	private static <M extends net.minecraft.world.inventory.AbstractContainerMenu> MenuType<M> register(String name,
			ExtendedScreenHandlerType.ExtendedFactory<M, BlockPos> factory) {
		Identifier id = Identifier.fromNamespaceAndPath(PathogenProtocol.MOD_ID, name);
		return Registry.register(BuiltInRegistries.MENU, id,
				new ExtendedScreenHandlerType<>(factory, BlockPos.STREAM_CODEC));
	}
}

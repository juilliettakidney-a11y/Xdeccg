package com.pathogen.protocol.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntSupplier;

import com.pathogen.protocol.ModBlocks;
import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.block.entity.CulturePlateBlockEntity;
import com.pathogen.protocol.item.SampleData;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;

/**
 * The culture dish cockpit: one specimen slot, live readouts, and the
 * feeding controls (medium / golden carrot / harvest into vial).
 */
public class PetriDishMenu extends AbstractContainerMenu {
	public static final int SLOT_PLATE = 0;
	public static final int SLOT_INVENTORY_START = 1;
	public static final int SLOT_COUNT = 37;

	public static final int DATA_FED = 0;
	public static final int DATA_SEVERITY = 1;
	public static final int DATA_COUNT = 2;

	private final net.minecraft.world.Container container;
	private final ContainerLevelAccess access;
	private final LiveContainerData data;
	private final BlockPos pos;

	public PetriDishMenu(int syncId, Inventory playerInv, BlockPos pos) {
		this(syncId, playerInv, resolveContainer(playerInv, pos), pos);
	}

	private PetriDishMenu(int syncId, Inventory playerInv, net.minecraft.world.Container container, BlockPos pos) {
		super(ModMenuTypes.PETRI_DISH, syncId);
		checkContainerSize(container, 1);

		this.container = container;
		this.pos = pos;
		this.access = ContainerLevelAccess.create(playerInv.player.level(), pos);
		container.startOpen(playerInv.player);

		addSlot(new SampleSlot(container, 0, 10, 24));
		addStandardInventorySlots(playerInv, 8, 98);

		boolean client = playerInv.player.level().isClientSide();
		CulturePlateBlockEntity plate = container instanceof CulturePlateBlockEntity p ? p : null;
		List<IntSupplier> suppliers = new ArrayList<>();
		if (client || plate == null) {
			suppliers.addAll(LiveContainerData.clientPlaceholders(DATA_COUNT));
		} else {
			suppliers.add(plate::fedCount);
			suppliers.add(plate::loadedSeverity);
		}
		this.data = new LiveContainerData(client, suppliers);
		checkContainerDataCount(data, DATA_COUNT);
		addDataSlots(data);
	}

	private static net.minecraft.world.Container resolveContainer(Inventory inv, BlockPos pos) {
		Level level = inv.player.level();
		if (!level.isClientSide()) {
			BlockEntity be = level.getBlockEntity(pos);
			if (be instanceof CulturePlateBlockEntity plate) {
				return plate.inventory();
			}
		}
		// The client world would hold a stale copy; the slot sync drives our view instead.
		return new SimpleContainer(1);
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		this.container.stopOpen(player);
	}

	@Override
	public boolean stillValid(Player player) {
		return stillValid(this.access, player, ModBlocks.CULTURE_PLATE);
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasItem()) {
			return ItemStack.EMPTY;
		}
		ItemStack stack = slot.getItem();
		ItemStack original = stack.copy();

		if (index == SLOT_PLATE) {
			if (!moveItemStackTo(stack, SLOT_INVENTORY_START, SLOT_COUNT, true)) {
				return ItemStack.EMPTY;
			}
		} else if (!moveItemStackTo(stack, SLOT_PLATE, SLOT_PLATE + 1, false)) {
			return ItemStack.EMPTY;
		}
		if (stack.isEmpty()) {
			slot.set(ItemStack.EMPTY);
		} else {
			slot.setChanged();
		}
		slot.onTake(player, stack);
		return original;
	}

	/** Reads a data slot (works on both sides; client sees the broadcast shadow). */
	public int data(int index) {
		return this.data.get(index);
	}

	@Override
	public boolean clickMenuButton(Player player, int id) {
		if (!(player.level() instanceof ServerLevel level)) {
			return true;
		}
		BlockEntity be = level.getBlockEntity(this.pos);
		if (!(be instanceof CulturePlateBlockEntity plate)) {
			return false;
		}
		switch (id) {
			case 0 -> feedMedium(player, level, plate);
			case 1 -> feedGoldenCarrot(player, level, plate);
			case 2 -> harvest(player, level, plate);
			default -> {
				return false;
			}
		}
		return true;
	}

	private void feedMedium(Player player, ServerLevel level, CulturePlateBlockEntity plate) {
		if (!takeOne(player, ModItems.CULTURE_MEDIUM)) {
			player.displayClientMessage(Component.literal("§8You need a Culture Medium in your inventory to feed the culture."), false);
			return;
		}
		int updated = plate.feedMedium(level, this.pos);
		if (updated < 0) {
			returnOne(player, ModItems.CULTURE_MEDIUM);
			player.displayClientMessage(Component.literal("§cThe culture can't be fed — the dish is empty or at its limit (severity " + com.pathogen.protocol.VirusSpec.MAX_SEVERITY + ")."), false);
			return;
		}
		VirusSpecMessage.fed(player, plate, updated);
	}

	private void feedGoldenCarrot(Player player, ServerLevel level, CulturePlateBlockEntity plate) {
		if (!takeOne(player, Items.GOLDEN_CARROT)) {
			player.displayClientMessage(Component.literal("§8You need a Golden Carrot to feed the strain rich sugar."), false);
			return;
		}
		String label = plate.feedGoldenCarrot(level, this.pos);
		if (label == null) {
			returnOne(player, Items.GOLDEN_CARROT);
			player.displayClientMessage(Component.literal("§8The dish is empty — seed it first."), false);
			return;
		}
		player.displayClientMessage(Component.literal("§6The strain flares at the rich feed — §e" + label + "§6."), false);
	}

	private void harvest(Player player, ServerLevel level, CulturePlateBlockEntity plate) {
		if (!takeOne(player, ModItems.EMPTY_VIAL)) {
			player.displayClientMessage(Component.literal("§8You need an Empty Vial in your inventory to decant the culture."), false);
			return;
		}
		ItemStack harvested = plate.unloadSample();
		if (harvested.isEmpty()) {
			returnOne(player, ModItems.EMPTY_VIAL);
			player.displayClientMessage(Component.literal("§8The dish is empty — nothing to harvest."), false);
			return;
		}
		if (!player.getInventory().add(harvested)) {
			Containers.dropItemStack(level, this.pos.getX() + 0.5, this.pos.getY() + 1.0, this.pos.getZ() + 0.5, harvested);
		}
		SampleData.Sample read = SampleData.read(harvested);
		if (read != null) {
			player.displayClientMessage(Component.literal("§7You decant the culture: §f" + read.spec().displayName()
					+ " §8(severity " + read.severity() + ")"), false);
		}
	}

	private static boolean takeOne(Player player, Item item) {
		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			ItemStack stack = player.getInventory().getItem(i);
			if (stack.is(item)) {
				stack.shrink(1);
				return true;
			}
		}
		return false;
	}

	private void returnOne(Player player, Item item) {
		ItemStack stack = new ItemStack(item);
		if (!player.getInventory().add(stack)) {
			Containers.dropItemStack(player.level(), this.pos.getX() + 0.5, this.pos.getY() + 1.0, this.pos.getZ() + 0.5, stack);
		}
	}
}

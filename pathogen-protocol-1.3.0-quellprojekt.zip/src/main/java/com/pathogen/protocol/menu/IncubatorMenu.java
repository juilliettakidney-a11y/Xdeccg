package com.pathogen.protocol.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntSupplier;

import com.pathogen.protocol.ModBlocks;
import com.pathogen.protocol.block.entity.IncubatorBlockEntity;
import com.pathogen.protocol.item.SampleData;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;

/**
 * The incubator cockpit: sample + medium slots, the temperature dial
 * (20–45 °C, ideal 37 °C), and live cycle telemetry.
 */
public class IncubatorMenu extends AbstractContainerMenu {
	public static final int SLOT_SAMPLE = 0;
	public static final int SLOT_MEDIUM = 1;
	public static final int SLOT_OUTPUT = 2;
	public static final int SLOT_INVENTORY_START = 3;
	public static final int SLOT_COUNT = 39;

	public static final int DATA_TEMPERATURE = 0;
	public static final int DATA_PROGRESS = 1;
	public static final int DATA_CYCLE = 2;
	public static final int DATA_TICKS_PER_CYCLE = 3;
	public static final int DATA_COUNT = 4;

	private final net.minecraft.world.Container container;
	private final ContainerLevelAccess access;
	private final LiveContainerData data;
	private final BlockPos pos;

	public IncubatorMenu(int syncId, Inventory playerInv, BlockPos pos) {
		this(syncId, playerInv, resolveContainer(playerInv, pos), pos);
	}

	private IncubatorMenu(int syncId, Inventory playerInv, net.minecraft.world.Container container, BlockPos pos) {
		super(ModMenuTypes.INCUBATOR, syncId);
		checkContainerSize(container, 3);

		this.container = container;
		this.pos = pos;
		this.access = ContainerLevelAccess.create(playerInv.player.level(), pos);
		container.startOpen(playerInv.player);

		addSlot(new SampleSlot(container, IncubatorBlockEntity.SLOT_SAMPLE, 10, 24));
		addSlot(new CultureMediumSlot(container, IncubatorBlockEntity.SLOT_MEDIUM, 10, 48));
		addSlot(new OutputSlot(container, IncubatorBlockEntity.SLOT_OUTPUT, 152, 36));
		addStandardInventorySlots(playerInv, 8, 98);

		boolean client = playerInv.player.level().isClientSide();
		IncubatorBlockEntity incubator = container instanceof IncubatorBlockEntity i ? i : null;
		List<IntSupplier> suppliers = new ArrayList<>();
		if (client || incubator == null) {
			suppliers.addAll(LiveContainerData.clientPlaceholders(DATA_COUNT));
		} else {
			suppliers.add(incubator::temperature);
			suppliers.add(incubator::progressCount);
			suppliers.add(incubator::cycleTicks);
			suppliers.add(incubator::ticksPerCycle);
		}
		this.data = new LiveContainerData(client, suppliers);
		checkContainerDataCount(data, DATA_COUNT);
		addDataSlots(data);
	}

	private static net.minecraft.world.Container resolveContainer(Inventory inv, BlockPos pos) {
		Level level = inv.player.level();
		if (!level.isClientSide()) {
			BlockEntity be = level.getBlockEntity(pos);
			if (be instanceof IncubatorBlockEntity incubator) {
				return incubator.inventory();
			}
		}
		return new SimpleContainer(3);
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		this.container.stopOpen(player);
	}

	@Override
	public boolean stillValid(Player player) {
		return stillValid(this.access, player, ModBlocks.INCUBATOR);
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasItem()) {
			return ItemStack.EMPTY;
		}
		ItemStack stack = slot.getItem();
		ItemStack original = stack.copy();

		switch (index) {
			case SLOT_SAMPLE, SLOT_MEDIUM, SLOT_OUTPUT -> {
				if (!moveItemStackTo(stack, SLOT_INVENTORY_START, SLOT_COUNT, true)) {
					return ItemStack.EMPTY;
				}
			}
			default -> {
				if (stack.is(com.pathogen.protocol.ModItems.CULTURE_MEDIUM)) {
					if (!moveItemStackTo(stack, SLOT_MEDIUM, SLOT_MEDIUM + 1, false)) {
						if (!moveItemStackTo(stack, SLOT_SAMPLE, SLOT_SAMPLE + 1, false)) {
							return ItemStack.EMPTY;
						}
					}
				} else if (!moveItemStackTo(stack, SLOT_SAMPLE, SLOT_SAMPLE + 1, false)) {
					return ItemStack.EMPTY;
				}
			}
		}
		if (stack.isEmpty()) {
			slot.set(ItemStack.EMPTY);
		} else {
			slot.setChanged();
		}
		slot.onTake(player, stack);
		return original;
	}

	public int data(int index) {
		return this.data.get(index);
	}

	@Override
	public boolean clickMenuButton(Player player, int id) {
		if (!(player.level() instanceof ServerLevel level)) {
			return true;
		}
		BlockEntity be = level.getBlockEntity(this.pos);
		if (!(be instanceof IncubatorBlockEntity incubator)) {
			return false;
		}
		int current = incubator.temperature();
		int next = switch (id) {
			case 0 -> current - 5;
			case 1 -> current - 1;
			case 2 -> current + 1;
			case 3 -> current + 5;
			case 4 -> IncubatorBlockEntity.IDEAL_TEMP;
			default -> -1;
		};
		if (next == -1) {
			return false;
		}
		incubator.setTemperature(next);
		return true;
	}
}

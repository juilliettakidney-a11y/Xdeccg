package com.pathogen.protocol.menu;

import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;

/** Take-only slot for harvested goods; never accepts deposits. */
public class OutputSlot extends Slot {
	public OutputSlot(Container container, int index, int x, int y) {
		super(container, index, x, y);
	}

	@Override
	public boolean mayPlace(ItemStack stack) {
		return false;
	}
}

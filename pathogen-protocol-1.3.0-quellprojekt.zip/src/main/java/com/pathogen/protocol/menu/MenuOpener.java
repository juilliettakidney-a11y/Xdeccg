package com.pathogen.protocol.menu;

import com.pathogen.protocol.PathogenProtocol;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.MenuProvider;

/** Shared helpers to pop open the laboratory station screens. */
public final class MenuOpener {
	private MenuOpener() {
	}

	public static MenuProvider petriDish(BlockPos pos) {
		return factory("menu.pathogen_protocol.petri_dish", pos, PetriDishMenu::new);
	}

	public static MenuProvider incubator(BlockPos pos) {
		return factory("menu.pathogen_protocol.incubator", pos, IncubatorMenu::new);
	}

	public static MenuProvider researchBench(BlockPos pos) {
		return factory("menu.pathogen_protocol.research_bench", pos, ResearchBenchMenu::new);
	}

	private static MenuProvider factory(String titleKey, BlockPos pos, StationFactory<? extends AbstractContainerMenu> maker) {
		return new SimpleStationFactory(titleKey, pos, maker);
	}

	@FunctionalInterface
	private interface StationFactory<M extends AbstractContainerMenu> {
		M create(int syncId, Inventory inventory, BlockPos pos);
	}

	private static final class SimpleStationFactory implements ExtendedScreenHandlerFactory<BlockPos> {
		private final String titleKey;
		private final BlockPos pos;
		private final StationFactory<? extends AbstractContainerMenu> maker;

		private SimpleStationFactory(String titleKey, BlockPos pos, StationFactory<? extends AbstractContainerMenu> maker) {
			this.titleKey = titleKey;
			this.pos = pos;
			this.maker = maker;
		}

		@Override
		public Component getDisplayName() {
			return Component.translatable(titleKey);
		}

		@Override
		public BlockPos getScreenOpeningData(ServerPlayer player) {
			return this.pos;
		}

		// Server-side construction: vanilla openMenu uses this path.
		@Override
		public AbstractContainerMenu createMenu(int syncId, Inventory inventory, Player player) {
			return this.maker.create(syncId, inventory, this.pos);
		}
	}
}

package com.pathogen.protocol.menu;

import com.pathogen.protocol.ModItems;
import com.pathogen.protocol.item.SampleData;

import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;

/** A single-specimen slot: takes only vessels that actually carry a virus sample. */
public class SampleSlot extends Slot {
	public SampleSlot(Container container, int index, int x, int y) {
		super(container, index, x, y);
	}

	@Override
	public boolean mayPlace(ItemStack stack) {
		return (stack.is(ModItems.VIRUS_VIAL) || stack.is(ModItems.PATHOGEN_PROBE)
				|| stack.is(ModItems.VIRUS_SYRINGE)) && SampleData.hasSample(stack);
	}

	@Override
	public int getMaxStackSize(ItemStack stack) {
		return 1;
	}
}

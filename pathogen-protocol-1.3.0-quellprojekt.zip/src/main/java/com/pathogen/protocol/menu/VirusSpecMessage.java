package com.pathogen.protocol.menu;

import com.pathogen.protocol.block.entity.CulturePlateBlockEntity;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

/** Shared feedback strings for the culture dish. */
final class VirusSpecMessage {
	private VirusSpecMessage() {
	}

	static void fed(Player player, CulturePlateBlockEntity plate, int newSeverity) {
		String name = plate.loadedSpec() != null ? plate.loadedSpec().displayName() : "???";
		player.displayClientMessage(Component.literal("§6The culture rewrites itself — §f" + name
				+ " §6is now severity §c" + newSeverity + "§6/10."), false);
	}
}

# Pathogen Protocol

*A biohazard-research survival mod for Minecraft 1.21.11 (Fabric).*

Something is spreading, and no two outbreaks are alike. Every virus in
Pathogen Protocol is **procedurally generated** — a random name, color,
symptom profile, severity, transmission vector and virulence, recorded
forever in your world's archive. That skeletal zombie lurching toward you…
no one alive has seen that strain before.

Identify the strain. Sequence its genome. Brew the serum. Before it takes you down.

## The outbreak — no two strains alike

Each specimen gets:

- **A name** — generated from a syllable table ("Rusting Thae Miasma",
  "Weeping Ostrix Blight", "Saffron Quorin Scourge"...), tagged by vector.
  Once you've looked at a strain under the microscope, **you own its naming
  rights** — see *Strain naming* below.
- **A vector**, one of three, weighted by dice:
  - **Contact** — blood, bites and saliva. Any close wound can carry it.
  - **Airborne** — shared air. Radius 3.5–7 blocks; grows if the culture is fed.
  - **Foodborne** — the harvest turned; an invisible strain hunts the grain
    supply. Anything you eat risks exposure.
- **Severity 1–10** — dictates damage per pulse, symptom intensity, infection
  length (30 → 70 minutes), decoding cost, and how fast the symptoms stack.
- **Virulence 0.6–1.8** — how *eagerly* the strain spreads. Scales contact
  and foodborne infection chance and airborne reach. Mutates over time —
  culture dishes make it happen.
- **Symptoms** — drawn from Nausea, Hunger, Weakness, Mining Fatigue,
  Blindness, Slowness, Withering; stronger strains roll more of them.
- **An archive entry** — the world saves every genome it has ever known, so
  a strain on day one behaves identically on day two hundred.

Wild infections favor the survivable end (mostly severity 1–2). Almost.
Zombies have a **25% chance** of spawning infected.

## The loop

1. Hunt **infected zombies** (they shed motes of their strain's color).
   They drop a **Virus Sample**, pathogen protein — and some wear a
   **Torn Hazmat Suit**.
2. A torn suit protects nothing. Repair it with a **Hazmat Repair Kit**
   (copper + leather + iron nugget) to get a **Sealed Hazmat Suit** — full
   immunity to contact, airborne and blockborne exposure while worn.
   *It cannot stop a syringe.*
3. Inspect anything suspicious with the **Electron Microscope**: vector,
   severity, danger, symptom dossier, virulence and whether the world has
   decoded the strain — and claim the naming rights for it.
4. **Research Bench**: load a sample, feed it Culture Medium. Every medium
   is 25 research points toward the genome's decoding threshold — and
   worse strains demand *far* more: severity 10 demands 31 medium. Each cycle
   drops a **Genome Fragment**. Fully decode it and the whole world can brew
   the cure.
5. **Brew the Engineered Serum**: Antibiotics + 3 Genome Fragments +
   Nether Wart. It erases any fully-decoded strain in your blood.
   (Plain **Antibiotics** alone only clear severity-1 wild specimens.)
6. Alternatively, play fast and loose: load a **Syringe** (dual-wield an
   empty syringe with a vial — it fills, the vial empties). *Suits don't
   stop needles.*

## The Culture Plate — feeding the monster

Craft a **Culture Plate** (glass + glass + slime ball) and seed it with any
sample. Feeding rewrites the strain:

- **Culture Medium** — +1 severity per feeding. Each feed rolls the
  **mutation table** (25% chance).
- **Golden Carrot** — the strain gets *rich sugar*: one trait flares at
  random — +1 severity, +0.5 airborne reach, +0.12 virulence, or a brand-new
  symptom — plus a smaller (15%) mutation roll.
- The full record of every flare and drift is written to the strain's
  **mutation ledger** — read it with `/pathogen_protocol journal`.

**Mutations** can raise or lower virulence, shrink or extend airborne reach,
add or drop symptoms, or drift the strain's hue — all while the genome
identity stays stable. Drain the dish back into a vial for a specimen as
mean as you dared to breed.

## Swabs & probes — and the G hotkey

Some things bite back only from a distance. A **Sterile Swab** (feather +
stick) run over an **infected creature** or a **contaminated block** yields a
**Pathogen Probe** — a full sample you can research, sequence, breed, or
weaponize like any vial.

New in 1.3.0: press **G** while looking at an infected creature or a
contaminated block and it's swabbed automatically — using a swab from your
hands or your inventory.

## Contaminated blocks

Anything touched by an infected entity — use, attack, or break — stays
**contagious for 5 minutes**. It glints with their strain's motes. Touching
it with bare (or unmasked) hands rolls for exposure, severity-scaled. A
sealed Hazmat Suit rolls nothing; it simply can't get in.

## The interactive lab (new in 1.3.0)

Right-click any station **with an empty hand** and its cockpit opens:

- **Culture Dish** — the specimen in its slot, severity pips, virulence and
  feed count, and one-click **Medium / Carrot / Harvest** controls.
  Harvesting decants the live culture into a fresh vial (consumes one
  Empty Vial).
- **Virus Incubator** — a **temperature dial** (20–45 °C). 37 °C is
  physiologically ideal: growth runs at ×1.7 speed and each growth cycle
  takes ~59 ticks. Every degree away from ideal stretches the cycle; at
  the extremes the culture barely divides. Feedings, cycle progress and
  the loaded strain are all live.
- **Research Bench** — the specimen, its severity, a live research bar
  toward full decode, and the current 200-tick cycle.

All three blocks also keep their classic interactions: shift+interact with
an empty hand ejects the loaded specimen (the bench and incubator), and
shift+interact on the dish harvests it. Breaking a block with a live culture
drops the specimen as a vial — nothing is silently deleted.

## Strain naming & discovery

The first player to analyze a strain under the **Electron Microscope** owns
its naming rights, world-wide. Rename it with:

```
/pathogen_protocol name Patient Zero
```

Rules: 2–48 characters; letters, digits, spaces, `'` and `-`; the name
sticks to the genome, so every microscope, vial and bench in the world
shows it from then on. Everyone else only gets to call it by its generated
name.

The full history of a strain — every severity feed, carrot flare, mutation
and incubator drift — is in its journal:

```
/pathogen_protocol journal
```

## Laboratory equipment

- **Field Laboratory Table** — a proper crafting surface.
- **Laboratory Counter** — steel sink worktop with cabinet drawers; the build-your-lab centerpiece.
- **Specimen Cabinet** — locker-style storage for your more… interesting samples.
- **Laboratory Wall Panel / Floor Tile** — sterile, cleanable, hitherto featureless.
- **Biohazard Hazard Stripe** — decorative warning bands for sealing a wing.
- **Electron Microscope** — full specimen dossier: vector, severity, danger,
  symptoms, virulence and research status; claims naming rights.
- **Centrifuge** — spin a sample into **2 Pathogen Protein**.
- **Virus Incubator** — seed a culture, feed it 3 medium, harvest **two
  vials** of the strain. Its temperature decides how fast.
- **Research Bench** — the heart of the operation. Load, feed, wait.
- **Culture Plate** — the accelerator. Feed it to breed stronger strains.

## Installation

1. Minecraft **1.21.11** + Fabric Loader ≥ 0.20.1
2. Fabric API 0.141.6+1.21.11 (or compatible)
3. Drop `pathogen-protocol-1.3.0.jar` into your `mods/` folder.

**1.1.0 replaced all 4 legacy strains — old vials, cures and genomes are gone. Start a new world.
1.2.0 adds the v2 art overhaul and lab décor blocks.
1.3.0 is world-safe: research, genomes, names and ledgers live in the world
archive and survive upgrades; culture dishes, incubators and benches migrate
their stored specimens automatically on first load.**

## Art direction

All sprites are 16×16 vanilla-style, redrawn with smooth per-pixel gradient ramps,
Bayer-dithered transitions and auto-outlines (v2). Armor layers, the effect icon and the
mod icon were redrawn to match. The whole set is generated from `art/gen_art_v2.py` —
rerun it after tweaking palettes.

## Building from source

Requirements: **JDK 25** (Fabric Loom 1.19.4 runs on the Gradle JVM; the mod's
bytecode targets Java 21) and ~2 GB RAM for Gradle.

```bash
# Linux/macOS (or `sh gradlew ...` if the wrapper is not executable)
./gradlew remapJar    # fastest full mod jar -> build/libs/pathogen-protocol-1.3.0.jar
./gradlew build       # full build: jar + sources jar + remap (heavier, ~2 GB heap)
./gradlew runClient   # playtest in a Loom dev client (needs a desktop session)
./gradlew runServer   # headless dedicated-server smoke test
```

On Windows use `gradlew.bat` instead of `./gradlew`. The Gradle wrapper
(`gradlew`, `gradlew.bat`, `gradle/wrapper/`) is committed, so no local
Gradle install is needed — only the JDK. First run downloads Minecraft and
Fabric dependencies into the Gradle cache. The mod jar ends up at
`build/libs/pathogen-protocol-1.3.0.jar`.

`gradle.properties` sets `org.gradle.jvmargs=-Xmx1536m` and
`org.gradle.workers.max=2` for small machines; raise `-Xmx` if you have RAM.

## Roadmap

- Mob-side contamination (infected creatures tainting their own kills)
- Cure sprays (area cleansing), antiviral warheads
- Plague Doctor variant zombies; Patient Zero boss
- Treatable villagers raising a village's herd immunity
- Config file for spread chances, reservoir strength, plate strength

## Changelog

See **CHANGELOG.md**. Highlights for 1.3.0: the interactive lab
(dish/incubator/bench screens), the temperature dial, golden-carrot feeding,
strain virulence and mutations with a persistent journal, world-wide strain
naming, the G-swab hotkey, 25% infected-zombie rate, and automatic migration
of stored specimens.

---
*Containment is recommended. It is rarely sufficient.*

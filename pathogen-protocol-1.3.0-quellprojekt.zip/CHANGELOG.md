# Changelog

## 1.3.0 — The Interactive Lab

The outbreak learned to evolve, and the laboratory learned to answer back.

### New features

- **Interactive lab screens** — right-click a station with an empty hand to
  open its cockpit:
  - **Culture Dish** — specimen slot, severity pips, virulence readout, feed
    counter, and one-click *Medium / Carrot / Harvest* controls. Harvesting
    decants the live culture into a fresh vial (consumes an Empty Vial).
  - **Virus Incubator** — a live **temperature dial** (20–45 °C). 37 °C is
    ideal (×1.7 growth, ~59-tick cycles); every degree off stretches each
    growth cycle (base 100 ticks per medium, floored at ×0.15 speed).
    Feedings-per-harvest progress (3) and cycle bar update live.
  - **Research Bench** — specimen details, research progress bar toward the
    decode threshold, decoded state badge, and the current 200-tick cycle.
- **Golden Carrot feeding** — feed a culture a golden carrot and one trait of
  the strain flares at random: +1 severity, +0.5 airborne reach, +0.12
  virulence, or a brand-new symptom; plus a 15% bonus mutation roll.
- **Virulence** — every strain carries a virulence factor (0.6–1.8) scaling
  contact chance, foodborne chance and airborne radius. Wild strains spawn
  at 0.9–1.2. Persisted in tags, codecs and the world archive.
- **Mutations** — culture feeding (25% per medium), golden carrots and the
  incubator drift roll (12% per tanked cycle) can shift virulence, airborne
  reach, symptoms, color hue and severity. Genome identity (and therefore
  research progress) survives mutation.
- **Mutation ledger** — the world archive logs every flare, drift and feed,
  per genome. Read it in-game with `/pathogen_protocol journal`.
- **Strain naming & discovery** — the first player to analyze a strain at the
  **Electron Microscope** owns its naming rights world-wide; rename it with
  `/pathogen_protocol name <name>`. Names (2–48 chars, letters/digits/spaces/
  `'-'`) are shown by every microscope, vial, dish, bench and journal.
- **G-key swab** — press **G** looking at an infected creature or a
  contaminated block to swab it automatically (consumes a swab from hand or
  inventory; never consumes one on failure).
- **25% infected-zombie rate** (was 14%).
- **Archive 2.0** — discoverers, custom names, scanned set and per-genome
  mutation ledgers persist in the world save; genome registration now happens
  on microscope scan, bench load and every mutation.

### Changes

- Culture Dish / Incubator / Research Bench are now proper containers with
  slot-based inventories; menu sync replaces chat-spam readouts.
- Dish severity-10 cap unchanged; incubator yield (2 vials per 3 medium)
  unchanged; decoding thresholds unchanged.
- Emptied interactions: empty-hand right-click = open screen; shift+empty
  hand = legacy eject/harvest (kept); medium and samples can still be placed
  by hand or by shift-click from the inventory.
- Breaking a station drops the live specimen as a vial (nothing is lost).
- **World-safe upgrade**: worlds from 1.2.x migrate automatically — the
  pre-1.3 on-block specimen blobs convert to the slot inventories on first
  load, and old archive data gains the new sections empty.

### Technical

- Ported to the 1.21.11 mappings (`Entity.getTags`, `ServerTickEvents`
  `END_WORLD_TICK`, `SavedDataType` String id, `FabricBlockEntityTypeBuilder`,
  `BaseEntityBlock#simpleCodec`).
- New packages: `menu` (screens' common half + slot types + `LiveContainerData`
  broadcast bridge), `net` (G-key payload), `item.SwabService` (shared
  item/hotkey swab path), `client.screen` (drawn, texture-free GUIs).
- Requires Java 21 bytecode; built with JDK 25 (Fabric Loom 1.19.4).

### Known issues / open tasks

See **OPEN_TASKS.md**.

## 1.2.0 — Containment Protocol

- v2 art overhaul: smooth per-pixel gradient ramps, Bayer dithering,
  auto-outlines; redrawn armor layers, effect and mod icons.
- New décor blocks: Laboratory Counter, Specimen Cabinet, Laboratory Wall
  Panel, Laboratory Floor Tile, Biohazard Hazard Stripe.

## 1.1.0 — Genesis

- Replaced the four legacy strains with fully procedural generation
  (name, color, symptoms, severity, vector) and the world archive.
- Research Bench decoding, Engineered Serum, Antibiotics, Centrifuge,
  Virus Incubator, Culture Plate, Electron Microscope, Hazmat gear +
  repair kit, Torn Hazmat Suit from zombies, contaminated blocks.

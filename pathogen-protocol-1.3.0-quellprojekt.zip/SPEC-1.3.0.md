# Pathogen Protocol — 1.3.0 Specification

Precise description of everything 1.3.0 changes or adds, for review and
future maintenance. Items labeled *(unchanged)* are documented for context.

## 1. Genome model

### 1.1 Virulence (new)

Every specimen carries `virulence: float` in [0.6, 1.8].

- Wild specimens roll 0.9–1.2 (`VirusSpec.generate`); food reservoir = 1.0.
- Persisted in item-sample tags, the SavedData archive codec and the
  block-entity migration path of legacy dishes/incubators/benches.
- Effect on balance math (severity-scaled, then multiplied):
  - `contactChance(sev)  = min(0.75, (0.10 + 0.05·sev) · virulence)`
  - `foodChance(sev)     = min(0.40, (0.06 + 0.022·sev) · virulence)`
  - `effectiveRadius(sev) = (spec.radius + 0.4·(sev − spec.severity)) · virulence`
- Severity-10 contact cap raised from 0.55 → 0.75 (high-virulence strains
  must feel endgame).

### 1.2 Mutations (new)

`VirusSpec.mutate(RandomSource)` rolls one mutation from a weighted pool
(AIRBORNE strains additionally roll reach mutations):

| Pool entry       | Effect                                             |
|------------------|----------------------------------------------------|
| VIRULENCE_UP     | +0.08…0.15 virulence (cap 1.8)                    |
| VIRULENCE_DOWN   | −0.05…0.10 virulence (floor 0.6)                  |
| RADIUS_UP        | +0.4…0.7 airborne reach                           |
| RADIUS_DOWN      | −0.3…0.5 airborne reach                           |
| SYMPTOM_ADDED    | one symptom not already present (≤5 symptoms)      |
| SYMPTOM_LOST     | one present symptom removed (≥1 must remain)       |
| HUE_SHIFT        | +0.08…0.18 hue drift, saturation kept              |

Genome `id` never changes — research progress, decoded state and archives
stay valid through evolution. Returns `SimpleEntry<VirusSpec, String>`; the
String is the ledger line.

### 1.3 Triggers

| Source             | Chance | Ledger entry                          |
|--------------------|--------|---------------------------------------|
| Dish: Culture Medium | 25% per feed (severity ≥1 required) | `<from> → <to>` per mutation |
| Dish: Golden Carrot | 15% per feed, after the flare roll  | `Golden carrot — <flare>`      |
| Incubator tick     | 12% per *completed medium cycle*     | `<from> → <to>` per mutation   |

### 1.4 Golden Carrot flare (new)

One randomly chosen improvement (pool filtered by applicability):

- **severity**: +1 (unavailable at severity 10)
- **radius**: +0.5…0.8 airborne reach (airborne strains only)
- **virulence**: +0.12…0.22 (cap 1.8)
- **symptom**: one absent symptom added (≤5)
- **endurance**: +0.08 virulence (fallback when nothing else applies)

Flares are logged, then the 15% mutation roll fires independently.

## 2. Archive (SavedData, `pathogen_protocol:virus_archive`)

New sections (all `optionalFieldOf`, old saves migrate cleanly to empty):

- `discoverers`: genomeId → player name of first microscope scan
- `custom_names`: genomeId → renamed strain (see §5)
- `scanned`: genomeIds analyzed at least once
- `mutations`: genomeId → chronological string log (bounded to 64 entries)

Writers all go through `VirusArchive`; genome registration is guaranteed on
 microscope scan, bench tick, incubator drift and dish mutation. `sanitize()`
prunes dangling sections on load.

## 3. Block stations — now containers

All three stations are `SimpleContainer`-backed (`items` list serialized as
`ItemStack.OPTIONAL_CODEC`), with slot-based menus. Pre-1.3 on-block specimen
blobs (`sample` tag + `medium`/`fedCount` counters) migrate into slots on
first load.

### 3.1 Culture Dish (`culture_plate`)

- Slot 0: specimen vial/probe/syringe (`SampleSlot`, max 1)
- Empty hand → menu · Shift+empty → harvest drop · Medium → direct feed
  (+1 severity, 25% mutation) · Golden Carrot → flare · Empty Vial → decant
- Menu buttons: `0` feed medium · `1` feed golden carrot · `2` harvest into
  new vial (consumes 1 Empty Vial from the player inventory)
- Breaking the block drops the live specimen stack.
- `fedCount` tracks total feedings (medium + carrots) for the screen.

### 3.2 Virus Incubator (`incubator`)

- Slots: 0 sample · 1 culture medium (max 16) · 2 harvest output (take-only)
- Growth cycle: base 100 ticks per medium;
  `ticksPerCycle = max(10, round(100 / tempFactorFor(T)))`
  `tempFactorFor(T) = max(0.15, 1.7 − 0.075·|T − 37|)`
  At 37 °C: ×1.7 → 59 ticks. At 20 °C/45 °C: ×0.425 → 235 ticks.
- 3 feedings → harvest rolls **2 vials** of the live specimen (identical
  spec, current severity) into the output slot; excess vials drop at the
  block. If the output slot can't accept everything, the culture waits in
  suspension rather than vanishing.
- Menu buttons: `0..3` temperature −5/−1/+1/+5 °C (clamped 20–45), `4` → 37 °C.
- Legacy shift interactions kept (eject specimen, etc.).

### 3.3 Research Bench (`research_bench`)

- Slots: 0 sample · 1 medium (max 16) · 2 genome fragments (take-only)
- 200 ticks per cycle · 1 medium → +25 RP · target = `spec.researchTarget(sev)`
  (100 + 75·(sev−1), capped growth as before) · on decode: broadcast message,
  `decoded` tag set · each cycle drops 1 Genome Fragment (output slot or drop).
- Menu: read-only cockpit (organism, severity, RP bar, decoded badge, cycle bar).

## 4. Menus & networking

- Menu types registered via `ExtendedScreenHandlerType<M, BlockPos>` +
  `BlockPos.STREAM_CODEC` (Fabric screen-handler API). Server builds the menu
  via `MenuConstructor.createMenu(syncId, inv, player)`; client builds it from
  the OpenScreen payload via the registered `MenuScreens` constructor.
- `LiveContainerData` — server computes `IntSupplier`s lazily each broadcast;
  client reads a shadow filled by `ClientboundContainerSetDataPacket`.
  Data indices: dish `[fed, severity]`, incubator `[temp, progress, cycleTicks,
  ticksPerCycle]`, bench `[cycleTicks, research, target, decoded]`.
- Slot visuals on client: menu sync writes straight into our dummy containers
  (verified against `ClientPacketListener.handleContainerSetSlot` →
  `AbstractContainerMenu.setItem` → `Slot.set`). The client never sees the
  server's BE instance.
- Screens are texture-free (drawn `fill`/`renderOutline`/`drawString`).
- G-key: `KeyMapping` on `key.pathogen_protocol.swab` (default **G**,
  category MISC) → C2S `swab_action` payload (empty) → server
  `SwabService.swabContextual`: nearest swab (main hand → off hand →
  inventory), ray-cast (4.5 blocks) preferring entities over blocks; swabs
  infected entity or contaminated block; never consumes a swab on failure.

## 5. Discovery, naming & journal

- **Microscope scan**: registers the genome, `markScanned(id, playerName)`;
  first scanner becomes discoverer (`discoverers`).
- **Renaming**: `/pathogen_protocol name <name…>` with greedy string;
  validation happens in `VirusArchive.nameGenome` —
  archive must know the genome, caller must be the discoverer, 2–48 chars,
  `[A-Za-z0-9][A-Za-z0-9 '-]*`. Success: `custom_names` set; shown game-wide.
- **Journal**: `/pathogen_protocol journal` prints the last 8 ledger entries
  for the held specimen (or offhand).
- **Microscope dossier** now includes custom names and virulence.

## 6. Zombie infection

Infected-zombie spawn exposure roll: **0.25** per check (was 0.14).

## 7. Persistence & migration

- `VirusSpec` codec gained `virulence` (optional, default 1.0); tags gained
  `virulence` (optional, default 1.0, clamped). Pre-1.3 worlds: any saved
  infection deserializes with virulence 1.0.
- Station block entities: on `loadAdditional`, a missing slot item plus a
  legacy `sample` compound tag → vial stack rebuilt into the container;
  legacy `medium` counter folded into the medium slot (capped at 16).
- Archive: new sections optional → old saves load with empties.

## 8. Artifacts

- `/home/user/pathogen-protocol-1.3.0.jar` — the release artifact
  (remapped, `fabric.mod.json`: id `pathogen_protocol`, version 1.3.0,
  minecraft `~1.21.11`, java `>=21`).
- Release ZIP `/home/user/pathogen-protocol-1.3.0-release.zip` contains jar +
  README + CHANGELOG + SPEC + OPEN_TASKS + LICENSE.

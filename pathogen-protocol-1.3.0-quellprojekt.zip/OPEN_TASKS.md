# Open Tasks — after 1.3.0

Honest list of what is not done, in rough priority order. Checked items are
verified; unchecked ones are known gaps.

## Verification gaps

- [ ] **Full playtest of the three screens** — rendering, slot sync, buttons
      (`Medium`/`Carrot`/`Harvest`, temperature dial) and shift-click behavior
      were written against the API but not run in a live client this session.
- [ ] `./gradlew build` does not finish on this host: `remapSourcesJar`
      (loom decompile+remap of the sources jar) ran >25 minutes and exhausted
      the 2 GB RAM; the hung daemon was killed. `sourcesJar` itself passes,
      `remapJar` + `compileJava` + `compileClientJava` are green, and the
      release jar + zip are verified. Build with `-Xmx1536m` (already in
      `gradle.properties`) or on a bigger host for the full assembly.
- [ ] Multiplayer behavior of menus across two clients is untested.
- [ ] Server smoke test (`runServer`) not re-run since the 1.3.0 changes.

## Quality

- [ ] No automated tests/gametest exist in the repo (none before either).
      Candidates: VirusSpec.mutate() invariants (clamps, id stability),
      VirusArchive codec round-trip, plate feeding math.
- [ ] `ModAttachments` `builder()` deprecation warnings (3×) — non-blocking.
- [ ] No dedicated advancement for "named your strain" or "first mutation".
- [ ] Screen textures are drawn (no GUI texture atlas) — fine, but a designed
      texture would look better.
- [ ] The G-swab hotkey has no on-screen reminder; add a first-time hint
      toast when the player picks up their first Sterile Swab.

## Gameplay design (ideas, not commitments)

- [ ] Ledger capacity UI: the journal command prints only the last 8 entries.
- [ ] Mutation rates per-arc: golden carrot could favor helpful flares.
- [ ] Discoverer attribution on vial tooltips ("First analyzed by X").
- [ ] Naming length/charset is enforced in the command but not surfaced in UI.

## Release engineering

- [ ] Publish the 1.3.0 jar + release notes to Modrinth/CurseForge (manual).
- [ ] Re-verify `fabric.mod.json` dependencies against 1.21.11/API releases.
